'use strict';
// ---------------------------------------------------------------------------
// Chunk section mesher. Vertex layout (32 bytes):
//  0 pos f32x3 | 12 uv f32x2 | 20 layer u16, overlay u16 | 24 rgb+shade u8x4 | 28 sky u8, block u8, anim u8, pad
// ---------------------------------------------------------------------------
const VSTRIDE = 32;
const FACE_SHADE = [0.6, 0.6, 0.5, 1.0, 0.8, 0.8];
const AO_CURVE = [0.42, 0.62, 0.8, 1.0];
// face corners (BL, BR, TR, TL as seen from outside) and uv
const FACES = [
  { n: [-1, 0, 0], c: [[0, 0, 0], [0, 0, 1], [0, 1, 1], [0, 1, 0]], uv: (x, y, z) => [z, 1 - y] },
  { n: [1, 0, 0], c: [[1, 0, 1], [1, 0, 0], [1, 1, 0], [1, 1, 1]], uv: (x, y, z) => [1 - z, 1 - y] },
  { n: [0, -1, 0], c: [[0, 0, 0], [1, 0, 0], [1, 0, 1], [0, 0, 1]], uv: (x, y, z) => [x, 1 - z] },
  { n: [0, 1, 0], c: [[0, 1, 0], [0, 1, 1], [1, 1, 1], [1, 1, 0]], uv: (x, y, z) => [x, z] },
  { n: [0, 0, -1], c: [[1, 0, 0], [0, 0, 0], [0, 1, 0], [1, 1, 0]], uv: (x, y, z) => [1 - x, 1 - y] },
  { n: [0, 0, 1], c: [[0, 0, 1], [1, 0, 1], [1, 1, 1], [0, 1, 1]], uv: (x, y, z) => [x, 1 - y] },
];
const ANIM_FRAMES = new Uint8Array(4096);
// 连接族（fence/wall/gate/pane）的邻居连接判定：栅栏连栅栏/墙/栅栏门/实心方块；
// 玻璃板/铁栏杆连同类/实心方块/栅栏（单向）。与 entity.js 的碰撞箱共用。
function famConnects(b, nid) {
  if (!nid) return false;
  const nb = BLOCKS[nid];
  if (!nb) return false;
  if (nb.solid && nb.shape === SH_CUBE) return true;
  if (!nb.fam) return false;
  if (nb.fam === b.fam) return true;
  if (b.fam === 'pane' && nb.fam === 'fence') return true;
  if (b.fam !== 'pane' && nb.fam !== 'pane') return true;
  return false;
}
  // 依据四个水平邻居计算连接几何。kind: 'visual' | 'collision'
  // 原版几何（1.21.1 官方模型 fence_post / template_wall_post / template_wall_side_tall）：
  //   栅栏 fence_post = 16px 高（碰撞箱仍为 1.5 格，见 entity.js famCollisionBoxes）；
  //   墙   wall_post  = 16px 立柱 + 连接臂 14px（连接点上方有实体方块时 16px）；
  //   墙碰撞箱仍为 1.5 格（entity.js famCollisionBoxes）。
function famBoxes(b, kind, conn, tallArr) {
  const tall = kind === 'collision';
  if (b.fam === 'fence') {
    const list = [[6, 0, 6, 10, 16, 10]];
    if (conn[0]) list.push([7, 12, 0, 9, 15, 9], [7, 6, 0, 9, 9, 9]);
    if (conn[1]) list.push([7, 12, 9, 9, 15, 16], [7, 6, 9, 9, 9, 16]);
    if (conn[2]) list.push([0, 12, 7, 7, 15, 9], [0, 6, 7, 7, 9, 9]);
    if (conn[3]) list.push([9, 12, 7, 16, 15, 9], [9, 6, 7, 16, 9, 9]);
    return list;
  }
  if (b.fam === 'wall') {
    const list = [[4, 0, 4, 12, 16, 12]];
    if (conn[0]) list.push([5, 0, 0, 11, tall ? 24 : (tallArr && tallArr[0] ? 16 : 14), 8]);
    if (conn[1]) list.push([5, 0, 8, 11, tall ? 24 : (tallArr && tallArr[1] ? 16 : 14), 16]);
    if (conn[2]) list.push([0, 0, 5, 8, tall ? 24 : (tallArr && tallArr[2] ? 16 : 14), 11]);
    if (conn[3]) list.push([8, 0, 5, 16, tall ? 24 : (tallArr && tallArr[3] ? 16 : 14), 11]);
    return list;
  }
  if (b.fam === 'pane') {
    const list = [[7, 0, 7, 9, 16, 9]];
    if (conn[0]) list.push([7, 0, 0, 9, 16, 7]);
    if (conn[1]) list.push([7, 0, 9, 9, 16, 16]);
    if (conn[2]) list.push([0, 0, 7, 7, 16, 9]);
    if (conn[3]) list.push([9, 0, 7, 16, 16, 9]);
    return list;
  }
  return null;
}
function initAnimTable() {
  for (const k in ASSETS.anims) ANIM_FRAMES[ASSETS.tiles[k]] = ASSETS.anims[k];
}

class MeshBuffer {
  constructor(cap) { this.alloc(cap); this.n = 0; }
  alloc(cap) {
    const buf = new ArrayBuffer(cap * VSTRIDE);
    if (this.buf) new Uint8Array(buf).set(new Uint8Array(this.buf, 0, this.n * VSTRIDE));
    this.buf = buf; this.cap = cap;
    this.f = new Float32Array(buf); this.u16 = new Uint16Array(buf); this.u8 = new Uint8Array(buf);
  }
  reset() { this.n = 0; }
  // push one vertex
  v(x, y, z, u, v, layer, overlay, r, g, b, shade, sky, blk, anim) {
    if (this.n >= this.cap) this.alloc(this.cap * 2);
    const o = this.n * 8, o16 = this.n * 16, o8 = this.n * 32;
    const f = this.f;
    f[o] = x; f[o + 1] = y; f[o + 2] = z; f[o + 3] = u; f[o + 4] = v;
    this.u16[o16 + 10] = layer; this.u16[o16 + 11] = overlay;
    const u8 = this.u8;
    u8[o8 + 24] = r; u8[o8 + 25] = g; u8[o8 + 26] = b; u8[o8 + 27] = shade;
    u8[o8 + 28] = sky; u8[o8 + 29] = blk; u8[o8 + 30] = anim; u8[o8 + 31] = 0;
    this.n++;
  }
  slice() { return new Uint8Array(this.buf.slice(0, this.n * VSTRIDE)); }
}

const Mesher = {
  ids: new Uint16Array(18 * 18 * 18),   // 16 位方块 ID（blocks_full.js 全方块）
  metas: new Uint8Array(18 * 18 * 18),
  lights: new Uint8Array(18 * 18 * 18),
  tints: new Uint8Array(18 * 18 * 6), // grass rgb + foliage rgb per padded column
  opaqueBuf: new MeshBuffer(65536),
  transBuf: new MeshBuffer(16384),
  P(x, y, z) { return ((y + 1) * 18 + (z + 1)) * 18 + (x + 1); },

  // Fill padded arrays for section (cx, sy, cz)
  gather(world, cx, sy, cz) {
    const ids = this.ids, metas = this.metas, lights = this.lights, tints = this.tints;
    const y0 = sy * 16;
    for (let dcz = -1; dcz <= 1; dcz++) for (let dcx = -1; dcx <= 1; dcx++) {
      const ch = world.getChunk(cx + dcx, cz + dcz);
      const xa = dcx < 0 ? 15 : 0, xb = dcx > 0 ? 0 : 15, za = dcz < 0 ? 15 : 0, zb = dcz > 0 ? 0 : 15;
      for (let lz = za; lz <= zb; lz++) for (let lx = xa; lx <= xb; lx++) {
        const px = lx + dcx * 16, pz = lz + dcz * 16;
        const ti = ((pz + 1) * 18 + (px + 1)) * 6;
        if (ch) {
          const ci = (lz * 16 + lx) * 3;
          tints[ti] = ch.grass[ci]; tints[ti + 1] = ch.grass[ci + 1]; tints[ti + 2] = ch.grass[ci + 2];
          tints[ti + 3] = ch.foliage[ci]; tints[ti + 4] = ch.foliage[ci + 1]; tints[ti + 5] = ch.foliage[ci + 2];
        }
        for (let py = -1; py <= 16; py++) {
          const y = y0 + py, pi = ((py + 1) * 18 + (pz + 1)) * 18 + (px + 1);
          if (!ch || y < 0) { ids[pi] = y < 0 ? 6 : 0; metas[pi] = 0; lights[pi] = y < 0 ? 0 : 0xF0; continue; }
          if (y >= HEIGHT) { ids[pi] = 0; metas[pi] = 0; lights[pi] = 0xF0; continue; }
          const i = (y << 8) | (lz << 4) | lx;
          ids[pi] = ch.blocks[i]; metas[pi] = ch.meta[i]; lights[pi] = ch.light[i];
        }
      }
    }
  },

  tintOf(b, x, z) {
    const t = this.tints, ti = ((z + 1) * 18 + (x + 1)) * 6;
    switch (b.tint) {
      case 'grass': return [t[ti], t[ti + 1], t[ti + 2]];
      case 'foliage': return [t[ti + 3], t[ti + 4], t[ti + 5]];
      case 'birch': return [128, 167, 85];
      case 'spruce': return [97, 153, 97];
      case 'water': return [63, 118, 228];
    }
    return [255, 255, 255];
  },

  build(world, cx, sy, cz) {
    this.gather(world, cx, sy, cz);
    const ob = this.opaqueBuf, tb = this.transBuf;
    ob.reset(); tb.reset();
    const ids = this.ids;
    const ox = cx * 16, oy = sy * 16, oz = cz * 16;
    for (let y = 0; y < 16; y++) for (let z = 0; z < 16; z++) for (let x = 0; x < 16; x++) {
      const id = ids[((y + 1) * 18 + (z + 1)) * 18 + (x + 1)];
      if (!id) continue;
      this.block(id, x, y, z, ox, oy, oz);
    }
    return { opaque: ob.n ? ob.slice() : null, trans: tb.n ? tb.slice() : null, nOpaque: ob.n, nTrans: tb.n };
  },

  // Mesh a single block at local (0,0,0) with full light (icons, dropped items, held blocks)
  single(id, meta, fullBright = true, iconBoxes = null) {
    this.ids.fill(0); this.metas.fill(0); this.lights.fill(fullBright ? 0xF0 : 0xF0);
    for (let i = 0; i < this.tints.length; i += 6) { this.tints.set([124, 189, 107, 89, 174, 48], i); }
    const p = this.P(0, 0, 0);
    this.ids[p] = id; this.metas[p] = meta;
    if (BLOCKS[id].door) { this.ids[this.P(0, 1, 0)] = 0; }
    const ob = this.opaqueBuf, tb = this.transBuf;
    ob.reset(); tb.reset();
    this._iconBoxes = iconBoxes;
    this.block(id, 0, 0, 0, 0, 0, 0, true);
    this._iconBoxes = null;
    const out = new MeshBuffer(ob.n + tb.n + 4);
    out.u8.set(ob.u8.subarray(0, ob.n * VSTRIDE), 0);
    out.u8.set(tb.u8.subarray(0, tb.n * VSTRIDE), ob.n * VSTRIDE);
    out.n = ob.n + tb.n;
    return out;
  },

  block(id, x, y, z, ox, oy, oz, single) {
    const b = BLOCKS[id];
    const meta = this.metas[this.P(x, y, z)];
    switch (b.shape) {
      case SH_CUBE: this.cube(b, id, meta, x, y, z, ox, oy, oz, single); break;
      case SH_CROSS: this.cross(b, meta, x, y, z, ox, oy, oz, single); break;
      case SH_CROP: this.crop(b, meta, x, y, z, ox, oy, oz); break;
      case SH_LIQUID: this.liquid(b, id, meta, x, y, z, ox, oy, oz, single); break;
      case SH_BOXES: this.boxes(b, id, meta, x, y, z, ox, oy, oz, single); break;
      case SH_TORCH: this.torch(b, meta, x, y, z, ox, oy, oz); break;
      case SH_CACTUS: this.cactus(b, meta, x, y, z, ox, oy, oz); break;
      case SH_MODEL: this.modelShape(b, meta, x, y, z, ox, oy, oz, single); break;
      case SH_FLAT: this.flat(b, meta, x, y, z, ox, oy, oz); break;
    }
  },

  texOf(b, face, meta) { return b.texFn ? b.texFn.call(b, face, meta) : b.tex[face]; },

  cube(b, id, meta, x, y, z, ox, oy, oz, single) {
    const ids = this.ids, lights = this.lights;
    const buf = b.render === 'translucent' ? this.transBuf : this.opaqueBuf;
    let tint = b.tint ? this.tintOf(b, x, z) : null;
    for (let f = 0; f < 6; f++) {
      const F = FACES[f], n = F.n;
      const nid = ids[this.P(x + n[0], y + n[1], z + n[2])];
      if (SOLIDCUBE[nid]) continue;
      if (b.cullSame && nid === id) continue;
      if (b.render === 'translucent' && IS_FLUID[nid]) continue; // avoids order-dependent blending against water
      if (b.render === 'translucent' && BLOCKS[nid].render === 'translucent' && SOLIDCUBE[nid] === 0 && nid !== 0 && BLOCKS[nid].shape === SH_CUBE && id !== 35) continue;
      let layer = this.texOf(b, f, meta);
      let overlay = b.overlay[f];
      let r = 255, g = 255, bl = 255;
      if (id === 2) {
        if ((meta & 1) && f !== 2 && f !== 3) overlay = 0;
        else if (f === 3) { r = tint[0]; g = tint[1]; bl = tint[2]; }
        // side: base untinted, overlay tinted (shader uses rgb for overlay when overlay present)
        if (overlay) { r = tint[0]; g = tint[1]; bl = tint[2]; }
      } else if (tint) { r = tint[0]; g = tint[1]; bl = tint[2]; }
      const rot = b.axis && (meta & 3) ? this.axisRot(meta & 3, f) : 0;
      this.quadAO(buf, F, x, y, z, ox, oy, oz, layer, overlay, r, g, bl, f, rot, single);
    }
  },

  axisRot(a, f) {
    if (a === 1) return (f === 0 || f === 1) ? 0 : 1; // x-axis log: rotate side textures on y/z faces
    if (a === 2) return (f === 4 || f === 5) ? 0 : (f === 2 || f === 3 ? 0 : 1);
    return 0;
  },

  // Quad with smooth lighting + ambient occlusion
  quadAO(buf, F, x, y, z, ox, oy, oz, layer, overlay, r, g, bl, f, rot, single) {
    const ids = this.ids, lights = this.lights, n = F.n;
    const fx = x + n[0], fy = y + n[1], fz = z + n[2];
    const ao = [0, 0, 0, 0], sk = [0, 0, 0, 0], bk = [0, 0, 0, 0];
    const anim = ANIM_FRAMES[layer];
    for (let k = 0; k < 4; k++) {
      const c = F.c[k];
      // tangent offsets
      let s1x = 0, s1y = 0, s1z = 0, s2x = 0, s2y = 0, s2z = 0;
      if (n[0]) { s1y = c[1] ? 1 : -1; s2z = c[2] ? 1 : -1; }
      else if (n[1]) { s1x = c[0] ? 1 : -1; s2z = c[2] ? 1 : -1; }
      else { s1x = c[0] ? 1 : -1; s2y = c[1] ? 1 : -1; }
      const p0 = this.P(fx, fy, fz);
      const p1 = this.P(fx + s1x, fy + s1y, fz + s1z);
      const p2 = this.P(fx + s2x, fy + s2y, fz + s2z);
      const p3 = this.P(fx + s1x + s2x, fy + s1y + s2y, fz + s1z + s2z);
      const o1 = SOLIDCUBE[ids[p1]], o2 = SOLIDCUBE[ids[p2]], o3 = SOLIDCUBE[ids[p3]];
      ao[k] = single ? 3 : (o1 && o2 ? 0 : 3 - o1 - o2 - o3);
      let ls = lights[p0] >> 4, lb = lights[p0] & 15, cnt = 1;
      if (!o1) { ls += lights[p1] >> 4; lb += lights[p1] & 15; cnt++; }
      if (!o2) { ls += lights[p2] >> 4; lb += lights[p2] & 15; cnt++; }
      if (!o3 && !(o1 && o2)) { ls += lights[p3] >> 4; lb += lights[p3] & 15; cnt++; }
      sk[k] = ls / cnt; bk[k] = lb / cnt;
    }
    const shade = FACE_SHADE[f];
    const order = (ao[0] + ao[2] + (sk[0] + sk[2]) * 0.01 < ao[1] + ao[3] + (sk[1] + sk[3]) * 0.01) ? [1, 2, 3, 0] : [0, 1, 2, 3];
    for (const k of order) {
      const c = F.c[k];
      let uv = F.uv(c[0], c[1], c[2]);
      if (rot) uv = [1 - uv[1], uv[0]];
      buf.v(ox + x + c[0], oy + y + c[1], oz + z + c[2], uv[0], uv[1], layer, overlay, r, g, bl,
        Math.round(shade * AO_CURVE[ao[k]] * 255), Math.round(sk[k] * 17), Math.round(bk[k] * 17), anim);
    }
  },

  // Flat-lit quad from explicit corners (array of 4 [x,y,z,u,v])
  quadFlat(buf, pts, layer, overlay, r, g, bl, shade, light, anim = 0) {
    const s = Math.round((light >> 4) * 17), k = Math.round((light & 15) * 17), sh = Math.round(shade * 255);
    for (const p of pts) buf.v(p[0], p[1], p[2], p[3], p[4], layer, overlay, r, g, bl, sh, s, k, anim);
  },

  cross(b, meta, x, y, z, ox, oy, oz, single) {
    const buf = this.opaqueBuf, light = this.lights[this.P(x, y, z)];
    const layer = this.texOf(b, 0, meta);
    const t = b.tint ? this.tintOf(b, x, z) : [255, 255, 255];
    const anim = ANIM_FRAMES[layer];
    let jx = 0, jz = 0;
    if (!single && (b.key === 'short_grass' || b.key === 'fern' || FLOWER_IDS.includes(b.id))) {
      const h = hash3(ox + x, oy + y, oz + z, 99);
      jx = (h - 0.5) * 0.4; jz = (hash3(oz + z, ox + x, oy + y, 7) - 0.5) * 0.4;
    }
    const X = ox + x + jx, Y = oy + y, Z = oz + z + jz, d = 0.15, e = 0.85;
    const quads = [
      [[X + d, Y, Z + d, 0, 1], [X + e, Y, Z + e, 1, 1], [X + e, Y + 1, Z + e, 1, 0], [X + d, Y + 1, Z + d, 0, 0]],
      [[X + e, Y, Z + e, 0, 1], [X + d, Y, Z + d, 1, 1], [X + d, Y + 1, Z + d, 1, 0], [X + e, Y + 1, Z + e, 0, 0]],
      [[X + d, Y, Z + e, 0, 1], [X + e, Y, Z + d, 1, 1], [X + e, Y + 1, Z + d, 1, 0], [X + d, Y + 1, Z + e, 0, 0]],
      [[X + e, Y, Z + d, 0, 1], [X + d, Y, Z + e, 1, 1], [X + d, Y + 1, Z + e, 1, 0], [X + e, Y + 1, Z + d, 0, 0]],
    ];
    for (const q of quads) this.quadFlat(buf, q, layer, 0, t[0], t[1], t[2], 0.9, light, anim);
  },

  crop(b, meta, x, y, z, ox, oy, oz) {
    const buf = this.opaqueBuf, light = this.lights[this.P(x, y, z)];
    const layer = this.texOf(b, 0, meta);
    const X = ox + x, Y = oy + y - 1 / 16, Z = oz + z;
    for (const o of [0.25, 0.75]) {
      for (const flip of [0, 1]) {
        const a = flip ? 1 : 0, c = flip ? 0 : 1;
        this.quadFlat(buf, [[X + o, Y, Z + a, 0, 1], [X + o, Y, Z + c, 1, 1], [X + o, Y + 1, Z + c, 1, 0], [X + o, Y + 1, Z + a, 0, 0]], layer, 0, 255, 255, 255, 0.85, light);
        this.quadFlat(buf, [[X + c, Y, Z + o, 0, 1], [X + a, Y, Z + o, 1, 1], [X + a, Y + 1, Z + o, 1, 0], [X + c, Y + 1, Z + o, 0, 0]], layer, 0, 255, 255, 255, 0.85, light);
      }
    }
  },

  fluidHeight(id, x, y, z) {
    // height of fluid column at padded cell; -1 if not fluid
    const p = this.P(x, y, z);
    if (this.ids[p] !== id) return SOLIDCUBE[this.ids[p]] ? -2 : -1;
    if (this.ids[this.P(x, y + 1, z)] === id) return 1;
    const m = this.metas[p];
    if (m & 8) return 0.9;
    return m === 0 ? 0.889 : (8 - m) / 9;
  },
  cornerHeight(id, x, y, z, dx, dz) {
    // average heights of the 4 columns around corner (x+dx, z+dz) where dx,dz in {0,1}
    let sum = 0, cnt = 0;
    for (const [ax, az] of [[dx - 1, dz - 1], [dx, dz - 1], [dx - 1, dz], [dx, dz]]) {
      const h = this.fluidHeight(id, x + ax, y, z + az);
      if (h === 1) return 1;
      if (h >= 0) { sum += h; cnt++; }
      else if (h === -1 && this.ids[this.P(x + ax, y, z + az)] === 0) { cnt++; }
    }
    return cnt ? sum / cnt : 0.889;
  },

  liquid(b, id, meta, x, y, z, ox, oy, oz, single) {
    const buf = b.render === 'translucent' ? this.transBuf : this.opaqueBuf;
    const ids = this.ids, layer = b.tex[0], anim = ANIM_FRAMES[layer];
    const t = b.tint ? this.tintOf(b, x, z) : [255, 255, 255];
    const above = ids[this.P(x, y + 1, z)];
    let h00, h10, h01, h11;
    if (above === id || single) h00 = h10 = h01 = h11 = single ? 0.889 : 1;
    else {
      h00 = this.cornerHeight(id, x, y, z, 0, 0); h10 = this.cornerHeight(id, x, y, z, 1, 0);
      h01 = this.cornerHeight(id, x, y, z, 0, 1); h11 = this.cornerHeight(id, x, y, z, 1, 1);
    }
    const X = ox + x, Y = oy + y, Z = oz + z;
    const L = (dx, dy, dz) => this.lights[this.P(x + dx, y + dy, z + dz)];
    const own = this.lights[this.P(x, y, z)];
    const lmax = (a, c) => (Math.max(a >> 4, c >> 4) << 4) | Math.max(a & 15, c & 15);
    // top
    if (above !== id) {
      const l = lmax(L(0, 1, 0), own);
      const e = 0.001;
      this.quadFlat(buf, [[X, Y + h00 - e, Z, 0, 0], [X, Y + h01 - e, Z + 1, 0, 1], [X + 1, Y + h11 - e, Z + 1, 1, 1], [X + 1, Y + h10 - e, Z, 1, 0]], layer, 0, t[0], t[1], t[2], 1, l, anim);
      if (b.render === 'translucent') // underside visible from below the surface
        this.quadFlat(buf, [[X + 1, Y + h10 - e, Z, 1, 0], [X + 1, Y + h11 - e, Z + 1, 1, 1], [X, Y + h01 - e, Z + 1, 0, 1], [X, Y + h00 - e, Z, 0, 0]], layer, 0, t[0], t[1], t[2], 0.8, l, anim);
    }
    // bottom
    const below = ids[this.P(x, y - 1, z)];
    if (below !== id && !SOLIDCUBE[below]) {
      this.quadFlat(buf, [[X, Y, Z, 0, 0], [X + 1, Y, Z, 1, 0], [X + 1, Y, Z + 1, 1, 1], [X, Y, Z + 1, 0, 1]], layer, 0, t[0], t[1], t[2], 0.5, lmax(L(0, -1, 0), own), anim);
    }
    // sides
    // [face, dx, dz, BL(x,z), BR(x,z), height at BR, height at BL]
    const sides = [
      [0, -1, 0, X, Z, X, Z + 1, h01, h00],
      [1, 1, 0, X + 1, Z + 1, X + 1, Z, h10, h11],
      [4, 0, -1, X + 1, Z, X, Z, h00, h10],
      [5, 0, 1, X, Z + 1, X + 1, Z + 1, h11, h01],
    ];
    for (const [f, dx, dz, ax, az, bx, bz, hb, ha] of sides) {
      const nid = ids[this.P(x + dx, y, z + dz)];
      if (nid === id || SOLIDCUBE[nid]) continue;
      const q = [[ax, Y, az, 0, 1], [bx, Y, bz, 1, 1], [bx, Y + hb, bz, 1, 1 - hb], [ax, Y + ha, az, 0, 1 - ha]];
      this.quadFlat(buf, q, layer, 0, t[0], t[1], t[2], FACE_SHADE[f], lmax(L(dx, 0, dz), own), anim);
    }
  },

  // 贴地平面方块（原版 rail_flat）：顶部 + 底面两个 quad，meta 控制旋转（0 南北 / 1 东西 / 6..9 弯道）
  flat(b, meta, x, y, z, ox, oy, oz) {
    const buf = this.opaqueBuf, light = this.lights[this.P(x, y, z)];
    const m = meta & 15;
    const curve = m >= 6;
    const layer = curve ? (b.tex[1] ?? b.tex[0]) : b.tex[0];
    const anim = ANIM_FRAMES[layer];
    const X = ox + x, Y = oy + y + 1 / 16, Z = oz + z;
    const r = curve ? (m - 6) : (m === 1 || m === 3 || m === 5 ? 1 : 0);
    const rot = (u, v, k) => { for (let i = 0; i < k; i++) { const t = u; u = 1 - v; v = t; } return [u, v]; };
    const q = [[X, Y, Z], [X, Y, Z + 1], [X + 1, Y, Z + 1], [X + 1, Y, Z]];
    const qd = [[X + 1, Y, Z], [X + 1, Y, Z + 1], [X, Y, Z + 1], [X, Y, Z]];
    const uvs = [[0, 0], [0, 1], [1, 1], [1, 0]];
    const pts = q.map((p, i) => { const [u, v] = rot(uvs[i][0], uvs[i][1], r); return [p[0], p[1], p[2], u, v]; });
    const ptsD = qd.map((p, i) => { const [u, v] = rot(uvs[i][0], uvs[i][1], r); return [p[0], p[1], p[2], u, v]; });
    this.quadFlat(buf, pts, layer, 0, 255, 255, 255, 1, light, anim);
    this.quadFlat(buf, ptsD, layer, 0, 255, 255, 255, 0.5, light, anim);
  },

  boxes(b, id, meta, x, y, z, ox, oy, oz, single) {
    const buf = b.render === 'translucent' ? this.transBuf : this.opaqueBuf;
    const ids = this.ids, lights = this.lights;
    const own = lights[this.P(x, y, z)];
    const tint = b.tint ? this.tintOf(b, x, z) : [255, 255, 255];
    let list;
    let conn = null, tallArr = null;
    if (this._iconBoxes) list = this._iconBoxes;
    else if (b.fam && b.fam !== 'gate') {
      conn = [
        !!famConnects(b, ids[this.P(x, y, z - 1)]), !!famConnects(b, ids[this.P(x, y, z + 1)]),
        !!famConnects(b, ids[this.P(x - 1, y, z)]), !!famConnects(b, ids[this.P(x + 1, y, z)])];
      if (b.fam === 'wall') tallArr = conn.map((c, i) => { const D = [[0, 0, -1], [0, 0, 1], [-1, 0, 0], [1, 0, 0]][i]; return !!SOLIDCUBE[ids[this.P(x + D[0], y + 1, z + D[2])]]; });
      list = famBoxes(b, 'visual', conn, tallArr) || b.boxes(meta);
    } else list = b.boxes(meta);
    for (const bx of list) {
      const x0 = bx[0] / 16, y0 = bx[1] / 16, z0 = bx[2] / 16, x1 = bx[3] / 16, y1 = bx[4] / 16, z1 = bx[5] / 16;
      for (let f = 0; f < 6; f++) {
        const n = FACES[f].n;
        const onEdge = (f === 0 && x0 === 0) || (f === 1 && x1 === 1) || (f === 2 && y0 === 0) || (f === 3 && y1 === 1) || (f === 4 && z0 === 0) || (f === 5 && z1 === 1);
        let light = own;
        if (onEdge) {
          const nid = ids[this.P(x + n[0], y + n[1], z + n[2])];
          if (SOLIDCUBE[nid] && !single) continue;
          if (nid === id && b.cullSame) continue;
          light = lights[this.P(x + n[0], y + n[1], z + n[2])];
          if (SOLIDCUBE[nid]) light = own;
        }
        if (b.slab && (meta & 3) === 2 && !onEdge) continue;
        if (single) light = 0xF0;
        // 玻璃板贴图规则（原版 template_glass_pane_post/side/noside）：
        //   连接态立柱仅绘制上下面（边缘贴图），侧面不绘制（原版 pane_post 无侧面）；
        //   连接臂大面（垂直于薄边的两个面）用玻璃贴图，端面与上下面用边缘贴图；
        //   孤立玻璃板 = 原版 noside：大面用玻璃贴图（南北向）。
        let layer;
        if (b.fam === 'pane' && b.paneFace !== undefined) {
          const thinX = bx[3] - bx[0] <= 2 && bx[5] - bx[2] > 2;   // 南北向连接臂
          const thinZ = bx[5] - bx[2] <= 2 && bx[3] - bx[0] > 2;   // 东西向连接臂
          const isPost = !thinX && !thinZ;
          const lone = isPost && (!conn || conn.every(c => !c));
          if (isPost && !lone && f !== 2 && f !== 3) continue;
          if (isPost && lone && (f === 0 || f === 1)) continue;
          const wide = thinX ? [0, 1] : thinZ ? [4, 5] : lone ? [4, 5] : null;
          layer = wide && wide.includes(f) ? b.paneFace : b.paneEdge;
        } else layer = this.texOf(b, f, meta);
        const anim = ANIM_FRAMES[layer];
        const pts = FACES[f].c.map(c => {
          const px = c[0] ? x1 : x0, py = c[1] ? y1 : y0, pz = c[2] ? z1 : z0;
          const uv = FACES[f].uv(px, py, pz);
          return [ox + x + px, oy + y + py, oz + z + pz, uv[0], uv[1]];
        });
        this.quadFlat(buf, pts, layer, 0, tint[0], tint[1], tint[2], FACE_SHADE[f], light, anim);
      }
    }
  },

  modelShape(b, meta, x, y, z, ox, oy, oz, single) {
    const buf = this.opaqueBuf, ids = this.ids, lights = this.lights;
    const own = lights[this.P(x, y, z)];
    const { els, rot, tiltX, tiltZ } = b.model(meta);
    const FN = { west: 0, east: 1, down: 2, up: 3, north: 4, south: 5 };
    const rotDir = [[0, 1, 2, 3, 4, 5], [4, 5, 2, 3, 1, 0], [1, 0, 2, 3, 5, 4], [5, 4, 2, 3, 0, 1]][rot]; // model face -> world face
    const rp = (px, pz) => { // rotate point around block centre, clockwise seen from above
      for (let k = 0; k < rot; k++) { const t = px; px = 1 - pz; pz = t; }
      return [px, pz];
    };
    // 整体绕 X / Z 轴旋转（末地烛 6 向朝向、锁链水平轴向），绕方块中心
    const tx = tiltX ? tiltX * Math.PI / 180 : 0, tz = tiltZ ? tiltZ * Math.PI / 180 : 0;
    const tilt = (px, py, pz) => {
      if (tx) { const dy = py - 0.5, dz = pz - 0.5; py = 0.5 + dy * Math.cos(tx) - dz * Math.sin(tx); pz = 0.5 + dy * Math.sin(tx) + dz * Math.cos(tx); }
      if (tz) { const dx = px - 0.5, dy2 = py - 0.5; px = 0.5 + dx * Math.cos(tz) - dy2 * Math.sin(tz); py = 0.5 + dx * Math.sin(tz) + dy2 * Math.cos(tz); }
      return [px, py, pz];
    };
    for (const e of els) {
      const x0 = e.from[0] / 16, y0 = e.from[1] / 16, z0 = e.from[2] / 16, x1 = e.to[0] / 16, y1 = e.to[1] / 16, z1 = e.to[2] / 16;
      // 元素级旋转：绕 X 轴（原版讲台顶板 -22.5°）/ 绕 Y 轴 45°（灯笼吊环、锁链斜板）
      const exrot = e.rot && e.rot.axis === 'x' ? e.rot.angle * Math.PI / 180 : 0;
      const eyrot = e.rot && e.rot.axis === 'y' ? e.rot.angle * Math.PI / 180 : 0;
      const eoy = e.rot ? e.rot.origin[1] / 16 : 0, eoz = e.rot ? e.rot.origin[2] / 16 : 0, eox = e.rot ? e.rot.origin[0] / 16 : 0;
      for (const fname in e.faces) {
        const f = FN[fname], [u0, v0, u1, v1, layer] = e.faces[fname];
        const wf = rotDir[f];
        const n = FACES[wf].n;
        const onEdge = !exrot && !eyrot && !tx && !tz && ((f === 0 && x0 === 0) || (f === 1 && x1 === 1) || (f === 2 && y0 === 0) || (f === 3 && y1 === 1) || (f === 4 && z0 === 0) || (f === 5 && z1 === 1));
        let light = own;
        if (onEdge && !single) {
          const nid = ids[this.P(x + n[0], y + n[1], z + n[2])];
          if (SOLIDCUBE[nid]) continue;
          light = lights[this.P(x + n[0], y + n[1], z + n[2])];
        }
        if (single) light = 0xF0;
        const pts = FACES[f].c.map((c) => {
          let px = c[0] ? x1 : x0, py = c[1] ? y1 : y0, pz = c[2] ? z1 : z0;
          if (exrot) {
            const dy = py - eoy, dz = pz - eoz;
            py = eoy + dy * Math.cos(exrot) - dz * Math.sin(exrot);
            pz = eoz + dy * Math.sin(exrot) + dz * Math.cos(exrot);
          }
          if (eyrot) {
            const dx = px - eox, dz = pz - eoz;
            px = eox + dx * Math.cos(eyrot) - dz * Math.sin(eyrot);
            pz = eoz + dx * Math.sin(eyrot) + dz * Math.cos(eyrot);
          }
          [px, py, pz] = tilt(px, py, pz);
          const U = FACES[f].uv(c[0], c[1], c[2]);
          const [rx, rz] = rp(px, pz);
          return [ox + x + rx, oy + y + py, oz + z + rz, (u0 + U[0] * (u1 - u0)) / 16, (v0 + U[1] * (v1 - v0)) / 16];
        });
        this.quadFlat(buf, pts, layer, 0, 255, 255, 255, FACE_SHADE[wf], light);
      }
    }
  },

  // several blocks at given local offsets (icons for multi-block items)
  multi(list) {
    this.ids.fill(0); this.metas.fill(0); this.lights.fill(0xF0);
    for (const [id, meta, x, y, z] of list) { const p = this.P(x, y, z); this.ids[p] = id; this.metas[p] = meta; }
    const ob = this.opaqueBuf; ob.reset(); this.transBuf.reset();
    for (const [id, meta, x, y, z] of list) this.block(id, x, y, z, 0, 0, 0, true);
    const out = new MeshBuffer(ob.n + 4);
    out.u8.set(ob.u8.subarray(0, ob.n * VSTRIDE), 0); out.n = ob.n;
    return out;
  },

  cactus(b, meta, x, y, z, ox, oy, oz) {
    const buf = this.opaqueBuf, light = this.lights[this.P(x, y, z)];
    const X = ox + x, Y = oy + y, Z = oz + z, i = 1 / 16;
    for (let f = 0; f < 6; f++) {
      const F = FACES[f], n = F.n;
      if ((f === 2 || f === 3) && SOLIDCUBE[this.ids[this.P(x + n[0], y + n[1], z + n[2])]]) continue;
      if ((f === 3 || f === 2) && this.ids[this.P(x + n[0], y + n[1], z + n[2])] === b.id) continue;
      const pts = F.c.map(c => {
        let px = c[0], py = c[1], pz = c[2];
        if (f === 0) px = i; if (f === 1) px = 1 - i; if (f === 4) pz = i; if (f === 5) pz = 1 - i;
        const uv = F.uv(c[0], c[1], c[2]);
        return [X + px, Y + py, Z + pz, uv[0], uv[1]];
      });
      this.quadFlat(buf, pts, b.tex[f], 0, 255, 255, 255, FACE_SHADE[f], light);
    }
  },

  torch(b, meta, x, y, z, ox, oy, oz) {
    const buf = this.opaqueBuf, light = 0xF0 | 14 | (this.lights[this.P(x, y, z)] & 0xF0);
    const layer = b.tex[0];
    const X = ox + x + 0.5, Z = oz + z + 0.5;
    let bx = 0, bz = 0, by = 0, lean = 0, lx = 0, lz = 0;
    if (meta && DIRS[meta]) {
      const D = DIRS[meta];
      bx = D[0] * 0.38; bz = D[2] * 0.38; by = 0.2; lean = 0.32; lx = -D[0]; lz = -D[2];
    }
    const Y = oy + y + by;
    const w = 1 / 16, h = 10 / 16;
    const P = (px, py, pz) => [X + bx + px + lx * lean * py / h * 0.6, Y + py, Z + bz + pz + lz * lean * py / h * 0.6];
    const u0 = 7 / 16, u1 = 9 / 16, v0 = 6 / 16, v1 = 1;
    const sides = [
      [[-w, 0, -w], [-w, 0, w], [-w, h, w], [-w, h, -w], 0],
      [[w, 0, w], [w, 0, -w], [w, h, -w], [w, h, w], 1],
      [[w, 0, -w], [-w, 0, -w], [-w, h, -w], [w, h, -w], 4],
      [[-w, 0, w], [w, 0, w], [w, h, w], [-w, h, w], 5],
    ];
    for (const s of sides) {
      const pts = [[...P(...s[0]), u0, v1], [...P(...s[1]), u1, v1], [...P(...s[2]), u1, v0], [...P(...s[3]), u0, v0]];
      this.quadFlat(buf, pts, layer, 0, 255, 255, 255, FACE_SHADE[s[4]], light);
    }
    const top = [[...P(-w, h, -w), u0, 8 / 16], [...P(-w, h, w), u0, 6 / 16], [...P(w, h, w), u1, 6 / 16], [...P(w, h, -w), u1, 8 / 16]];
    this.quadFlat(buf, top, layer, 0, 255, 255, 255, 1, light);
    const bot = [[...P(-w, 0, -w), u0, 1], [...P(w, 0, -w), u1, 1], [...P(w, 0, w), u1, 14 / 16], [...P(-w, 0, w), u0, 14 / 16]];
    this.quadFlat(buf, bot, layer, 0, 255, 255, 255, 0.5, light);
  },
};

// Extruded item sprite mesh (for held items and dropped items). Returns MeshBuffer in 0..1 xy, z in [-1/32,1/32]
const ItemMeshCache = new Map();
let _spriteAlpha = null;
function itemSpriteMesh(layer) {
  if (ItemMeshCache.has(layer)) return ItemMeshCache.get(layer);
  const a = _spriteAlpha;
  const buf = new MeshBuffer(512);
  const t = 1 / 32, px = 1 / 16;
  const opaque = (x, y) => x >= 0 && y >= 0 && x < 16 && y < 16 && a[layer * 256 + y * 16 + x] > 0;
  const V = (x, y, z, u, v, sh) => buf.v(x, y, z, u, v, layer, 0, 255, 255, 255, Math.round(sh * 255), 255, 0, 0);
  // front (+z) and back
  V(0, 0, t, 0, 1, 1); V(1, 0, t, 1, 1, 1); V(1, 1, t, 1, 0, 1); V(0, 1, t, 0, 0, 1);
  V(1, 0, -t, 1, 1, 0.8); V(0, 0, -t, 0, 1, 0.8); V(0, 1, -t, 0, 0, 0.8); V(1, 1, -t, 1, 0, 0.8);
  for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) {
    if (!opaque(x, y)) continue;
    const X0 = x * px, X1 = (x + 1) * px, Y1 = 1 - y * px, Y0 = 1 - (y + 1) * px;
    const uc = (x + 0.5) / 16, vc = (y + 0.5) / 16;
    if (!opaque(x - 1, y)) { V(X0, Y0, -t, uc, vc, 0.6); V(X0, Y0, t, uc, vc, 0.6); V(X0, Y1, t, uc, vc, 0.6); V(X0, Y1, -t, uc, vc, 0.6); }
    if (!opaque(x + 1, y)) { V(X1, Y0, t, uc, vc, 0.6); V(X1, Y0, -t, uc, vc, 0.6); V(X1, Y1, -t, uc, vc, 0.6); V(X1, Y1, t, uc, vc, 0.6); }
    if (!opaque(x, y - 1)) { V(X0, Y1, t, uc, vc, 1); V(X1, Y1, t, uc, vc, 1); V(X1, Y1, -t, uc, vc, 1); V(X0, Y1, -t, uc, vc, 1); }
    if (!opaque(x, y + 1)) { V(X0, Y0, -t, uc, vc, 0.5); V(X1, Y0, -t, uc, vc, 0.5); V(X1, Y0, t, uc, vc, 0.5); V(X0, Y0, t, uc, vc, 0.5); }
  }
  ItemMeshCache.set(layer, buf);
  return buf;
}
