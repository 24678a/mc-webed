'use strict';
// ============================================================================
// 1.21.1 全方块注册 + 原版创造模式物品栏分类（自动生成，见 tools/gen_blocks_full.py）
//  - 新物品先注册（沿用 defItem 自动 ID）；新方块 ID 接在全部物品之后，
//    与旧存档（旧 ID 方块 0..175 / 物品 256..352）完全兼容。
//  - 世界存储与网格器已改为 16 位方块 ID（world.js / mesher.js / save.js）。
// ============================================================================

// ---- 新增物品 ---------------------------------------------------------------
defItem('potato', '马铃薯', { food: [1, 0.6], places: 'potatoes' });
defItem('golden_carrot', '金胡萝卜', { food: [6, 14.4] });
defItem('bowl', '碗', {});
defItem('mushroom_stew', '蘑菇煲', { food: [6, 7.2], stack: 1 });
defItem('cod', '生鳕鱼', { food: [2, 0.4] });
defItem('cooked_cod', '熟鳕鱼', { food: [5, 6] });
defItem('sweet_berries', '甜浆果', { food: [2, 0.4], places: 'sweet_berry_bush', tex: T('sweet_berry_bush_stage3') });
defItem('nether_wart', '下界疣', { places: 'nether_wart', tex: T('nether_wart_stage2') });
defItem('raw_copper', '粗铜', { tex: T('raw_copper_block') });
defItem('quartz', '下界石英', { tex: T('quartz_block_side') });
defItem('amethyst_shard', '紫水晶碎片', { tex: T('amethyst_cluster') });

// ---- 新方块：ID 接在全部物品之后 ---------------------------------------------
let __nid = ITEMS.length;
function D(key, cn, o) { return defBlock(__nid++, key, cn, o); }
const cubeB = (key, cn, tex, o = {}) => D(key, cn, Object.assign({ tex }, o));
const cubeTS = (key, cn, top, side, o = {}) => cubeB(key, cn, { top, side }, o);
const crossB = (key, cn, tex, o = {}) => D(key, cn, Object.assign({ shape: SH_CROSS, tex, solid: false, hardness: 0, sound: 'grass', needsSupport: true, flatIcon: tex }, o));
const logB = (key, cn, side, top, o = {}) => cubeTS(key, cn, top, side, Object.assign({ hardness: 2, tool: 'axe', sound: 'wood', axis: true, texFn: logTex, fuel: 300 }, o));
const stairB = (key, cn, tex, o = {}) => D(key, cn, Object.assign({ shape: SH_BOXES, boxes: stairBoxes, tex, stairs: true }, o));
const slabB = (key, cn, tex, o = {}) => D(key, cn, Object.assign({ shape: SH_BOXES, boxes: (m) => SLAB_BOXES[m & 3], tex, slab: true, drops: slabDrop(key) }, o));
// 原版几何（1/16 单位）：
//   栅栏连接柱: post [6,0,6,10,16,10]，横杆(N/S 向) x7..9 y12..15 与 y6..9
//   图标 = 原版 fence_inventory（双柱 + 上下横杆）；按钮 = button_inventory
const wallB = (key, cn, tex, o = {}) => D(key, cn, Object.assign({ shape: SH_BOXES, boxes: () => [[4, 0, 4, 12, 16, 12]], tex, solid: true, fam: 'wall',
  // 物品栏图标 = 原版 wall_inventory：立柱 [4,0,4,12,16,12] + 一段整幅连接臂 [5,0,0,11,13,16]
  iconBoxes: [[4, 0, 4, 12, 16, 12], [5, 0, 0, 11, 13, 16]] }, o));
const fenceB = (key, cn, tex, o = {}) => D(key, cn, Object.assign({ shape: SH_BOXES, boxes: () => [[6, 0, 6, 10, 16, 10]], tex, fam: 'fence', iconBoxes: [[6, 0, 0, 10, 16, 4], [6, 0, 12, 10, 16, 16], [7, 12, 0, 9, 15, 16], [7, 6, 0, 9, 9, 16]] }, o));
// 栅栏门：原版 template_fence_gate / template_fence_gate_open 全套 8 元素几何；
// meta bit0-1 = 朝向旋转，bit2 = 打开；碰撞 1.5 格高（entity.js famCollisionBoxes）
const GATE_CLOSED_TPL = [
  { from: [0, 5, 7], to: [2, 16, 9], faces: { down: [0, 7, 2, 9, '%'], up: [0, 7, 2, 9, '%'], north: [0, 0, 2, 11, '%'], south: [0, 0, 2, 11, '%'], west: [7, 0, 9, 11, '%'], east: [7, 0, 9, 11, '%'] } },
  { from: [14, 5, 7], to: [16, 16, 9], faces: { down: [14, 7, 16, 9, '%'], up: [14, 7, 16, 9, '%'], north: [14, 0, 16, 11, '%'], south: [14, 0, 16, 11, '%'], west: [7, 0, 9, 11, '%'], east: [7, 0, 9, 11, '%'] } },
  { from: [6, 6, 7], to: [8, 15, 9], faces: { down: [6, 7, 8, 9, '%'], up: [6, 7, 8, 9, '%'], north: [6, 1, 8, 10, '%'], south: [6, 1, 8, 10, '%'], west: [7, 1, 9, 10, '%'], east: [7, 1, 9, 10, '%'] } },
  { from: [8, 6, 7], to: [10, 15, 9], faces: { down: [8, 7, 10, 9, '%'], up: [8, 7, 10, 9, '%'], north: [8, 1, 10, 10, '%'], south: [8, 1, 10, 10, '%'], west: [7, 1, 9, 10, '%'], east: [7, 1, 9, 10, '%'] } },
  { from: [2, 6, 7], to: [6, 9, 9], faces: { down: [2, 7, 6, 9, '%'], up: [2, 7, 6, 9, '%'], north: [2, 7, 6, 10, '%'], south: [2, 7, 6, 10, '%'] } },
  { from: [2, 12, 7], to: [6, 15, 9], faces: { down: [2, 7, 6, 9, '%'], up: [2, 7, 6, 9, '%'], north: [2, 1, 6, 4, '%'], south: [2, 1, 6, 4, '%'] } },
  { from: [10, 6, 7], to: [14, 9, 9], faces: { down: [10, 7, 14, 9, '%'], up: [10, 7, 14, 9, '%'], north: [10, 7, 14, 10, '%'], south: [10, 7, 14, 10, '%'] } },
  { from: [10, 12, 7], to: [14, 15, 9], faces: { down: [10, 7, 14, 9, '%'], up: [10, 7, 14, 9, '%'], north: [10, 1, 14, 4, '%'], south: [10, 1, 14, 4, '%'] } },
];
const GATE_OPEN_TPL = [
  { from: [0, 5, 7], to: [2, 16, 9], faces: { down: [0, 7, 2, 9, '%'], up: [0, 7, 2, 9, '%'], north: [0, 0, 2, 11, '%'], south: [0, 0, 2, 11, '%'], west: [7, 0, 9, 11, '%'], east: [7, 0, 9, 11, '%'] } },
  { from: [14, 5, 7], to: [16, 16, 9], faces: { down: [14, 7, 16, 9, '%'], up: [14, 7, 16, 9, '%'], north: [14, 0, 16, 11, '%'], south: [14, 0, 16, 11, '%'], west: [7, 0, 9, 11, '%'], east: [7, 0, 9, 11, '%'] } },
  { from: [0, 6, 13], to: [2, 15, 15], faces: { down: [0, 13, 2, 15, '%'], up: [0, 13, 2, 15, '%'], north: [0, 1, 2, 10, '%'], south: [0, 1, 2, 10, '%'], west: [13, 1, 15, 10, '%'], east: [13, 1, 15, 10, '%'] } },
  { from: [14, 6, 13], to: [16, 15, 15], faces: { down: [14, 13, 16, 15, '%'], up: [14, 13, 16, 15, '%'], north: [14, 1, 16, 10, '%'], south: [14, 1, 16, 10, '%'], west: [13, 1, 15, 10, '%'], east: [13, 1, 15, 10, '%'] } },
  { from: [0, 6, 9], to: [2, 9, 13], faces: { down: [0, 9, 2, 13, '%'], up: [0, 9, 2, 13, '%'], west: [13, 7, 15, 10, '%'], east: [13, 7, 15, 10, '%'] } },
  { from: [0, 12, 9], to: [2, 15, 13], faces: { down: [0, 9, 2, 13, '%'], up: [0, 9, 2, 13, '%'], west: [13, 1, 15, 4, '%'], east: [13, 1, 15, 4, '%'] } },
  { from: [14, 6, 9], to: [16, 9, 13], faces: { down: [14, 9, 16, 13, '%'], up: [14, 9, 16, 13, '%'], west: [13, 7, 15, 10, '%'], east: [13, 7, 15, 10, '%'] } },
  { from: [14, 12, 9], to: [16, 15, 13], faces: { down: [14, 9, 16, 13, '%'], up: [14, 9, 16, 13, '%'], west: [13, 1, 15, 4, '%'], east: [13, 1, 15, 4, '%'] } },
];
// 模板元素 → SH_MODEL 元素（'%' 替换为贴图前缀并取 tile 行号）
function elsTpl(tpl, prefix) {
  return tpl.map(e => ({ from: e.from, to: e.to, rot: e.rot || null, faces: Object.fromEntries(Object.entries(e.faces).map(([f, a]) => [f, [a[0], a[1], a[2], a[3], T(a[4].replace('%', prefix))]])) }));
}
const gateB = (key, cn, tex, o = {}) => D(key, cn, Object.assign({ shape: SH_MODEL, model: (m) => ({ els: elsTpl((m & 4) ? GATE_OPEN_TPL : GATE_CLOSED_TPL, tex), rot: m & 3 }), boxes: (m) => (m & 4) ? [rotBoxXZ([0, 0, 7, 2, 24, 15], m & 3), rotBoxXZ([14, 0, 7, 16, 24, 15], m & 3)] : [rotBoxXZ([0, 0, 6, 16, 24, 10], m & 3)], tex, sound: 'wood', fam: 'gate', rotDir: true }, o));
// 压力板：原版 14x14x1（1..15, 高 1px），无碰撞（可走过），需要支撑
const plateB = (key, cn, tex, o = {}) => D(key, cn, Object.assign({ shape: SH_BOXES, boxes: () => [[1, 0, 1, 15, 1, 15]], tex, sound: 'wood', solid: false, needsSupport: true }, o));
// 按钮：原版 button.json 几何（6x2x4），按附着面旋转（meta = DIRS 下标）
const buttonB = (key, cn, tex, o = {}) => D(key, cn, Object.assign({ shape: SH_BOXES, boxes: buttonBoxes, tex, sound: 'wood', button: true, needsSupport: true, iconBoxes: [[5, 6, 6, 11, 10, 10]] }, o));
const carpetB = (key, cn, tex, o = {}) => D(key, cn, Object.assign({ shape: SH_BOXES, boxes: () => [[0, 0, 0, 16, 1, 16]], tex, hardness: 0.1, sound: 'wool', tool: 'shears' }, o));
// 铁轨：SH_FLAT 贴地平面 quad（原版 rail_flat），meta 0 南北 / 1 东西 / 6..9 弯道（rail_corner）
const railB = (key, cn, tex, o = {}) => { const b = D(key, cn, Object.assign({ shape: SH_FLAT, tex, render: 'cutout', solid: false, needsSupport: true, flatIcon: tex, sound: 'metal', rail: true }, o)); b.tex[1] = T('rail_corner'); return b; };
const __doorItems = [];
function doorB(key, cn, tex0, tex1, o = {}) {
  if (BID[key] !== undefined) return;
  D(key, cn, Object.assign({ shape: SH_BOXES, boxes: doorBoxes, tex: tex0, render: 'cutout', hardness: 3, tool: 'axe', sound: 'wood', door: true, noItem: true, drops: drop(key), texFn(face, meta) { return (meta & 8) ? T(tex1) : T(tex0); } }, o));
  // 门物品延迟注册：defItem 会占用 nextItem 计数器，若在方块 ID 分配期间调用，
  // 物品 ID 会与后续方块的自动物品 ID 冲突（v6 的物品栏显示错乱即源于此）。
  __doorItems.push([key, cn, tex0, o]);
}
const trapB = (key, cn, tex, o = {}) => D(key, cn, Object.assign({ shape: SH_BOXES, boxes: (m) => (m & 4) ? [[0, 0, 13, 16, 16, 16]] : (m & 8 ? [[0, 13, 0, 16, 16, 16]] : [[0, 0, 0, 16, 3, 16]]), tex, render: 'cutout', hardness: 3, tool: 'axe', sound: 'wood', trapdoor: true }, o));
// 作物：SH_CROP + 多阶段 texFn（meta 低 3 位 = 生长阶段）
function cropB(key, cn, stages, o = {}) {
  D(key, cn, Object.assign({ shape: SH_CROP, solid: false, hardness: 0, sound: 'grass', needsSupport: true, noItem: true, texFn(face, meta) { return T(stages[Math.min(meta & 7, stages.length - 1)]); } }, o));
}

// ---- 木系（原版家族顺序：原木/木/去皮原木/去皮木/木板/楼梯/台阶/栅栏/栅栏门/门/活板门/压力板/按钮）
// 竹系
// 菌柄系（下界木）
cubeB('oak_wood', '橡木', 'oak_log', { sound: 'wood', fuel: 300 });
logB('stripped_oak_log', '去皮橡木原木', 'stripped_oak_log', 'stripped_oak_log_top');
cubeB('stripped_oak_wood', '去皮橡木', 'stripped_oak_log', { sound: 'wood', fuel: 300 });
fenceB('oak_fence', '橡木栅栏', 'oak_planks', { hardness: 2, tool: 'axe', sound: 'wood', fuel: 300 });
gateB('oak_fence_gate', '橡木栅栏门', 'oak_planks', { hardness: 2, tool: 'axe', fuel: 300 });
plateB('oak_pressure_plate', '橡木压力板', 'oak_planks', { hardness: 0.5, tool: 'axe' });
buttonB('oak_button', '橡木按钮', 'oak_planks', { hardness: 0.5, tool: 'axe' });
cubeB('spruce_wood', '云杉木', 'spruce_log', { sound: 'wood', fuel: 300 });
logB('stripped_spruce_log', '去皮云杉原木', 'stripped_spruce_log', 'stripped_spruce_log_top');
cubeB('stripped_spruce_wood', '去皮云杉木', 'stripped_spruce_log', { sound: 'wood', fuel: 300 });
slabB('spruce_slab', '云杉木台阶', 'spruce_planks', { hardness: 2, tool: 'axe', sound: 'wood', fuel: 150 });
fenceB('spruce_fence', '云杉木栅栏', 'spruce_planks', { hardness: 2, tool: 'axe', sound: 'wood', fuel: 300 });
gateB('spruce_fence_gate', '云杉木栅栏门', 'spruce_planks', { hardness: 2, tool: 'axe', fuel: 300 });
doorB('spruce_door', '云杉木门', 'spruce_door_bottom', 'spruce_door_top');
trapB('spruce_trapdoor', '云杉木活板门', 'spruce_trapdoor');
plateB('spruce_pressure_plate', '云杉木压力板', 'spruce_planks', { hardness: 0.5, tool: 'axe' });
buttonB('spruce_button', '云杉木按钮', 'spruce_planks', { hardness: 0.5, tool: 'axe' });
cubeB('birch_wood', '白桦木', 'birch_log', { sound: 'wood', fuel: 300 });
logB('stripped_birch_log', '去皮白桦原木', 'stripped_birch_log', 'stripped_birch_log_top');
cubeB('stripped_birch_wood', '去皮白桦木', 'stripped_birch_log', { sound: 'wood', fuel: 300 });
stairB('birch_stairs', '白桦木楼梯', 'birch_planks', { hardness: 2, tool: 'axe', sound: 'wood', fuel: 300 });
fenceB('birch_fence', '白桦木栅栏', 'birch_planks', { hardness: 2, tool: 'axe', sound: 'wood', fuel: 300 });
gateB('birch_fence_gate', '白桦木栅栏门', 'birch_planks', { hardness: 2, tool: 'axe', fuel: 300 });
doorB('birch_door', '白桦木门', 'birch_door_bottom', 'birch_door_top');
trapB('birch_trapdoor', '白桦木活板门', 'birch_trapdoor');
plateB('birch_pressure_plate', '白桦木压力板', 'birch_planks', { hardness: 0.5, tool: 'axe' });
buttonB('birch_button', '白桦木按钮', 'birch_planks', { hardness: 0.5, tool: 'axe' });
logB('jungle_log', '丛林原木', 'jungle_log', 'jungle_log_top');
cubeB('jungle_wood', '丛林木', 'jungle_log', { sound: 'wood', fuel: 300 });
logB('stripped_jungle_log', '去皮丛林原木', 'stripped_jungle_log', 'stripped_jungle_log_top');
cubeB('stripped_jungle_wood', '去皮丛林木', 'stripped_jungle_log', { sound: 'wood', fuel: 300 });
stairB('jungle_stairs', '丛林木楼梯', 'jungle_planks', { hardness: 2, tool: 'axe', sound: 'wood', fuel: 300 });
slabB('jungle_slab', '丛林木台阶', 'jungle_planks', { hardness: 2, tool: 'axe', sound: 'wood', fuel: 150 });
fenceB('jungle_fence', '丛林木栅栏', 'jungle_planks', { hardness: 2, tool: 'axe', sound: 'wood', fuel: 300 });
gateB('jungle_fence_gate', '丛林木栅栏门', 'jungle_planks', { hardness: 2, tool: 'axe', fuel: 300 });
doorB('jungle_door', '丛林木门', 'jungle_door_bottom', 'jungle_door_top');
trapB('jungle_trapdoor', '丛林木活板门', 'jungle_trapdoor');
plateB('jungle_pressure_plate', '丛林木压力板', 'jungle_planks', { hardness: 0.5, tool: 'axe' });
buttonB('jungle_button', '丛林木按钮', 'jungle_planks', { hardness: 0.5, tool: 'axe' });
logB('acacia_log', '金合欢原木', 'acacia_log', 'acacia_log_top');
cubeB('acacia_wood', '金合欢木', 'acacia_log', { sound: 'wood', fuel: 300 });
logB('stripped_acacia_log', '去皮金合欢原木', 'stripped_acacia_log', 'stripped_acacia_log_top');
cubeB('stripped_acacia_wood', '去皮金合欢木', 'stripped_acacia_log', { sound: 'wood', fuel: 300 });
stairB('acacia_stairs', '金合欢木楼梯', 'acacia_planks', { hardness: 2, tool: 'axe', sound: 'wood', fuel: 300 });
slabB('acacia_slab', '金合欢木台阶', 'acacia_planks', { hardness: 2, tool: 'axe', sound: 'wood', fuel: 150 });
fenceB('acacia_fence', '金合欢木栅栏', 'acacia_planks', { hardness: 2, tool: 'axe', sound: 'wood', fuel: 300 });
gateB('acacia_fence_gate', '金合欢木栅栏门', 'acacia_planks', { hardness: 2, tool: 'axe', fuel: 300 });
doorB('acacia_door', '金合欢木门', 'acacia_door_bottom', 'acacia_door_top');
trapB('acacia_trapdoor', '金合欢木活板门', 'acacia_trapdoor');
plateB('acacia_pressure_plate', '金合欢木压力板', 'acacia_planks', { hardness: 0.5, tool: 'axe' });
buttonB('acacia_button', '金合欢木按钮', 'acacia_planks', { hardness: 0.5, tool: 'axe' });
logB('dark_oak_log', '深色橡木原木', 'dark_oak_log', 'dark_oak_log_top');
cubeB('dark_oak_wood', '深色橡木', 'dark_oak_log', { sound: 'wood', fuel: 300 });
logB('stripped_dark_oak_log', '去皮深色橡木原木', 'stripped_dark_oak_log', 'stripped_dark_oak_log_top');
cubeB('stripped_dark_oak_wood', '去皮深色橡木', 'stripped_dark_oak_log', { sound: 'wood', fuel: 300 });
stairB('dark_oak_stairs', '深色橡木楼梯', 'dark_oak_planks', { hardness: 2, tool: 'axe', sound: 'wood', fuel: 300 });
slabB('dark_oak_slab', '深色橡木台阶', 'dark_oak_planks', { hardness: 2, tool: 'axe', sound: 'wood', fuel: 150 });
fenceB('dark_oak_fence', '深色橡木栅栏', 'dark_oak_planks', { hardness: 2, tool: 'axe', sound: 'wood', fuel: 300 });
gateB('dark_oak_fence_gate', '深色橡木栅栏门', 'dark_oak_planks', { hardness: 2, tool: 'axe', fuel: 300 });
doorB('dark_oak_door', '深色橡木门', 'dark_oak_door_bottom', 'dark_oak_door_top');
trapB('dark_oak_trapdoor', '深色橡木活板门', 'dark_oak_trapdoor');
plateB('dark_oak_pressure_plate', '深色橡木压力板', 'dark_oak_planks', { hardness: 0.5, tool: 'axe' });
buttonB('dark_oak_button', '深色橡木按钮', 'dark_oak_planks', { hardness: 0.5, tool: 'axe' });
logB('mangrove_log', '红树原木', 'mangrove_log', 'mangrove_log_top');
cubeB('mangrove_wood', '红树木', 'mangrove_log', { sound: 'wood', fuel: 300 });
logB('stripped_mangrove_log', '去皮红树原木', 'stripped_mangrove_log', 'stripped_mangrove_log_top');
cubeB('stripped_mangrove_wood', '去皮红树木', 'stripped_mangrove_log', { sound: 'wood', fuel: 300 });
stairB('mangrove_stairs', '红树木楼梯', 'mangrove_planks', { hardness: 2, tool: 'axe', sound: 'wood', fuel: 300 });
slabB('mangrove_slab', '红树木台阶', 'mangrove_planks', { hardness: 2, tool: 'axe', sound: 'wood', fuel: 150 });
fenceB('mangrove_fence', '红树木栅栏', 'mangrove_planks', { hardness: 2, tool: 'axe', sound: 'wood', fuel: 300 });
gateB('mangrove_fence_gate', '红树木栅栏门', 'mangrove_planks', { hardness: 2, tool: 'axe', fuel: 300 });
doorB('mangrove_door', '红树木门', 'mangrove_door_bottom', 'mangrove_door_top');
trapB('mangrove_trapdoor', '红树木活板门', 'mangrove_trapdoor');
plateB('mangrove_pressure_plate', '红树木压力板', 'mangrove_planks', { hardness: 0.5, tool: 'axe' });
buttonB('mangrove_button', '红树木按钮', 'mangrove_planks', { hardness: 0.5, tool: 'axe' });
logB('cherry_log', '樱花原木', 'cherry_log', 'cherry_log_top');
cubeB('cherry_wood', '樱花木', 'cherry_log', { sound: 'wood', fuel: 300 });
logB('stripped_cherry_log', '去皮樱花原木', 'stripped_cherry_log', 'stripped_cherry_log_top');
cubeB('stripped_cherry_wood', '去皮樱花木', 'stripped_cherry_log', { sound: 'wood', fuel: 300 });
stairB('cherry_stairs', '樱花木楼梯', 'cherry_planks', { hardness: 2, tool: 'axe', sound: 'wood', fuel: 300 });
slabB('cherry_slab', '樱花木台阶', 'cherry_planks', { hardness: 2, tool: 'axe', sound: 'wood', fuel: 150 });
fenceB('cherry_fence', '樱花木栅栏', 'cherry_planks', { hardness: 2, tool: 'axe', sound: 'wood', fuel: 300 });
gateB('cherry_fence_gate', '樱花木栅栏门', 'cherry_planks', { hardness: 2, tool: 'axe', fuel: 300 });
doorB('cherry_door', '樱花木门', 'cherry_door_bottom', 'cherry_door_top');
trapB('cherry_trapdoor', '樱花木活板门', 'cherry_trapdoor');
plateB('cherry_pressure_plate', '樱花木压力板', 'cherry_planks', { hardness: 0.5, tool: 'axe' });
buttonB('cherry_button', '樱花木按钮', 'cherry_planks', { hardness: 0.5, tool: 'axe' });
cubeB('bamboo_block', '竹块', { top: 'bamboo_block_top', side: 'bamboo_block' }, { hardness: 2, tool: 'axe', sound: 'wood', fuel: 300 });
cubeB('stripped_bamboo_block', '去皮竹块', { top: 'stripped_bamboo_block_top', side: 'stripped_bamboo_block' }, { hardness: 2, tool: 'axe', sound: 'wood', fuel: 300 });
cubeB('bamboo_mosaic', '竹马赛克', 'bamboo_mosaic', { hardness: 2, tool: 'axe', sound: 'wood', fuel: 300 });
stairB('bamboo_mosaic_stairs', '竹马赛克楼梯', 'bamboo_mosaic', { hardness: 2, tool: 'axe', sound: 'wood', fuel: 300 });
slabB('bamboo_mosaic_slab', '竹马赛克台阶', 'bamboo_mosaic', { hardness: 2, tool: 'axe', sound: 'wood', fuel: 150 });
stairB('bamboo_stairs', '竹楼梯', 'bamboo_planks', { hardness: 2, tool: 'axe', sound: 'wood', fuel: 300 });
slabB('bamboo_slab', '竹台阶', 'bamboo_planks', { hardness: 2, tool: 'axe', sound: 'wood', fuel: 150 });
fenceB('bamboo_fence', '竹栅栏', 'bamboo_planks', { hardness: 2, tool: 'axe', sound: 'wood', fuel: 300 });
gateB('bamboo_fence_gate', '竹栅栏门', 'bamboo_fence_gate', { hardness: 2, tool: 'axe', fuel: 300 });
doorB('bamboo_door', '竹门', 'bamboo_door_bottom', 'bamboo_door_top');
trapB('bamboo_trapdoor', '竹活板门', 'bamboo_trapdoor');
plateB('bamboo_pressure_plate', '竹压力板', 'bamboo_planks', { hardness: 0.5, tool: 'axe' });
buttonB('bamboo_button', '竹按钮', 'bamboo_planks', { hardness: 0.5, tool: 'axe' });
logB('crimson_stem', '绯红菌柄', 'crimson_stem', 'crimson_stem_top', { sound: 'wood', fuel: 0 });
cubeB('crimson_hyphae', '绯红菌核', 'crimson_stem', { sound: 'wood' });
logB('stripped_crimson_stem', '去皮绯红菌柄', 'stripped_crimson_stem', 'stripped_crimson_stem_top', { sound: 'wood' });
cubeB('stripped_crimson_hyphae', '去皮绯红菌核', 'stripped_crimson_stem', { sound: 'wood' });
cubeB('crimson_planks', '绯红木板', 'crimson_planks', { hardness: 2, tool: 'axe', sound: 'wood', fuel: 300 });
stairB('crimson_stairs', '绯红木楼梯', 'crimson_planks', { hardness: 2, tool: 'axe', sound: 'wood', fuel: 300 });
slabB('crimson_slab', '绯红木台阶', 'crimson_planks', { hardness: 2, tool: 'axe', sound: 'wood', fuel: 150 });
fenceB('crimson_fence', '绯红木栅栏', 'crimson_planks', { hardness: 2, tool: 'axe', sound: 'wood', fuel: 300 });
gateB('crimson_fence_gate', '绯红木栅栏门', 'crimson_planks', { hardness: 2, tool: 'axe', fuel: 300 });
doorB('crimson_door', '绯红木门', 'crimson_door_bottom', 'crimson_door_top');
trapB('crimson_trapdoor', '绯红木活板门', 'crimson_trapdoor');
plateB('crimson_pressure_plate', '绯红木压力板', 'crimson_planks', { hardness: 0.5, tool: 'axe' });
buttonB('crimson_button', '绯红木按钮', 'crimson_planks', { hardness: 0.5, tool: 'axe' });
logB('warped_stem', '诡异菌柄', 'warped_stem', 'warped_stem_top', { sound: 'wood', fuel: 0 });
cubeB('warped_hyphae', '诡异菌核', 'warped_stem', { sound: 'wood' });
logB('stripped_warped_stem', '去皮诡异菌柄', 'stripped_warped_stem', 'stripped_warped_stem_top', { sound: 'wood' });
cubeB('stripped_warped_hyphae', '去皮诡异菌核', 'stripped_warped_stem', { sound: 'wood' });
cubeB('warped_planks', '诡异木板', 'warped_planks', { hardness: 2, tool: 'axe', sound: 'wood', fuel: 300 });
stairB('warped_stairs', '诡异木楼梯', 'warped_planks', { hardness: 2, tool: 'axe', sound: 'wood', fuel: 300 });
slabB('warped_slab', '诡异木台阶', 'warped_planks', { hardness: 2, tool: 'axe', sound: 'wood', fuel: 150 });
fenceB('warped_fence', '诡异木栅栏', 'warped_planks', { hardness: 2, tool: 'axe', sound: 'wood', fuel: 300 });
gateB('warped_fence_gate', '诡异木栅栏门', 'warped_planks', { hardness: 2, tool: 'axe', fuel: 300 });
doorB('warped_door', '诡异木门', 'warped_door_bottom', 'warped_door_top');
trapB('warped_trapdoor', '诡异木活板门', 'warped_trapdoor');
plateB('warped_pressure_plate', '诡异木压力板', 'warped_planks', { hardness: 0.5, tool: 'axe' });
buttonB('warped_button', '诡异木按钮', 'warped_planks', { hardness: 0.5, tool: 'axe' });
cubeB('nether_wart_block', '下界疣块', 'nether_wart_block', { hardness: 1, tool: 'hoe', sound: 'wool' });
cubeB('warped_wart_block', '诡异疣块', 'warped_wart_block', { hardness: 1, tool: 'hoe', sound: 'wool' });
cubeB('shroomlight', '菌光体', 'shroomlight', { light: 15, hardness: 1, sound: 'wool' });

// ---- 石头家族 ---------------------------------------------------------------
wallB('cobblestone_wall', '圆石墙', 'cobblestone', { hardness: 2, tool: 'pickaxe', needsTool: true });
stairB('mossy_cobblestone_stairs', '苔石楼梯', 'mossy_cobblestone', { hardness: 2, tool: 'pickaxe', needsTool: true });
slabB('mossy_cobblestone_slab', '苔石台阶', 'mossy_cobblestone', { hardness: 2, tool: 'pickaxe', needsTool: true });
wallB('mossy_cobblestone_wall', '苔石墙', 'mossy_cobblestone', { hardness: 2, tool: 'pickaxe', needsTool: true });
stairB('granite_stairs', '花岗岩楼梯', 'granite', { hardness: 2, tool: 'pickaxe', needsTool: true });
slabB('granite_slab', '花岗岩台阶', 'granite', { hardness: 2, tool: 'pickaxe', needsTool: true });
wallB('granite_wall', '花岗岩墙', 'granite', { hardness: 2, tool: 'pickaxe', needsTool: true });
stairB('diorite_stairs', '闪长岩楼梯', 'diorite', { hardness: 2, tool: 'pickaxe', needsTool: true });
slabB('diorite_slab', '闪长岩台阶', 'diorite', { hardness: 2, tool: 'pickaxe', needsTool: true });
wallB('diorite_wall', '闪长岩墙', 'diorite', { hardness: 2, tool: 'pickaxe', needsTool: true });
stairB('andesite_stairs', '安山岩楼梯', 'andesite', { hardness: 2, tool: 'pickaxe', needsTool: true });
slabB('andesite_slab', '安山岩台阶', 'andesite', { hardness: 2, tool: 'pickaxe', needsTool: true });
wallB('andesite_wall', '安山岩墙', 'andesite', { hardness: 2, tool: 'pickaxe', needsTool: true });
stairB('tuff_stairs', '凝灰岩楼梯', 'tuff', { hardness: 2, tool: 'pickaxe', needsTool: true });
slabB('tuff_slab', '凝灰岩台阶', 'tuff', { hardness: 2, tool: 'pickaxe', needsTool: true });
wallB('tuff_wall', '凝灰岩墙', 'tuff', { hardness: 2, tool: 'pickaxe', needsTool: true });
stairB('stone_stairs', '石头楼梯', 'stone', { hardness: 1.5, tool: 'pickaxe', needsTool: true });
slabB('stone_slab', '石头台阶', 'stone', { hardness: 2, tool: 'pickaxe', needsTool: true });
plateB('stone_pressure_plate', '石头压力板', 'stone', { hardness: 0.5, tool: 'pickaxe', needsTool: true, sound: 'stone' });
buttonB('stone_button', '石头按钮', 'stone', { hardness: 0.5, tool: 'pickaxe', needsTool: true, sound: 'stone' });
cubeB('packed_mud', '泥坯', 'packed_mud', { hardness: 1, tool: 'pickaxe', needsTool: true });
cubeB('smooth_sandstone', '平滑砂岩', 'sandstone_top', { hardness: 2, tool: 'pickaxe', needsTool: true });
slabB('smooth_sandstone_slab', '平滑砂岩台阶', 'sandstone_top', { hardness: 2, tool: 'pickaxe', needsTool: true });
cubeB('cut_sandstone', '切制砂岩', 'cut_sandstone', { hardness: 0.8, tool: 'pickaxe', needsTool: true });
slabB('cut_sandstone_slab', '切制砂岩台阶', 'cut_sandstone', { hardness: 0.8, tool: 'pickaxe', needsTool: true });
cubeB('chiseled_sandstone', '雕纹砂岩', 'chiseled_sandstone', { hardness: 0.8, tool: 'pickaxe', needsTool: true });
stairB('sandstone_stairs', '砂岩楼梯', { top: 'sandstone_top', bottom: 'sandstone_bottom', side: 'sandstone' }, { hardness: 0.8, tool: 'pickaxe', needsTool: true });
slabB('sandstone_slab', '砂岩台阶', { top: 'sandstone_top', bottom: 'sandstone_bottom', side: 'sandstone' }, { hardness: 0.8, tool: 'pickaxe', needsTool: true });
wallB('sandstone_wall', '砂岩墙', { top: 'sandstone_top', bottom: 'sandstone_bottom', side: 'sandstone' }, { hardness: 0.8, tool: 'pickaxe', needsTool: true });
cubeB('smooth_red_sandstone', '平滑红砂岩', 'red_sandstone_top', { hardness: 2, tool: 'pickaxe', needsTool: true });
slabB('smooth_red_sandstone_slab', '平滑红砂岩台阶', 'red_sandstone_top', { hardness: 2, tool: 'pickaxe', needsTool: true });
cubeB('cut_red_sandstone', '切制红砂岩', 'cut_red_sandstone', { hardness: 0.8, tool: 'pickaxe', needsTool: true });
slabB('cut_red_sandstone_slab', '切制红砂岩台阶', 'cut_red_sandstone', { hardness: 0.8, tool: 'pickaxe', needsTool: true });
cubeB('chiseled_red_sandstone', '雕纹红砂岩', 'chiseled_red_sandstone', { hardness: 0.8, tool: 'pickaxe', needsTool: true });
stairB('red_sandstone_stairs', '红砂岩楼梯', { top: 'red_sandstone_top', bottom: 'red_sandstone_bottom', side: 'red_sandstone' }, { hardness: 0.8, tool: 'pickaxe', needsTool: true });
slabB('red_sandstone_slab', '红砂岩台阶', { top: 'red_sandstone_top', bottom: 'red_sandstone_bottom', side: 'red_sandstone' }, { hardness: 0.8, tool: 'pickaxe', needsTool: true });
wallB('red_sandstone_wall', '红砂岩墙', { top: 'red_sandstone_top', bottom: 'red_sandstone_bottom', side: 'red_sandstone' }, { hardness: 0.8, tool: 'pickaxe', needsTool: true });
cubeB('cobbled_deepslate', '深板岩圆石', 'cobbled_deepslate', { hardness: 3.5, tool: 'pickaxe', level: 1, needsTool: true });
stairB('cobbled_deepslate_stairs', '深板岩圆石楼梯', 'cobbled_deepslate', { hardness: 3.5, tool: 'pickaxe', level: 1, needsTool: true });
slabB('cobbled_deepslate_slab', '深板岩圆石台阶', 'cobbled_deepslate', { hardness: 3.5, tool: 'pickaxe', level: 1, needsTool: true });
wallB('cobbled_deepslate_wall', '深板岩圆石墙', 'cobbled_deepslate', { hardness: 3.5, tool: 'pickaxe', level: 1, needsTool: true });
cubeB('polished_deepslate', '磨制深板岩', 'polished_deepslate', { hardness: 3.5, tool: 'pickaxe', level: 1, needsTool: true });
stairB('polished_deepslate_stairs', '磨制深板岩楼梯', 'polished_deepslate', { hardness: 3.5, tool: 'pickaxe', level: 1, needsTool: true });
slabB('polished_deepslate_slab', '磨制深板岩台阶', 'polished_deepslate', { hardness: 3.5, tool: 'pickaxe', level: 1, needsTool: true });
wallB('polished_deepslate_wall', '磨制深板岩墙', 'polished_deepslate', { hardness: 3.5, tool: 'pickaxe', level: 1, needsTool: true });
cubeB('deepslate_bricks', '深板岩砖', 'deepslate_bricks', { hardness: 3.5, tool: 'pickaxe', level: 1, needsTool: true });
stairB('deepslate_brick_stairs', '深板岩砖楼梯', 'deepslate_bricks', { hardness: 3.5, tool: 'pickaxe', level: 1, needsTool: true });
slabB('deepslate_brick_slab', '深板岩砖台阶', 'deepslate_bricks', { hardness: 3.5, tool: 'pickaxe', level: 1, needsTool: true });
wallB('deepslate_brick_wall', '深板岩砖墙', 'deepslate_bricks', { hardness: 3.5, tool: 'pickaxe', level: 1, needsTool: true });
cubeB('deepslate_tiles', '深板岩瓦', 'deepslate_tiles', { hardness: 3.5, tool: 'pickaxe', level: 1, needsTool: true });
stairB('deepslate_tile_stairs', '深板岩瓦楼梯', 'deepslate_tiles', { hardness: 3.5, tool: 'pickaxe', level: 1, needsTool: true });
slabB('deepslate_tile_slab', '深板岩瓦台阶', 'deepslate_tiles', { hardness: 3.5, tool: 'pickaxe', level: 1, needsTool: true });
wallB('deepslate_tile_wall', '深板岩瓦墙', 'deepslate_tiles', { hardness: 3.5, tool: 'pickaxe', level: 1, needsTool: true });
cubeB('chiseled_deepslate', '雕纹深板岩', 'chiseled_deepslate', { hardness: 3.5, tool: 'pickaxe', level: 1, needsTool: true });
cubeB('cracked_deepslate_bricks', '裂纹深板岩砖', 'cracked_deepslate_bricks', { hardness: 3.5, tool: 'pickaxe', level: 1, needsTool: true });
cubeB('cracked_deepslate_tiles', '裂纹深板岩瓦', 'cracked_deepslate_tiles', { hardness: 3.5, tool: 'pickaxe', level: 1, needsTool: true });
cubeTS('reinforced_deepslate', '强化深板岩', 'reinforced_deepslate_top', 'reinforced_deepslate_side', { hardness: 55, tool: 'pickaxe', level: 3, needsTool: true });
cubeB('deepslate_copper_ore', '深层铜矿石', 'deepslate_copper_ore', { hardness: 4.5, tool: 'pickaxe', level: 1, needsTool: true, drops: drop('raw_copper', 2) });
cubeB('deepslate_redstone_ore', '深层红石矿石', 'deepslate_redstone_ore', { hardness: 4.5, tool: 'pickaxe', level: 2, needsTool: true, drops: (m, r) => [['redstone', 4 + (r() * 2 | 0)]] });
cubeB('deepslate_emerald_ore', '深层绿宝石矿石', 'deepslate_emerald_ore', { hardness: 4.5, tool: 'pickaxe', level: 2, needsTool: true, drops: drop('emerald') });
cubeB('deepslate_lapis_ore', '深层青金石矿石', 'deepslate_lapis_ore', { hardness: 4.5, tool: 'pickaxe', level: 1, needsTool: true, drops: (m, r) => [['lapis_lazuli', 4 + (r() * 5 | 0)]] });
cubeB('chiseled_tuff', '雕纹凝灰岩', 'chiseled_tuff', { hardness: 1.5, tool: 'pickaxe', needsTool: true });
cubeB('tuff_bricks', '凝灰岩砖', 'tuff_bricks', { hardness: 1.5, tool: 'pickaxe', needsTool: true });
stairB('tuff_brick_stairs', '凝灰岩砖楼梯', 'tuff_bricks', { hardness: 1.5, tool: 'pickaxe', needsTool: true });
slabB('tuff_brick_slab', '凝灰岩砖台阶', 'tuff_bricks', { hardness: 1.5, tool: 'pickaxe', needsTool: true });
wallB('tuff_brick_wall', '凝灰岩砖墙', 'tuff_bricks', { hardness: 1.5, tool: 'pickaxe', needsTool: true });
cubeB('chiseled_tuff_bricks', '雕纹凝灰岩砖', 'chiseled_tuff_bricks', { hardness: 1.5, tool: 'pickaxe', needsTool: true });
cubeB('polished_tuff', '磨制凝灰岩', 'polished_tuff', { hardness: 1.5, tool: 'pickaxe', needsTool: true });
stairB('polished_tuff_stairs', '磨制凝灰岩楼梯', 'polished_tuff', { hardness: 1.5, tool: 'pickaxe', needsTool: true });
slabB('polished_tuff_slab', '磨制凝灰岩台阶', 'polished_tuff', { hardness: 1.5, tool: 'pickaxe', needsTool: true });
wallB('polished_tuff_wall', '磨制凝灰岩墙', 'polished_tuff', { hardness: 1.5, tool: 'pickaxe', needsTool: true });
wallB('stone_brick_wall', '石砖墙', 'stone_bricks', { hardness: 1.5, tool: 'pickaxe', needsTool: true });
stairB('mossy_stone_brick_stairs', '苔石砖楼梯', 'mossy_stone_bricks', { hardness: 1.5, tool: 'pickaxe', needsTool: true });
slabB('mossy_stone_brick_slab', '苔石砖台阶', 'mossy_stone_bricks', { hardness: 1.5, tool: 'pickaxe', needsTool: true });
wallB('mossy_stone_brick_wall', '苔石砖墙', 'mossy_stone_bricks', { hardness: 1.5, tool: 'pickaxe', needsTool: true });
slabB('brick_slab', '红砖台阶', 'bricks', { hardness: 2, tool: 'pickaxe', needsTool: true });
wallB('brick_wall', '红砖墙', 'bricks', { hardness: 2, tool: 'pickaxe', needsTool: true });
stairB('mud_brick_stairs', '泥砖楼梯', 'mud_bricks', { hardness: 1.5, tool: 'pickaxe', needsTool: true });
slabB('mud_brick_slab', '泥砖台阶', 'mud_bricks', { hardness: 1.5, tool: 'pickaxe', needsTool: true });
wallB('mud_brick_wall', '泥砖墙', 'mud_bricks', { hardness: 1.5, tool: 'pickaxe', needsTool: true });
stairB('polished_granite_stairs', '磨制花岗岩楼梯', 'polished_granite', { hardness: 2, tool: 'pickaxe', needsTool: true });
slabB('polished_granite_slab', '磨制花岗岩台阶', 'polished_granite', { hardness: 2, tool: 'pickaxe', needsTool: true });
stairB('polished_diorite_stairs', '磨制闪长岩楼梯', 'polished_diorite', { hardness: 2, tool: 'pickaxe', needsTool: true });
slabB('polished_diorite_slab', '磨制闪长岩台阶', 'polished_diorite', { hardness: 2, tool: 'pickaxe', needsTool: true });
stairB('polished_andesite_stairs', '磨制安山岩楼梯', 'polished_andesite', { hardness: 2, tool: 'pickaxe', needsTool: true });
slabB('polished_andesite_slab', '磨制安山岩台阶', 'polished_andesite', { hardness: 2, tool: 'pickaxe', needsTool: true });
cubeB('mangrove_planks', '红树木板', 'mangrove_planks', { hardness: 2, tool: 'axe', sound: 'wood', fuel: 300 });
cubeB('bamboo_planks', '竹板', 'bamboo_planks', { hardness: 2, tool: 'axe', sound: 'wood', fuel: 300 });
cubeB('tuff', '凝灰岩', 'tuff', { hardness: 1.5, tool: 'pickaxe', needsTool: true });
stairB('prismarine_stairs', '海晶石楼梯', 'prismarine', { hardness: 1.5, tool: 'pickaxe', needsTool: true });
slabB('prismarine_slab', '海晶石台阶', 'prismarine', { hardness: 1.5, tool: 'pickaxe', needsTool: true });
wallB('prismarine_wall', '海晶石墙', 'prismarine', { hardness: 1.5, tool: 'pickaxe', needsTool: true });
cubeB('prismarine_bricks', '海晶石砖', 'prismarine_bricks', { hardness: 1.5, tool: 'pickaxe', needsTool: true });
stairB('prismarine_brick_stairs', '海晶石砖楼梯', 'prismarine_bricks', { hardness: 1.5, tool: 'pickaxe', needsTool: true });
slabB('prismarine_brick_slab', '海晶石砖台阶', 'prismarine_bricks', { hardness: 1.5, tool: 'pickaxe', needsTool: true });
cubeB('dark_prismarine', '暗海晶石', 'dark_prismarine', { hardness: 1.5, tool: 'pickaxe', needsTool: true });
stairB('dark_prismarine_stairs', '暗海晶石楼梯', 'dark_prismarine', { hardness: 1.5, tool: 'pickaxe', needsTool: true });
slabB('dark_prismarine_slab', '暗海晶石台阶', 'dark_prismarine', { hardness: 1.5, tool: 'pickaxe', needsTool: true });
cubeB('netherrack', '下界岩', 'netherrack', { hardness: 0.4, tool: 'pickaxe', needsTool: true, sound: 'stone' });
cubeB('nether_bricks', '下界砖块', 'nether_bricks', { hardness: 2, tool: 'pickaxe', needsTool: true });
stairB('nether_brick_stairs', '下界砖楼梯', 'nether_bricks', { hardness: 2, tool: 'pickaxe', needsTool: true });
slabB('nether_brick_slab', '下界砖台阶', 'nether_bricks', { hardness: 2, tool: 'pickaxe', needsTool: true });
wallB('nether_brick_wall', '下界砖墙', 'nether_bricks', { hardness: 2, tool: 'pickaxe', needsTool: true });
fenceB('nether_brick_fence', '下界砖栅栏', 'nether_bricks', { hardness: 2, tool: 'pickaxe', needsTool: true });
cubeB('cracked_nether_bricks', '裂纹下界砖块', 'cracked_nether_bricks', { hardness: 2, tool: 'pickaxe', needsTool: true });
cubeB('chiseled_nether_bricks', '雕纹下界砖块', 'chiseled_nether_bricks', { hardness: 2, tool: 'pickaxe', needsTool: true });
cubeB('red_nether_bricks', '红色下界砖块', 'red_nether_bricks', { hardness: 2, tool: 'pickaxe', needsTool: true });
cubeB('nether_gold_ore', '下界金矿石', 'nether_gold_ore', { hardness: 3, tool: 'pickaxe', level: 1, needsTool: true, drops: (m, r) => [['gold_ingot', 2 + (r() * 3 | 0)]] });
cubeB('nether_quartz_ore', '下界石英矿石', 'nether_quartz_ore', { hardness: 3, tool: 'pickaxe', level: 1, needsTool: true, drops: (m, r) => [['quartz', 1 + (r() * 2 | 0)]] });
cubeTS('ancient_debris', '远古残骸', 'ancient_debris_top', 'ancient_debris_side', { hardness: 30, tool: 'pickaxe', level: 3, needsTool: true });
cubeB('netherite_block', '下界合金块', 'netherite_block', { hardness: 50, tool: 'pickaxe', level: 3, needsTool: true, sound: 'metal' });
logB('basalt', '玄武岩', 'basalt_side', 'basalt_top', { hardness: 1.25, tool: 'pickaxe', needsTool: true, sound: 'stone', fuel: 0 });
logB('polished_basalt', '磨制玄武岩', 'polished_basalt_side', 'polished_basalt_top', { hardness: 1.25, tool: 'pickaxe', needsTool: true, sound: 'stone', fuel: 0 });
cubeB('smooth_basalt', '平滑玄武岩', 'smooth_basalt', { hardness: 1.25, tool: 'pickaxe', needsTool: true, sound: 'stone' });
cubeB('blackstone', '黑石', { top: 'blackstone_top', side: 'blackstone' }, { hardness: 1.5, tool: 'pickaxe', needsTool: true, sound: 'stone' });
stairB('blackstone_stairs', '黑石楼梯', 'blackstone', { hardness: 1.5, tool: 'pickaxe', needsTool: true });
slabB('blackstone_slab', '黑石台阶', 'blackstone', { hardness: 1.5, tool: 'pickaxe', needsTool: true });
wallB('blackstone_wall', '黑石墙', 'blackstone', { hardness: 1.5, tool: 'pickaxe', needsTool: true });
cubeB('gilded_blackstone', '镶金黑石', 'gilded_blackstone', { hardness: 1.5, tool: 'pickaxe', needsTool: true, drops: (m, r) => r() < 0.1 ? [['gold_ingot', 1]] : [['blackstone', 1]] });
cubeB('chiseled_polished_blackstone', '雕纹磨制黑石', 'chiseled_polished_blackstone', { hardness: 1.5, tool: 'pickaxe', needsTool: true });
cubeB('polished_blackstone', '磨制黑石', 'polished_blackstone', { hardness: 2, tool: 'pickaxe', needsTool: true });
stairB('polished_blackstone_stairs', '磨制黑石楼梯', 'polished_blackstone', { hardness: 2, tool: 'pickaxe', needsTool: true });
slabB('polished_blackstone_slab', '磨制黑石台阶', 'polished_blackstone', { hardness: 2, tool: 'pickaxe', needsTool: true });
wallB('polished_blackstone_wall', '磨制黑石墙', 'polished_blackstone', { hardness: 2, tool: 'pickaxe', needsTool: true });
plateB('polished_blackstone_pressure_plate', '磨制黑石压力板', 'polished_blackstone', { hardness: 0.5, tool: 'pickaxe', needsTool: true, sound: 'stone' });
buttonB('polished_blackstone_button', '磨制黑石按钮', 'polished_blackstone', { hardness: 0.5, tool: 'pickaxe', needsTool: true, sound: 'stone' });
cubeB('polished_blackstone_bricks', '磨制黑石砖', 'polished_blackstone_bricks', { hardness: 2, tool: 'pickaxe', needsTool: true });
stairB('polished_blackstone_brick_stairs', '磨制黑石砖楼梯', 'polished_blackstone_bricks', { hardness: 2, tool: 'pickaxe', needsTool: true });
slabB('polished_blackstone_brick_slab', '磨制黑石砖台阶', 'polished_blackstone_bricks', { hardness: 2, tool: 'pickaxe', needsTool: true });
wallB('polished_blackstone_brick_wall', '磨制黑石砖墙', 'polished_blackstone_bricks', { hardness: 2, tool: 'pickaxe', needsTool: true });
cubeB('cracked_polished_blackstone_bricks', '裂纹磨制黑石砖', 'cracked_polished_blackstone_bricks', { hardness: 2, tool: 'pickaxe', needsTool: true });
cubeB('end_stone_bricks', '末地石砖', 'end_stone_bricks', { hardness: 3, tool: 'pickaxe', needsTool: true });
stairB('end_stone_brick_stairs', '末地石砖楼梯', 'end_stone_bricks', { hardness: 3, tool: 'pickaxe', needsTool: true });
slabB('end_stone_brick_slab', '末地石砖台阶', 'end_stone_bricks', { hardness: 3, tool: 'pickaxe', needsTool: true });
wallB('end_stone_brick_wall', '末地石砖墙', 'end_stone_bricks', { hardness: 3, tool: 'pickaxe', needsTool: true });
cubeB('purpur_block', '紫珀块', 'purpur_block', { hardness: 1.5, tool: 'pickaxe', needsTool: true });
stairB('purpur_stairs', '紫珀楼梯', 'purpur_block', { hardness: 1.5, tool: 'pickaxe', needsTool: true });
slabB('purpur_slab', '紫珀台阶', 'purpur_block', { hardness: 1.5, tool: 'pickaxe', needsTool: true });
logB('purpur_pillar', '紫珀柱', 'purpur_block', 'purpur_pillar_top', { hardness: 1.5, tool: 'pickaxe', needsTool: true, sound: 'stone', fuel: 0 });
cubeB('raw_iron_block', '粗铁块', 'raw_iron_block', { hardness: 5, tool: 'pickaxe', level: 1, needsTool: true, sound: 'metal' });
cubeB('raw_copper_block', '粗铜块', 'raw_copper_block', { hardness: 5, tool: 'pickaxe', level: 1, needsTool: true, sound: 'metal' });
cubeB('raw_gold_block', '粗金块', 'raw_gold_block', { hardness: 5, tool: 'pickaxe', level: 1, needsTool: true, sound: 'metal' });
cubeB('copper_ore', '铜矿石', 'copper_ore', { hardness: 3, tool: 'pickaxe', level: 1, needsTool: true, drops: drop('raw_copper', 2) });
D('iron_bars', '铁栏杆', { shape: SH_BOXES, boxes: () => [[7, 0, 7, 9, 16, 9]], tex: 'iron_bars', render: 'cutout', hardness: 5, tool: 'pickaxe', needsTool: true, sound: 'metal', fam: 'pane', iconBoxes: [[7, 0, 7, 9, 16, 9]] });
// 锁链：原版 chain.json = 两块绕 Y 轴旋转 45° 的斜向链板（独立 UV）
// meta 0 = 竖直 / 1 = 沿 X 轴 / 2 = 沿 Z 轴
const CHAIN_TPL = [
  { from: [6.5, 0, 8], to: [9.5, 16, 8], rot: { origin: [8, 8, 8], axis: 'y', angle: 45 }, faces: { north: [3, 0, 0, 16, 'chain'], south: [0, 0, 3, 16, 'chain'] } },
  { from: [8, 0, 6.5], to: [8, 16, 9.5], rot: { origin: [8, 8, 8], axis: 'y', angle: 45 }, faces: { west: [6, 0, 3, 16, 'chain'], east: [3, 0, 6, 16, 'chain'] } },
];
D('chain', '锁链', { shape: SH_MODEL,
  model: (m) => { const a = m & 3; return Object.assign({ els: elsTpl(CHAIN_TPL, 'chain'), rot: 0 }, a === 1 ? { tiltZ: 90 } : a === 2 ? { tiltX: 90 } : {}); },
  boxes: (m) => (m & 3) === 1 ? [[0, 6, 6, 16, 10, 10]] : (m & 3) === 2 ? [[6, 6, 0, 10, 10, 16]] : [[6, 0, 6, 10, 16, 10]],
  tex: 'chain', render: 'cutout', hardness: 5, tool: 'pickaxe', needsTool: true, sound: 'metal' });

cubeB('copper_block', '铜块', 'copper_block', { hardness: 3, tool: 'pickaxe', level: 1, needsTool: true, sound: 'metal' });
cubeB('chiseled_copper', '雕纹铜块', 'chiseled_copper', { hardness: 3, tool: 'pickaxe', level: 1, needsTool: true, sound: 'metal' });
cubeB('cut_copper', '切制铜块', 'cut_copper', { hardness: 3, tool: 'pickaxe', level: 1, needsTool: true, sound: 'metal' });
stairB('cut_copper_stairs', '切制铜楼梯', 'cut_copper', { hardness: 3, tool: 'pickaxe', level: 1, needsTool: true });
slabB('cut_copper_slab', '切制铜台阶', 'cut_copper', { hardness: 3, tool: 'pickaxe', level: 1, needsTool: true });
D('copper_grate', '铜格栅', { shape: SH_CUBE, tex: 'copper_grate', render: 'cutout', hardness: 3, tool: 'pickaxe', level: 1, needsTool: true, sound: 'metal', cullSame: true });
cubeB('waxed_copper_block', '涂蜡的铜块', 'copper_block', { hardness: 3, tool: 'pickaxe', level: 1, needsTool: true, sound: 'metal' });
cubeB('waxed_chiseled_copper', '涂蜡的雕纹铜块', 'chiseled_copper', { hardness: 3, tool: 'pickaxe', level: 1, needsTool: true, sound: 'metal' });
cubeB('waxed_cut_copper', '涂蜡的切制铜块', 'cut_copper', { hardness: 3, tool: 'pickaxe', level: 1, needsTool: true, sound: 'metal' });
stairB('waxed_cut_copper_stairs', '涂蜡的切制铜楼梯', 'cut_copper', { hardness: 3, tool: 'pickaxe', level: 1, needsTool: true });
slabB('waxed_cut_copper_slab', '涂蜡的切制铜台阶', 'cut_copper', { hardness: 3, tool: 'pickaxe', level: 1, needsTool: true });
D('waxed_copper_grate', '涂蜡的铜格栅', { shape: SH_CUBE, tex: 'copper_grate', render: 'cutout', hardness: 3, tool: 'pickaxe', level: 1, needsTool: true, sound: 'metal', cullSame: true });
cubeB('exposed_copper', '斑驳的铜块', 'exposed_copper', { hardness: 3, tool: 'pickaxe', level: 1, needsTool: true, sound: 'metal' });
cubeB('exposed_chiseled_copper', '斑驳的雕纹铜块', 'exposed_chiseled_copper', { hardness: 3, tool: 'pickaxe', level: 1, needsTool: true, sound: 'metal' });
cubeB('exposed_cut_copper', '斑驳的切制铜块', 'exposed_cut_copper', { hardness: 3, tool: 'pickaxe', level: 1, needsTool: true, sound: 'metal' });
stairB('exposed_cut_copper_stairs', '斑驳的切制铜楼梯', 'exposed_cut_copper', { hardness: 3, tool: 'pickaxe', level: 1, needsTool: true });
slabB('exposed_cut_copper_slab', '斑驳的切制铜台阶', 'exposed_cut_copper', { hardness: 3, tool: 'pickaxe', level: 1, needsTool: true });
D('exposed_copper_grate', '斑驳的铜格栅', { shape: SH_CUBE, tex: 'exposed_copper_grate', render: 'cutout', hardness: 3, tool: 'pickaxe', level: 1, needsTool: true, sound: 'metal', cullSame: true });
cubeB('waxed_exposed_copper', '涂蜡的斑驳铜块', 'exposed_copper', { hardness: 3, tool: 'pickaxe', level: 1, needsTool: true, sound: 'metal' });
cubeB('waxed_exposed_chiseled_copper', '涂蜡的斑驳雕纹铜块', 'exposed_chiseled_copper', { hardness: 3, tool: 'pickaxe', level: 1, needsTool: true, sound: 'metal' });
cubeB('waxed_exposed_cut_copper', '涂蜡的斑驳切制铜块', 'exposed_cut_copper', { hardness: 3, tool: 'pickaxe', level: 1, needsTool: true, sound: 'metal' });
stairB('waxed_exposed_cut_copper_stairs', '涂蜡的斑驳切制铜楼梯', 'exposed_cut_copper', { hardness: 3, tool: 'pickaxe', level: 1, needsTool: true });
slabB('waxed_exposed_cut_copper_slab', '涂蜡的斑驳切制铜台阶', 'exposed_cut_copper', { hardness: 3, tool: 'pickaxe', level: 1, needsTool: true });
D('waxed_exposed_copper_grate', '涂蜡的斑驳铜格栅', { shape: SH_CUBE, tex: 'exposed_copper_grate', render: 'cutout', hardness: 3, tool: 'pickaxe', level: 1, needsTool: true, sound: 'metal', cullSame: true });
cubeB('weathered_copper', '锈蚀的铜块', 'weathered_copper', { hardness: 3, tool: 'pickaxe', level: 1, needsTool: true, sound: 'metal' });
cubeB('weathered_chiseled_copper', '锈蚀的雕纹铜块', 'weathered_chiseled_copper', { hardness: 3, tool: 'pickaxe', level: 1, needsTool: true, sound: 'metal' });
cubeB('weathered_cut_copper', '锈蚀的切制铜块', 'weathered_cut_copper', { hardness: 3, tool: 'pickaxe', level: 1, needsTool: true, sound: 'metal' });
stairB('weathered_cut_copper_stairs', '锈蚀的切制铜楼梯', 'weathered_cut_copper', { hardness: 3, tool: 'pickaxe', level: 1, needsTool: true });
slabB('weathered_cut_copper_slab', '锈蚀的切制铜台阶', 'weathered_cut_copper', { hardness: 3, tool: 'pickaxe', level: 1, needsTool: true });
D('weathered_copper_grate', '锈蚀的铜格栅', { shape: SH_CUBE, tex: 'weathered_copper_grate', render: 'cutout', hardness: 3, tool: 'pickaxe', level: 1, needsTool: true, sound: 'metal', cullSame: true });
cubeB('waxed_weathered_copper', '涂蜡的锈蚀铜块', 'weathered_copper', { hardness: 3, tool: 'pickaxe', level: 1, needsTool: true, sound: 'metal' });
cubeB('waxed_weathered_chiseled_copper', '涂蜡的锈蚀雕纹铜块', 'weathered_chiseled_copper', { hardness: 3, tool: 'pickaxe', level: 1, needsTool: true, sound: 'metal' });
cubeB('waxed_weathered_cut_copper', '涂蜡的锈蚀切制铜块', 'weathered_cut_copper', { hardness: 3, tool: 'pickaxe', level: 1, needsTool: true, sound: 'metal' });
stairB('waxed_weathered_cut_copper_stairs', '涂蜡的锈蚀切制铜楼梯', 'weathered_cut_copper', { hardness: 3, tool: 'pickaxe', level: 1, needsTool: true });
slabB('waxed_weathered_cut_copper_slab', '涂蜡的锈蚀切制铜台阶', 'weathered_cut_copper', { hardness: 3, tool: 'pickaxe', level: 1, needsTool: true });
D('waxed_weathered_copper_grate', '涂蜡的锈蚀铜格栅', { shape: SH_CUBE, tex: 'weathered_copper_grate', render: 'cutout', hardness: 3, tool: 'pickaxe', level: 1, needsTool: true, sound: 'metal', cullSame: true });
cubeB('oxidized_copper', '氧化的铜块', 'oxidized_copper', { hardness: 3, tool: 'pickaxe', level: 1, needsTool: true, sound: 'metal' });
cubeB('oxidized_chiseled_copper', '氧化的雕纹铜块', 'oxidized_chiseled_copper', { hardness: 3, tool: 'pickaxe', level: 1, needsTool: true, sound: 'metal' });
cubeB('oxidized_cut_copper', '氧化的切制铜块', 'oxidized_cut_copper', { hardness: 3, tool: 'pickaxe', level: 1, needsTool: true, sound: 'metal' });
stairB('oxidized_cut_copper_stairs', '氧化的切制铜楼梯', 'oxidized_cut_copper', { hardness: 3, tool: 'pickaxe', level: 1, needsTool: true });
slabB('oxidized_cut_copper_slab', '氧化的切制铜台阶', 'oxidized_cut_copper', { hardness: 3, tool: 'pickaxe', level: 1, needsTool: true });
D('oxidized_copper_grate', '氧化的铜格栅', { shape: SH_CUBE, tex: 'oxidized_copper_grate', render: 'cutout', hardness: 3, tool: 'pickaxe', level: 1, needsTool: true, sound: 'metal', cullSame: true });
cubeB('waxed_oxidized_copper', '涂蜡的氧化铜块', 'oxidized_copper', { hardness: 3, tool: 'pickaxe', level: 1, needsTool: true, sound: 'metal' });
cubeB('waxed_oxidized_chiseled_copper', '涂蜡的氧化雕纹铜块', 'oxidized_chiseled_copper', { hardness: 3, tool: 'pickaxe', level: 1, needsTool: true, sound: 'metal' });
cubeB('waxed_oxidized_cut_copper', '涂蜡的氧化切制铜块', 'oxidized_cut_copper', { hardness: 3, tool: 'pickaxe', level: 1, needsTool: true, sound: 'metal' });
stairB('waxed_oxidized_cut_copper_stairs', '涂蜡的氧化切制铜楼梯', 'oxidized_cut_copper', { hardness: 3, tool: 'pickaxe', level: 1, needsTool: true });
slabB('waxed_oxidized_cut_copper_slab', '涂蜡的氧化切制铜台阶', 'oxidized_cut_copper', { hardness: 3, tool: 'pickaxe', level: 1, needsTool: true });
D('waxed_oxidized_copper_grate', '涂蜡的氧化铜格栅', { shape: SH_CUBE, tex: 'oxidized_copper_grate', render: 'cutout', hardness: 3, tool: 'pickaxe', level: 1, needsTool: true, sound: 'metal', cullSame: true });
cubeB('copper_bulb', '铜灯', 'copper_bulb', { hardness: 3, tool: 'pickaxe', level: 1, needsTool: true, sound: 'metal' });
doorB('copper_door', '铜门', 'copper_door_bottom', 'copper_door_top', { hardness: 3, tool: 'pickaxe', needsTool: true, sound: 'metal' });
trapB('copper_trapdoor', '铜活板门', 'copper_trapdoor', { hardness: 3, tool: 'pickaxe', needsTool: true, sound: 'metal' });
cubeB('waxed_copper_bulb', '涂蜡的铜灯', 'copper_bulb', { hardness: 3, tool: 'pickaxe', level: 1, needsTool: true, sound: 'metal' });
doorB('waxed_copper_door', '涂蜡的铜门', 'copper_door_bottom', 'copper_door_top', { hardness: 3, tool: 'pickaxe', needsTool: true, sound: 'metal' });
trapB('waxed_copper_trapdoor', '涂蜡的铜活板门', 'copper_trapdoor', { hardness: 3, tool: 'pickaxe', needsTool: true, sound: 'metal' });
cubeB('exposed_copper_bulb', '斑驳的铜灯', 'exposed_copper_bulb', { hardness: 3, tool: 'pickaxe', level: 1, needsTool: true, sound: 'metal' });
doorB('exposed_copper_door', '斑驳的铜门', 'exposed_copper_door_bottom', 'exposed_copper_door_top', { hardness: 3, tool: 'pickaxe', needsTool: true, sound: 'metal' });
trapB('exposed_copper_trapdoor', '斑驳的铜活板门', 'exposed_copper_trapdoor', { hardness: 3, tool: 'pickaxe', needsTool: true, sound: 'metal' });
cubeB('waxed_exposed_copper_bulb', '涂蜡的斑驳铜灯', 'exposed_copper_bulb', { hardness: 3, tool: 'pickaxe', level: 1, needsTool: true, sound: 'metal' });
doorB('waxed_exposed_copper_door', '涂蜡的斑驳铜门', 'exposed_copper_door_bottom', 'exposed_copper_door_top', { hardness: 3, tool: 'pickaxe', needsTool: true, sound: 'metal' });
trapB('waxed_exposed_copper_trapdoor', '涂蜡的斑驳铜活板门', 'exposed_copper_trapdoor', { hardness: 3, tool: 'pickaxe', needsTool: true, sound: 'metal' });
cubeB('weathered_copper_bulb', '锈蚀的铜灯', 'weathered_copper_bulb', { hardness: 3, tool: 'pickaxe', level: 1, needsTool: true, sound: 'metal' });
doorB('weathered_copper_door', '锈蚀的铜门', 'weathered_copper_door_bottom', 'weathered_copper_door_top', { hardness: 3, tool: 'pickaxe', needsTool: true, sound: 'metal' });
trapB('weathered_copper_trapdoor', '锈蚀的铜活板门', 'weathered_copper_trapdoor', { hardness: 3, tool: 'pickaxe', needsTool: true, sound: 'metal' });
cubeB('waxed_weathered_copper_bulb', '涂蜡的锈蚀铜灯', 'weathered_copper_bulb', { hardness: 3, tool: 'pickaxe', level: 1, needsTool: true, sound: 'metal' });
doorB('waxed_weathered_copper_door', '涂蜡的锈蚀铜门', 'weathered_copper_door_bottom', 'weathered_copper_door_top', { hardness: 3, tool: 'pickaxe', needsTool: true, sound: 'metal' });
trapB('waxed_weathered_copper_trapdoor', '涂蜡的锈蚀铜活板门', 'weathered_copper_trapdoor', { hardness: 3, tool: 'pickaxe', needsTool: true, sound: 'metal' });
cubeB('oxidized_copper_bulb', '氧化的铜灯', 'oxidized_copper_bulb', { hardness: 3, tool: 'pickaxe', level: 1, needsTool: true, sound: 'metal' });
doorB('oxidized_copper_door', '氧化的铜门', 'oxidized_copper_door_bottom', 'oxidized_copper_door_top', { hardness: 3, tool: 'pickaxe', needsTool: true, sound: 'metal' });
trapB('oxidized_copper_trapdoor', '氧化的铜活板门', 'oxidized_copper_trapdoor', { hardness: 3, tool: 'pickaxe', needsTool: true, sound: 'metal' });
cubeB('waxed_oxidized_copper_bulb', '涂蜡的氧化铜灯', 'oxidized_copper_bulb', { hardness: 3, tool: 'pickaxe', level: 1, needsTool: true, sound: 'metal' });
doorB('waxed_oxidized_copper_door', '涂蜡的氧化铜门', 'oxidized_copper_door_bottom', 'oxidized_copper_door_top', { hardness: 3, tool: 'pickaxe', needsTool: true, sound: 'metal' });
trapB('waxed_oxidized_copper_trapdoor', '涂蜡的氧化铜活板门', 'oxidized_copper_trapdoor', { hardness: 3, tool: 'pickaxe', needsTool: true, sound: 'metal' });
cubeB('smooth_quartz', '平滑石英块', 'quartz_block_bottom', { hardness: 2, tool: 'pickaxe', needsTool: true });
stairB('smooth_quartz_stairs', '平滑石英楼梯', 'quartz_block_bottom', { hardness: 2, tool: 'pickaxe', needsTool: true });
slabB('smooth_quartz_slab', '平滑石英台阶', 'quartz_block_bottom', { hardness: 2, tool: 'pickaxe', needsTool: true });
cubeB('quartz_bricks', '石英砖', 'quartz_bricks', { hardness: 0.8, tool: 'pickaxe', needsTool: true });
logB('quartz_pillar', '石英柱', 'quartz_block_side', 'quartz_pillar_top', { hardness: 0.8, tool: 'pickaxe', needsTool: true, sound: 'stone', fuel: 0 });
cubeB('chiseled_quartz_block', '雕纹石英块', 'chiseled_quartz_block', { hardness: 0.8, tool: 'pickaxe', needsTool: true });
stairB('quartz_stairs', '石英楼梯', { top: 'quartz_block_top', bottom: 'quartz_block_bottom', side: 'quartz_block_side' }, { hardness: 0.8, tool: 'pickaxe', needsTool: true });
slabB('quartz_slab', '石英台阶', { top: 'quartz_block_top', bottom: 'quartz_block_bottom', side: 'quartz_block_side' }, { hardness: 0.8, tool: 'pickaxe', needsTool: true });
cubeB('amethyst_block', '紫水晶块', 'amethyst_block', { hardness: 1.5, tool: 'pickaxe', needsTool: true, sound: 'glass' });
cubeB('budding_amethyst', '紫水晶母岩', 'budding_amethyst', { hardness: 1.5, tool: 'pickaxe', needsTool: true, sound: 'glass' });
crossB('amethyst_cluster', '紫水晶簇', 'amethyst_cluster', { light: 5, sound: 'glass', needsSupport: false, drops: () => [['amethyst_shard', 4]] });
crossB('large_amethyst_bud', '大型紫晶芽', 'large_amethyst_bud', { light: 4, sound: 'glass', needsSupport: false });
crossB('medium_amethyst_bud', '中型紫晶芽', 'medium_amethyst_bud', { light: 2, sound: 'glass', needsSupport: false });
crossB('small_amethyst_bud', '小型紫晶芽', 'small_amethyst_bud', { light: 1, sound: 'glass', needsSupport: false });

// ---- 彩色方块：羊毛/地毯/陶瓦/混凝土/混凝土粉末/带釉陶瓦/玻璃/染色玻璃/玻璃板/潜影盒 ------
// 玻璃板：连接几何由 mesher famBoxes('pane') 按原版 template_glass_pane_* 生成；
// 大面（连接臂的两个宽面 / 孤立板南北面）用玻璃贴图，窄棱用 *_pane_top 边缘贴图；
// 染色玻璃板为半透明（render translucent），普通玻璃板/铁栏杆为 cutout。
// 物品栏图标 = 原版 template_glass_pane_post 立柱（2x16x2）。
function paneB(key, cn, faceTex, edgeTex, translucent) {
  D(key, cn, { shape: SH_BOXES, boxes: () => [[7, 0, 7, 9, 16, 9]], tex: edgeTex, render: translucent ? 'translucent' : 'cutout', hardness: 0.3, sound: 'glass', drops: nothing, cullSame: true, fam: 'pane', iconBoxes: [[7, 0, 7, 9, 16, 9]], paneFace: T(faceTex), paneEdge: T(edgeTex) });
}
carpetB('white_carpet', '白色地毯', 'white_wool');
carpetB('orange_carpet', '橙色地毯', 'orange_wool');
carpetB('magenta_carpet', '品红色地毯', 'magenta_wool');
carpetB('light_blue_carpet', '淡蓝色地毯', 'light_blue_wool');
carpetB('yellow_carpet', '黄色地毯', 'yellow_wool');
carpetB('lime_carpet', '黄绿色地毯', 'lime_wool');
carpetB('pink_carpet', '粉红色地毯', 'pink_wool');
carpetB('gray_carpet', '灰色地毯', 'gray_wool');
carpetB('light_gray_carpet', '淡灰色地毯', 'light_gray_wool');
carpetB('cyan_carpet', '青色地毯', 'cyan_wool');
carpetB('purple_carpet', '紫色地毯', 'purple_wool');
carpetB('blue_carpet', '蓝色地毯', 'blue_wool');
carpetB('brown_carpet', '棕色地毯', 'brown_wool');
carpetB('green_carpet', '绿色地毯', 'green_wool');
carpetB('red_carpet', '红色地毯', 'red_wool');
carpetB('black_carpet', '黑色地毯', 'black_wool');
cubeB('white_terracotta', '白色陶瓦', 'white_terracotta', { hardness: 1.25, tool: 'pickaxe', needsTool: true });
cubeB('orange_terracotta', '橙色陶瓦', 'orange_terracotta', { hardness: 1.25, tool: 'pickaxe', needsTool: true });
cubeB('magenta_terracotta', '品红色陶瓦', 'magenta_terracotta', { hardness: 1.25, tool: 'pickaxe', needsTool: true });
cubeB('light_blue_terracotta', '淡蓝色陶瓦', 'light_blue_terracotta', { hardness: 1.25, tool: 'pickaxe', needsTool: true });
cubeB('yellow_terracotta', '黄色陶瓦', 'yellow_terracotta', { hardness: 1.25, tool: 'pickaxe', needsTool: true });
cubeB('lime_terracotta', '黄绿色陶瓦', 'lime_terracotta', { hardness: 1.25, tool: 'pickaxe', needsTool: true });
cubeB('pink_terracotta', '粉红色陶瓦', 'pink_terracotta', { hardness: 1.25, tool: 'pickaxe', needsTool: true });
cubeB('gray_terracotta', '灰色陶瓦', 'gray_terracotta', { hardness: 1.25, tool: 'pickaxe', needsTool: true });
cubeB('light_gray_terracotta', '淡灰色陶瓦', 'light_gray_terracotta', { hardness: 1.25, tool: 'pickaxe', needsTool: true });
cubeB('cyan_terracotta', '青色陶瓦', 'cyan_terracotta', { hardness: 1.25, tool: 'pickaxe', needsTool: true });
cubeB('purple_terracotta', '紫色陶瓦', 'purple_terracotta', { hardness: 1.25, tool: 'pickaxe', needsTool: true });
cubeB('blue_terracotta', '蓝色陶瓦', 'blue_terracotta', { hardness: 1.25, tool: 'pickaxe', needsTool: true });
cubeB('brown_terracotta', '棕色陶瓦', 'brown_terracotta', { hardness: 1.25, tool: 'pickaxe', needsTool: true });
cubeB('green_terracotta', '绿色陶瓦', 'green_terracotta', { hardness: 1.25, tool: 'pickaxe', needsTool: true });
cubeB('red_terracotta', '红色陶瓦', 'red_terracotta', { hardness: 1.25, tool: 'pickaxe', needsTool: true });
cubeB('black_terracotta', '黑色陶瓦', 'black_terracotta', { hardness: 1.25, tool: 'pickaxe', needsTool: true });
cubeB('magenta_concrete', '品红色混凝土', 'magenta_concrete', { hardness: 1.8, tool: 'pickaxe', needsTool: true });
cubeB('pink_concrete', '粉红色混凝土', 'pink_concrete', { hardness: 1.8, tool: 'pickaxe', needsTool: true });
cubeB('light_gray_concrete', '淡灰色混凝土', 'light_gray_concrete', { hardness: 1.8, tool: 'pickaxe', needsTool: true });
cubeB('cyan_concrete', '青色混凝土', 'cyan_concrete', { hardness: 1.8, tool: 'pickaxe', needsTool: true });
cubeB('purple_concrete', '紫色混凝土', 'purple_concrete', { hardness: 1.8, tool: 'pickaxe', needsTool: true });
cubeB('brown_concrete', '棕色混凝土', 'brown_concrete', { hardness: 1.8, tool: 'pickaxe', needsTool: true });
cubeB('green_concrete', '绿色混凝土', 'green_concrete', { hardness: 1.8, tool: 'pickaxe', needsTool: true });
D('magenta_stained_glass', '品红色染色玻璃', { tex: 'magenta_stained_glass', render: 'translucent', opaque: false, hardness: 0.3, sound: 'glass', drops: nothing, cullSame: true });
D('gray_stained_glass', '灰色染色玻璃', { tex: 'gray_stained_glass', render: 'translucent', opaque: false, hardness: 0.3, sound: 'glass', drops: nothing, cullSame: true });
D('light_gray_stained_glass', '淡灰色染色玻璃', { tex: 'light_gray_stained_glass', render: 'translucent', opaque: false, hardness: 0.3, sound: 'glass', drops: nothing, cullSame: true });
D('brown_stained_glass', '棕色染色玻璃', { tex: 'brown_stained_glass', render: 'translucent', opaque: false, hardness: 0.3, sound: 'glass', drops: nothing, cullSame: true });
cubeB('white_concrete_powder', '白色混凝土粉末', 'white_concrete_powder', { hardness: 0.5, tool: 'shovel', sound: 'sand', gravity: true });
cubeB('orange_concrete_powder', '橙色混凝土粉末', 'orange_concrete_powder', { hardness: 0.5, tool: 'shovel', sound: 'sand', gravity: true });
cubeB('magenta_concrete_powder', '品红色混凝土粉末', 'magenta_concrete_powder', { hardness: 0.5, tool: 'shovel', sound: 'sand', gravity: true });
cubeB('light_blue_concrete_powder', '淡蓝色混凝土粉末', 'light_blue_concrete_powder', { hardness: 0.5, tool: 'shovel', sound: 'sand', gravity: true });
cubeB('yellow_concrete_powder', '黄色混凝土粉末', 'yellow_concrete_powder', { hardness: 0.5, tool: 'shovel', sound: 'sand', gravity: true });
cubeB('lime_concrete_powder', '黄绿色混凝土粉末', 'lime_concrete_powder', { hardness: 0.5, tool: 'shovel', sound: 'sand', gravity: true });
cubeB('pink_concrete_powder', '粉红色混凝土粉末', 'pink_concrete_powder', { hardness: 0.5, tool: 'shovel', sound: 'sand', gravity: true });
cubeB('gray_concrete_powder', '灰色混凝土粉末', 'gray_concrete_powder', { hardness: 0.5, tool: 'shovel', sound: 'sand', gravity: true });
cubeB('light_gray_concrete_powder', '淡灰色混凝土粉末', 'light_gray_concrete_powder', { hardness: 0.5, tool: 'shovel', sound: 'sand', gravity: true });
cubeB('cyan_concrete_powder', '青色混凝土粉末', 'cyan_concrete_powder', { hardness: 0.5, tool: 'shovel', sound: 'sand', gravity: true });
cubeB('purple_concrete_powder', '紫色混凝土粉末', 'purple_concrete_powder', { hardness: 0.5, tool: 'shovel', sound: 'sand', gravity: true });
cubeB('blue_concrete_powder', '蓝色混凝土粉末', 'blue_concrete_powder', { hardness: 0.5, tool: 'shovel', sound: 'sand', gravity: true });
cubeB('brown_concrete_powder', '棕色混凝土粉末', 'brown_concrete_powder', { hardness: 0.5, tool: 'shovel', sound: 'sand', gravity: true });
cubeB('green_concrete_powder', '绿色混凝土粉末', 'green_concrete_powder', { hardness: 0.5, tool: 'shovel', sound: 'sand', gravity: true });
cubeB('red_concrete_powder', '红色混凝土粉末', 'red_concrete_powder', { hardness: 0.5, tool: 'shovel', sound: 'sand', gravity: true });
cubeB('black_concrete_powder', '黑色混凝土粉末', 'black_concrete_powder', { hardness: 0.5, tool: 'shovel', sound: 'sand', gravity: true });
cubeB('white_glazed_terracotta', '白色带釉陶瓦', 'white_glazed_terracotta', { hardness: 1.4, tool: 'pickaxe', needsTool: true });
cubeB('orange_glazed_terracotta', '橙色带釉陶瓦', 'orange_glazed_terracotta', { hardness: 1.4, tool: 'pickaxe', needsTool: true });
cubeB('magenta_glazed_terracotta', '品红色带釉陶瓦', 'magenta_glazed_terracotta', { hardness: 1.4, tool: 'pickaxe', needsTool: true });
cubeB('light_blue_glazed_terracotta', '淡蓝色带釉陶瓦', 'light_blue_glazed_terracotta', { hardness: 1.4, tool: 'pickaxe', needsTool: true });
cubeB('yellow_glazed_terracotta', '黄色带釉陶瓦', 'yellow_glazed_terracotta', { hardness: 1.4, tool: 'pickaxe', needsTool: true });
cubeB('lime_glazed_terracotta', '黄绿色带釉陶瓦', 'lime_glazed_terracotta', { hardness: 1.4, tool: 'pickaxe', needsTool: true });
cubeB('pink_glazed_terracotta', '粉红色带釉陶瓦', 'pink_glazed_terracotta', { hardness: 1.4, tool: 'pickaxe', needsTool: true });
cubeB('gray_glazed_terracotta', '灰色带釉陶瓦', 'gray_glazed_terracotta', { hardness: 1.4, tool: 'pickaxe', needsTool: true });
cubeB('light_gray_glazed_terracotta', '淡灰色带釉陶瓦', 'light_gray_glazed_terracotta', { hardness: 1.4, tool: 'pickaxe', needsTool: true });
cubeB('cyan_glazed_terracotta', '青色带釉陶瓦', 'cyan_glazed_terracotta', { hardness: 1.4, tool: 'pickaxe', needsTool: true });
cubeB('purple_glazed_terracotta', '紫色带釉陶瓦', 'purple_glazed_terracotta', { hardness: 1.4, tool: 'pickaxe', needsTool: true });
cubeB('blue_glazed_terracotta', '蓝色带釉陶瓦', 'blue_glazed_terracotta', { hardness: 1.4, tool: 'pickaxe', needsTool: true });
cubeB('brown_glazed_terracotta', '棕色带釉陶瓦', 'brown_glazed_terracotta', { hardness: 1.4, tool: 'pickaxe', needsTool: true });
cubeB('green_glazed_terracotta', '绿色带釉陶瓦', 'green_glazed_terracotta', { hardness: 1.4, tool: 'pickaxe', needsTool: true });
cubeB('red_glazed_terracotta', '红色带釉陶瓦', 'red_glazed_terracotta', { hardness: 1.4, tool: 'pickaxe', needsTool: true });
cubeB('black_glazed_terracotta', '黑色带釉陶瓦', 'black_glazed_terracotta', { hardness: 1.4, tool: 'pickaxe', needsTool: true });
D('tinted_glass', '遮光玻璃', { tex: 'tinted_glass', render: 'translucent', opaque: false, opacity: 15, hardness: 0.3, sound: 'glass', drops: nothing, cullSame: true });
paneB('glass_pane', '玻璃板', 'glass', 'glass_pane_top');
paneB('white_stained_glass_pane', '白色染色玻璃板', 'white_stained_glass', 'white_stained_glass_pane_top', true);
paneB('orange_stained_glass_pane', '橙色染色玻璃板', 'orange_stained_glass', 'orange_stained_glass_pane_top', true);
paneB('magenta_stained_glass_pane', '品红色染色玻璃板', 'magenta_stained_glass', 'magenta_stained_glass_pane_top', true);
paneB('light_blue_stained_glass_pane', '淡蓝色染色玻璃板', 'light_blue_stained_glass', 'light_blue_stained_glass_pane_top', true);
paneB('yellow_stained_glass_pane', '黄色染色玻璃板', 'yellow_stained_glass', 'yellow_stained_glass_pane_top', true);
paneB('lime_stained_glass_pane', '黄绿色染色玻璃板', 'lime_stained_glass', 'lime_stained_glass_pane_top', true);
paneB('pink_stained_glass_pane', '粉红色染色玻璃板', 'pink_stained_glass', 'pink_stained_glass_pane_top', true);
paneB('gray_stained_glass_pane', '灰色染色玻璃板', 'gray_stained_glass', 'gray_stained_glass_pane_top', true);
paneB('light_gray_stained_glass_pane', '淡灰色染色玻璃板', 'light_gray_stained_glass', 'light_gray_stained_glass_pane_top', true);
paneB('cyan_stained_glass_pane', '青色染色玻璃板', 'cyan_stained_glass', 'cyan_stained_glass_pane_top', true);
paneB('purple_stained_glass_pane', '紫色染色玻璃板', 'purple_stained_glass', 'purple_stained_glass_pane_top', true);
paneB('blue_stained_glass_pane', '蓝色染色玻璃板', 'blue_stained_glass', 'blue_stained_glass_pane_top', true);
paneB('brown_stained_glass_pane', '棕色染色玻璃板', 'brown_stained_glass', 'brown_stained_glass_pane_top', true);
paneB('green_stained_glass_pane', '绿色染色玻璃板', 'green_stained_glass', 'green_stained_glass_pane_top', true);
paneB('red_stained_glass_pane', '红色染色玻璃板', 'red_stained_glass', 'red_stained_glass_pane_top', true);
paneB('black_stained_glass_pane', '黑色染色玻璃板', 'black_stained_glass', 'black_stained_glass_pane_top', true);
D('shulker_box', '潜影盒', { shape: SH_BOXES, boxes: () => [[1, 0, 1, 15, 16, 15]], tex: 'shulker_box', render: 'cutout', hardness: 2, sound: 'stone' });
D('white_shulker_box', '白色潜影盒', { shape: SH_BOXES, boxes: () => [[1, 0, 1, 15, 16, 15]], tex: 'white_shulker_box', render: 'cutout', hardness: 2, sound: 'stone' });
D('orange_shulker_box', '橙色潜影盒', { shape: SH_BOXES, boxes: () => [[1, 0, 1, 15, 16, 15]], tex: 'orange_shulker_box', render: 'cutout', hardness: 2, sound: 'stone' });
D('magenta_shulker_box', '品红色潜影盒', { shape: SH_BOXES, boxes: () => [[1, 0, 1, 15, 16, 15]], tex: 'magenta_shulker_box', render: 'cutout', hardness: 2, sound: 'stone' });
D('light_blue_shulker_box', '淡蓝色潜影盒', { shape: SH_BOXES, boxes: () => [[1, 0, 1, 15, 16, 15]], tex: 'light_blue_shulker_box', render: 'cutout', hardness: 2, sound: 'stone' });
D('yellow_shulker_box', '黄色潜影盒', { shape: SH_BOXES, boxes: () => [[1, 0, 1, 15, 16, 15]], tex: 'yellow_shulker_box', render: 'cutout', hardness: 2, sound: 'stone' });
D('lime_shulker_box', '黄绿色潜影盒', { shape: SH_BOXES, boxes: () => [[1, 0, 1, 15, 16, 15]], tex: 'lime_shulker_box', render: 'cutout', hardness: 2, sound: 'stone' });
D('pink_shulker_box', '粉红色潜影盒', { shape: SH_BOXES, boxes: () => [[1, 0, 1, 15, 16, 15]], tex: 'pink_shulker_box', render: 'cutout', hardness: 2, sound: 'stone' });
D('gray_shulker_box', '灰色潜影盒', { shape: SH_BOXES, boxes: () => [[1, 0, 1, 15, 16, 15]], tex: 'gray_shulker_box', render: 'cutout', hardness: 2, sound: 'stone' });
D('light_gray_shulker_box', '淡灰色潜影盒', { shape: SH_BOXES, boxes: () => [[1, 0, 1, 15, 16, 15]], tex: 'light_gray_shulker_box', render: 'cutout', hardness: 2, sound: 'stone' });
D('cyan_shulker_box', '青色潜影盒', { shape: SH_BOXES, boxes: () => [[1, 0, 1, 15, 16, 15]], tex: 'cyan_shulker_box', render: 'cutout', hardness: 2, sound: 'stone' });
D('purple_shulker_box', '紫色潜影盒', { shape: SH_BOXES, boxes: () => [[1, 0, 1, 15, 16, 15]], tex: 'purple_shulker_box', render: 'cutout', hardness: 2, sound: 'stone' });
D('blue_shulker_box', '蓝色潜影盒', { shape: SH_BOXES, boxes: () => [[1, 0, 1, 15, 16, 15]], tex: 'blue_shulker_box', render: 'cutout', hardness: 2, sound: 'stone' });
D('brown_shulker_box', '棕色潜影盒', { shape: SH_BOXES, boxes: () => [[1, 0, 1, 15, 16, 15]], tex: 'brown_shulker_box', render: 'cutout', hardness: 2, sound: 'stone' });
D('green_shulker_box', '绿色潜影盒', { shape: SH_BOXES, boxes: () => [[1, 0, 1, 15, 16, 15]], tex: 'green_shulker_box', render: 'cutout', hardness: 2, sound: 'stone' });
D('red_shulker_box', '红色潜影盒', { shape: SH_BOXES, boxes: () => [[1, 0, 1, 15, 16, 15]], tex: 'red_shulker_box', render: 'cutout', hardness: 2, sound: 'stone' });
D('black_shulker_box', '黑色潜影盒', { shape: SH_BOXES, boxes: () => [[1, 0, 1, 15, 16, 15]], tex: 'black_shulker_box', render: 'cutout', hardness: 2, sound: 'stone' });

// ---- 自然方块 ---------------------------------------------------------------
cubeB('podzol', '灰化土', { top: 'podzol_top', side: 'podzol_side', bottom: 'dirt' }, { hardness: 0.5, tool: 'shovel', sound: 'gravel', drops: drop('dirt') });
cubeB('mycelium', '菌丝体', { top: 'mycelium_top', side: 'mycelium_side', bottom: 'dirt' }, { hardness: 0.6, tool: 'shovel', sound: 'grass', drops: drop('dirt') });
D('dirt_path', '土径', { shape: SH_BOXES, boxes: () => [[0, 0, 0, 16, 15, 16]], tex: { top: 'dirt_path_top', side: 'dirt_path_side', bottom: 'dirt' }, render: 'opaque', hardness: 0.65, tool: 'shovel', sound: 'grass', drops: drop('dirt') });
cubeB('coarse_dirt', '砂土', 'coarse_dirt', { hardness: 0.5, tool: 'shovel', sound: 'gravel' });
cubeB('rooted_dirt', '缠根泥土', 'rooted_dirt', { hardness: 0.5, tool: 'shovel', sound: 'gravel' });
cubeB('mud', '泥巴', 'mud', { hardness: 0.5, tool: 'shovel', sound: 'gravel' });
D('blue_ice', '蓝冰', { tex: 'blue_ice', render: 'translucent', opaque: false, opacity: 2, hardness: 2.8, tool: 'pickaxe', sound: 'glass', cullSame: true, slip: 0.98 });
cubeB('powder_snow', '细雪', 'powder_snow', { hardness: 0.25, tool: 'shovel', sound: 'snow' });
carpetB('moss_carpet', '覆地苔藓', 'moss_block');
cubeB('calcite', '方解石', 'calcite', { hardness: 0.75, tool: 'pickaxe', needsTool: true });
cubeB('dripstone_block', '滴水石块', 'dripstone_block', { hardness: 1.5, tool: 'pickaxe', needsTool: true });
crossB('pointed_dripstone', '滴水石锥', 'pointed_dripstone_up_tip', { sound: 'stone' });
cubeB('crying_obsidian', '哭泣的黑曜石', 'crying_obsidian', { light: 10, hardness: 50, tool: 'pickaxe', level: 3, needsTool: true });
cubeB('crimson_nylium', '绯红菌岩', { top: 'crimson_nylium', side: 'crimson_nylium_side', bottom: 'netherrack' }, { hardness: 0.4, tool: 'pickaxe', needsTool: true, sound: 'stone', drops: drop('netherrack') });
cubeB('warped_nylium', '诡异菌岩', { top: 'warped_nylium', side: 'warped_nylium_side', bottom: 'netherrack' }, { hardness: 0.4, tool: 'pickaxe', needsTool: true, sound: 'stone', drops: drop('netherrack') });
cubeB('soul_sand', '灵魂沙', 'soul_sand', { hardness: 0.5, tool: 'shovel', sound: 'sand' });
cubeB('soul_soil', '灵魂土', 'soul_soil', { hardness: 0.5, tool: 'shovel', sound: 'gravel' });
cubeB('sponge', '海绵', 'sponge', { hardness: 0.6, tool: 'hoe', sound: 'grass' });
cubeB('wet_sponge', '湿海绵', 'wet_sponge', { hardness: 0.6, tool: 'hoe', sound: 'grass' });

// ---- 蘑菇方块 / 树叶 / 树苗 / 植物 --------------------------------------------
D('red_mushroom_block', '红色蘑菇方块', { tex: 'red_mushroom_block', render: 'cutout', opaque: false, hardness: 0.2, tool: 'axe', sound: 'wood', cullSame: true });
D('brown_mushroom_block', '棕色蘑菇方块', { tex: 'brown_mushroom_block', render: 'cutout', opaque: false, hardness: 0.2, tool: 'axe', sound: 'wood', cullSame: true });
D('mushroom_stem', '蘑菇柄', { tex: 'mushroom_stem', render: 'cutout', opaque: false, hardness: 0.2, tool: 'axe', sound: 'wood', cullSame: true });
D('jungle_leaves', '丛林树叶', { tex: 'jungle_leaves', render: 'cutout', opaque: false, opacity: 1, hardness: 0.2, tool: 'hoe', sound: 'grass', tint: 'foliage', drops: nothing });
D('acacia_leaves', '金合欢树叶', { tex: 'acacia_leaves', render: 'cutout', opaque: false, opacity: 1, hardness: 0.2, tool: 'hoe', sound: 'grass', tint: 'foliage', drops: nothing });
D('dark_oak_leaves', '深色橡树树叶', { tex: 'dark_oak_leaves', render: 'cutout', opaque: false, opacity: 1, hardness: 0.2, tool: 'hoe', sound: 'grass', tint: 'foliage', drops: nothing });
D('mangrove_leaves', '红树树叶', { tex: 'mangrove_leaves', render: 'cutout', opaque: false, opacity: 1, hardness: 0.2, tool: 'hoe', sound: 'grass', tint: 'foliage', drops: nothing });
D('cherry_leaves', '樱花树叶', { tex: 'cherry_leaves', render: 'cutout', opaque: false, opacity: 1, hardness: 0.2, tool: 'hoe', sound: 'grass', drops: nothing });
D('azalea_leaves', '杜鹃树叶', { tex: 'azalea_leaves', render: 'cutout', opaque: false, opacity: 1, hardness: 0.2, tool: 'hoe', sound: 'grass', tint: 'foliage', drops: nothing });
D('flowering_azalea_leaves', '盛开的杜鹃树叶', { tex: 'flowering_azalea_leaves', render: 'cutout', opaque: false, opacity: 1, hardness: 0.2, tool: 'hoe', sound: 'grass', drops: nothing });
crossB('jungle_sapling', '丛林树苗', 'jungle_sapling', { fuel: 100 });
crossB('acacia_sapling', '金合欢树苗', 'acacia_sapling', { fuel: 100 });
crossB('dark_oak_sapling', '深色橡树树苗', 'dark_oak_sapling', { fuel: 100 });
crossB('cherry_sapling', '樱花树苗', 'cherry_sapling', { fuel: 100 });
crossB('mangrove_propagule', '红树胎生苗', 'mangrove_propagule', { fuel: 100 });
crossB('azalea', '杜鹃花丛', 'azalea_plant');
crossB('flowering_azalea', '盛开的杜鹃花丛', 'potted_azalea_bush_plant');
crossB('crimson_fungus', '绯红菌', 'crimson_fungus');
crossB('warped_fungus', '诡异菌', 'warped_fungus');
// 双高植物：下半 + 上半两个方块（原版 half=lower/upper），上半用 *_top 贴图
function dblPlantB(key, cn, texB, texT, o = {}) {
  D(key, cn, Object.assign({ shape: SH_CROSS, tex: texB, solid: false, hardness: 0, sound: 'grass', needsSupport: true, flatIcon: texB }, o));
  const t = D(key + '_top', cn, { shape: SH_CROSS, tex: texT, solid: false, hardness: 0, sound: 'grass', replaceable: true, noItem: true, tint: o.tint || null, doubleBottom: BID[key] });
  BLOCKS[BID[key]].doubleTop = t.id;
}
dblPlantB('tall_grass', '高草丛', 'tall_grass_bottom', 'tall_grass_top', { tint: 'grass', replaceable: true });
dblPlantB('large_fern', '大型蕨', 'large_fern_bottom', 'large_fern_top', { tint: 'grass', replaceable: true });
dblPlantB('lilac', '丁香', 'lilac_bottom', 'lilac_top');
dblPlantB('peony', '牡丹', 'peony_bottom', 'peony_top');
dblPlantB('rose_bush', '玫瑰丛', 'rose_bush_bottom', 'rose_bush_top');
dblPlantB('sunflower', '向日葵', 'sunflower_front', 'sunflower_top');
crossB('wither_rose', '凋灵玫瑰', 'wither_rose');
crossB('torchflower', '火把花', 'torchflower');
crossB('pink_petals', '粉红色花簇', 'pink_petals');
crossB('spore_blossom', '孢子花', 'spore_blossom', { needsSupport: false });
// 竹子：原版形态 = 2px 细杆盒体 + 顶部叶片平面（非十字交叉面片）
const BAMBOO_ELS = [
  { from: [7, 0, 7], to: [9, 16, 9], faces: { north: [7, 0, 9, 16, 'bamboo_stalk'], south: [7, 0, 9, 16, 'bamboo_stalk'], east: [7, 0, 9, 16, 'bamboo_stalk'], west: [7, 0, 9, 16, 'bamboo_stalk'], up: [7, 14, 9, 16, 'bamboo_stalk'], down: [7, 14, 9, 16, 'bamboo_stalk'] } },
  { from: [4, 11, 7.875], to: [12, 16, 8.125], faces: { north: [0, 0, 16, 16, 'bamboo_large_leaves'], south: [0, 0, 16, 16, 'bamboo_large_leaves'] } },
  { from: [7.875, 11, 4], to: [8.125, 16, 12], faces: { east: [0, 0, 16, 16, 'bamboo_large_leaves'], west: [0, 0, 16, 16, 'bamboo_large_leaves'] } },
].map(e => ({ from: e.from, to: e.to, rot: null, faces: Object.fromEntries(Object.entries(e.faces).map(([f, a]) => [f, [a[0], a[1], a[2], a[3], T(a[4])]])) }));
D('bamboo', '竹子', { shape: SH_MODEL, model: () => ({ els: BAMBOO_ELS, rot: 0 }), boxes: () => [[7, 0, 7, 9, 16, 9]], tex: 'bamboo_stalk', solid: false, hardness: 0, sound: 'grass', needsSupport: true, flatIcon: 'i_bamboo' });
crossB('crimson_roots', '绯红菌索', 'crimson_roots');
crossB('warped_roots', '诡异菌索', 'warped_roots');
crossB('nether_sprouts', '下界苗', 'nether_sprouts');
crossB('weeping_vines', '垂泪藤', 'weeping_vines', { needsSupport: false });
crossB('twisting_vines', '缠怨藤', 'twisting_vines', { needsSupport: false });
crossB('vine', '藤蔓', 'vine', { needsSupport: false });
crossB('glow_lichen', '发光地衣', 'glow_lichen', { light: 7, needsSupport: false });
crossB('hanging_roots', '垂根', 'hanging_roots', { needsSupport: false });
D('lily_pad', '睡莲', { shape: SH_BOXES, boxes: () => [[0, 0, 0, 16, 1, 16]], tex: 'lily_pad', render: 'cutout', solid: false, hardness: 0, sound: 'grass', needsSupport: true, flatIcon: 'lily_pad' });
crossB('seagrass', '海草', 'seagrass', { needsSupport: false });
crossB('tall_seagrass', '高海草', 'tall_seagrass_bottom', { needsSupport: false });
crossB('sea_pickle', '海泡菜', 'sea_pickle', { needsSupport: false });
crossB('kelp', '海带', 'kelp', { needsSupport: false });
cubeB('dried_kelp_block', '干海带块', { top: 'dried_kelp_top', side: 'dried_kelp_side', bottom: 'dried_kelp_bottom' }, { hardness: 0.5, tool: 'hoe', sound: 'grass' });
crossB('cobweb', '蜘蛛网', 'cobweb', { needsSupport: false });

// ---- 珊瑚 / 鸡蛋类 / 蛙卵 -----------------------------------------------------
cubeB('tube_coral_block', '管珊瑚块', 'tube_coral_block', { hardness: 1.5, tool: 'pickaxe', needsTool: true });
crossB('tube_coral', '管珊瑚', 'tube_coral');
crossB('tube_coral_fan', '管珊瑚扇', 'tube_coral_fan');
cubeB('dead_tube_coral_block', '失活的管珊瑚块', 'dead_tube_coral_block', { hardness: 1.5, tool: 'pickaxe', needsTool: true });
crossB('dead_tube_coral', '失活的管珊瑚', 'dead_tube_coral');
crossB('dead_tube_coral_fan', '失活的管珊瑚扇', 'dead_tube_coral_fan');
cubeB('brain_coral_block', '脑纹珊瑚块', 'brain_coral_block', { hardness: 1.5, tool: 'pickaxe', needsTool: true });
crossB('brain_coral', '脑纹珊瑚', 'brain_coral');
crossB('brain_coral_fan', '脑纹珊瑚扇', 'brain_coral_fan');
cubeB('dead_brain_coral_block', '失活的脑纹珊瑚块', 'dead_brain_coral_block', { hardness: 1.5, tool: 'pickaxe', needsTool: true });
crossB('dead_brain_coral', '失活的脑纹珊瑚', 'dead_brain_coral');
crossB('dead_brain_coral_fan', '失活的脑纹珊瑚扇', 'dead_brain_coral_fan');
cubeB('bubble_coral_block', '气泡珊瑚块', 'bubble_coral_block', { hardness: 1.5, tool: 'pickaxe', needsTool: true });
crossB('bubble_coral', '气泡珊瑚', 'bubble_coral');
crossB('bubble_coral_fan', '气泡珊瑚扇', 'bubble_coral_fan');
cubeB('dead_bubble_coral_block', '失活的气泡珊瑚块', 'dead_bubble_coral_block', { hardness: 1.5, tool: 'pickaxe', needsTool: true });
crossB('dead_bubble_coral', '失活的气泡珊瑚', 'dead_bubble_coral');
crossB('dead_bubble_coral_fan', '失活的气泡珊瑚扇', 'dead_bubble_coral_fan');
cubeB('fire_coral_block', '火珊瑚块', 'fire_coral_block', { hardness: 1.5, tool: 'pickaxe', needsTool: true });
crossB('fire_coral', '火珊瑚', 'fire_coral');
crossB('fire_coral_fan', '火珊瑚扇', 'fire_coral_fan');
cubeB('dead_fire_coral_block', '失活的火珊瑚块', 'dead_fire_coral_block', { hardness: 1.5, tool: 'pickaxe', needsTool: true });
crossB('dead_fire_coral', '失活的火珊瑚', 'dead_fire_coral');
crossB('dead_fire_coral_fan', '失活的火珊瑚扇', 'dead_fire_coral_fan');
cubeB('horn_coral_block', '鹿角珊瑚块', 'horn_coral_block', { hardness: 1.5, tool: 'pickaxe', needsTool: true });
crossB('horn_coral', '鹿角珊瑚', 'horn_coral');
crossB('horn_coral_fan', '鹿角珊瑚扇', 'horn_coral_fan');
cubeB('dead_horn_coral_block', '失活的鹿角珊瑚块', 'dead_horn_coral_block', { hardness: 1.5, tool: 'pickaxe', needsTool: true });
crossB('dead_horn_coral', '失活的鹿角珊瑚', 'dead_horn_coral');
crossB('dead_horn_coral_fan', '失活的鹿角珊瑚扇', 'dead_horn_coral_fan');
D('turtle_egg', '海龟蛋', { shape: SH_BOXES, boxes: () => [[2, 0, 2, 14, 8, 14]], tex: 'turtle_egg', hardness: 0.5, sound: 'stone' });
D('sniffer_egg', '嗅探兽蛋', { shape: SH_BOXES, boxes: () => [[1, 0, 1, 15, 14, 15]], tex: 'sniffer_egg_not_cracked_north', hardness: 0.5, sound: 'stone' });
D('frogspawn', '青蛙卵', { shape: SH_BOXES, boxes: () => [[0, 0, 0, 16, 2, 16]], tex: 'frogspawn', render: 'cutout', solid: false, hardness: 0, sound: 'grass', flatIcon: 'frogspawn' });

// ---- 伏聆 / 蛙明灯 / 黏液块 蜂蜜块 ---------------------------------------------
cubeB('sculk', '幽匿块', 'sculk', { hardness: 0.6, tool: 'hoe', sound: 'grass' });
crossB('sculk_vein', '幽匿脉络', 'sculk_vein', { needsSupport: false });
cubeB('sculk_catalyst', '幽匿催发体', { top: 'sculk_catalyst_top', side: 'sculk_catalyst_side', bottom: 'sculk_catalyst_bottom' }, { hardness: 3, tool: 'hoe', sound: 'grass' });
cubeB('sculk_shrieker', '幽匿尖啸体', { top: 'sculk_shrieker_inner_top', side: 'sculk_shrieker_side', bottom: 'sculk_shrieker_bottom' }, { hardness: 3, tool: 'hoe', sound: 'grass' });
D('sculk_sensor', '幽匿感测体', { shape: SH_BOXES, boxes: () => [[0, 0, 0, 16, 8, 16]], tex: { top: 'sculk_sensor_top', side: 'sculk_sensor_side', bottom: 'sculk_sensor_bottom' }, hardness: 1.5, tool: 'hoe', sound: 'grass' });
D('calibrated_sculk_sensor', '校频幽匿感测体', { shape: SH_BOXES, boxes: () => [[0, 0, 0, 16, 9, 16]], tex: { top: 'calibrated_sculk_sensor_top', side: 'sculk_sensor_side', bottom: 'sculk_sensor_bottom' }, hardness: 1.5, tool: 'hoe', sound: 'grass' });
D('slime_block', '黏液块', { tex: 'slime_block', render: 'translucent', opaque: false, hardness: 0, sound: 'grass', cullSame: true, slip: 0.8 });
D('honey_block', '蜂蜜块', { shape: SH_BOXES, boxes: () => [[1, 0, 1, 15, 15, 15]], tex: 'honey_block_side', render: 'translucent', hardness: 0, sound: 'grass', slip: 0.7 });
cubeB('honeycomb_block', '蜜脾块', 'honeycomb_block', { hardness: 0.6, sound: 'grass' });
cubeB('ochre_froglight', '赭黄蛙明灯', { top: 'ochre_froglight_top', side: 'ochre_froglight_side' }, { light: 15, hardness: 0.3, sound: 'glass' });
cubeB('verdant_froglight', '青翠蛙明灯', { top: 'verdant_froglight_top', side: 'verdant_froglight_side' }, { light: 15, hardness: 0.3, sound: 'glass' });
cubeB('pearlescent_froglight', '珠光蛙明灯', { top: 'pearlescent_froglight_top', side: 'pearlescent_froglight_side' }, { light: 15, hardness: 0.3, sound: 'glass' });

// ---- 作物（SH_CROP；种子/食物物品放作物）---------------------------------------
cropB('carrots', '胡萝卜作物', ['carrots_stage0', 'carrots_stage1', 'carrots_stage2', 'carrots_stage3']);
cropB('potatoes', '马铃薯作物', ['potatoes_stage0', 'potatoes_stage1', 'potatoes_stage2', 'potatoes_stage3']);
cropB('beetroots', '甜菜作物', ['beetroots_stage0', 'beetroots_stage1', 'beetroots_stage2', 'beetroots_stage3']);
cropB('nether_wart', '地狱疣作物', ['nether_wart_stage0', 'nether_wart_stage1', 'nether_wart_stage2']);
cropB('sweet_berry_bush', '甜浆果丛', ['sweet_berry_bush_stage0', 'sweet_berry_bush_stage1', 'sweet_berry_bush_stage2', 'sweet_berry_bush_stage3']);
cropB('torchflower_crop', '火把花作物', ['torchflower_crop_stage0', 'torchflower_crop_stage1']);
cropB('pitcher_crop', '瓶子草作物', ['pitcher_crop_bottom_stage_1', 'pitcher_crop_bottom_stage_2', 'pitcher_crop_bottom_stage_3', 'pitcher_crop_bottom_stage_4']);
cropB('melon_stem', '西瓜茎', ['melon_stem']);
cropB('pumpkin_stem', '南瓜茎', ['pumpkin_stem']);
cropB('cocoa', '可可豆', ['cocoa_stage0', 'cocoa_stage1', 'cocoa_stage2']);
cropB('cave_vines', '洞穴藤蔓', ['cave_vines']);

// ---- 红树根 / 泥土类收尾 ------------------------------------------------------
D('mangrove_roots', '红树根', { tex: { top: 'mangrove_roots_top', side: 'mangrove_roots_side' }, render: 'cutout', hardness: 0.7, tool: 'axe', sound: 'wood' });
cubeB('muddy_mangrove_roots', '沾泥的红树根', { top: 'muddy_mangrove_roots_top', side: 'muddy_mangrove_roots_side' }, { hardness: 0.7, tool: 'shovel', sound: 'gravel' });
cubeB('carved_pumpkin', '雕刻南瓜', { top: 'pumpkin_top', bottom: 'pumpkin_top', side: 'pumpkin_side', front: 'carved_pumpkin' }, { facing: true, hardness: 1, tool: 'axe', sound: 'wood' });

// ---- 收尾的零散方块 ----------------------------------------------------------
cubeB('end_stone', '末地石', 'end_stone', { hardness: 3, tool: 'pickaxe', needsTool: true });
cubeB('red_sandstone', '红砂岩', { top: 'red_sandstone_top', bottom: 'red_sandstone_bottom', side: 'red_sandstone' }, { hardness: 0.8, tool: 'pickaxe', needsTool: true });
cubeB('chiseled_stone_bricks', '雕纹石砖', 'chiseled_stone_bricks', { hardness: 1.5, tool: 'pickaxe', needsTool: true });

// ---- 功能方块 ----------------------------------------------------------------
// 蜡烛（原版 17 色；点燃状态为方块状态，不单独注册）
// 被虫蚀的方块（与本体同贴图，1.21.1 原版归于功能方块）
D('soul_torch', '灵魂火把', { shape: SH_TORCH, tex: 'soul_torch', solid: false, light: 10, hardness: 0, sound: 'wood', needsSupport: true, flatIcon: 'soul_torch' });
D('redstone_torch', '红石火把', { shape: SH_TORCH, tex: 'redstone_torch', solid: false, light: 7, hardness: 0, sound: 'wood', needsSupport: true, flatIcon: 'redstone_torch' });
D('redstone_torch_off', '红石火把', { shape: SH_TORCH, tex: 'redstone_torch_off', solid: false, hardness: 0, sound: 'wood', needsSupport: true, noItem: true });
// 灯笼：原版 template_lantern / template_hanging_lantern（主体 + 顶盖 + 45° 吊环，独立 UV）
// meta bit2 = 悬挂（对着方块底面放置时），支撑：悬挂看上方、落地看下方
const LANTERN_TPL = [
  { from: [5, 0, 5], to: [11, 7, 11], faces: { down: [0, 9, 6, 15, '%'], up: [0, 9, 6, 15, '%'], north: [0, 2, 6, 9, '%'], south: [0, 2, 6, 9, '%'], west: [0, 2, 6, 9, '%'], east: [0, 2, 6, 9, '%'] } },
  { from: [6, 7, 6], to: [10, 9, 10], faces: { up: [1, 10, 5, 14, '%'], north: [1, 0, 5, 2, '%'], south: [1, 0, 5, 2, '%'], west: [1, 0, 5, 2, '%'], east: [1, 0, 5, 2, '%'] } },
  { from: [6.5, 9, 8], to: [9.5, 11, 8], rot: { origin: [8, 8, 8], axis: 'y', angle: 45 }, faces: { north: [14, 1, 11, 3, '%'], south: [11, 1, 14, 3, '%'] } },
  { from: [8, 9, 6.5], to: [8, 11, 9.5], rot: { origin: [8, 8, 8], axis: 'y', angle: 45 }, faces: { west: [14, 10, 11, 12, '%'], east: [11, 10, 14, 12, '%'] } },
];
const LANTERN_HANGING_TPL = [
  { from: [5, 1, 5], to: [11, 8, 11], faces: { down: [0, 9, 6, 15, '%'], up: [0, 9, 6, 15, '%'], north: [0, 2, 6, 9, '%'], south: [0, 2, 6, 9, '%'], west: [0, 2, 6, 9, '%'], east: [0, 2, 6, 9, '%'] } },
  { from: [6, 8, 6], to: [10, 10, 10], faces: { down: [1, 10, 5, 14, '%'], up: [1, 10, 5, 14, '%'], north: [1, 0, 5, 2, '%'], south: [1, 0, 5, 2, '%'], west: [1, 0, 5, 2, '%'], east: [1, 0, 5, 2, '%'] } },
  { from: [6.5, 11, 8], to: [9.5, 15, 8], rot: { origin: [8, 8, 8], axis: 'y', angle: 45 }, faces: { north: [14, 1, 11, 5, '%'], south: [11, 1, 14, 5, '%'] } },
  { from: [8, 10, 6.5], to: [8, 16, 9.5], rot: { origin: [8, 8, 8], axis: 'y', angle: 45 }, faces: { west: [14, 6, 11, 12, '%'], east: [11, 6, 14, 12, '%'] } },
];
for (const [lk, lcn] of [['lantern', '灯笼'], ['soul_lantern', '灵魂灯笼']]) {
  D(lk, lcn, { shape: SH_MODEL, model: (m) => ({ els: elsTpl((m & 4) ? LANTERN_HANGING_TPL : LANTERN_TPL, lk), rot: 0 }),
    boxes: () => [[4, 0, 4, 12, 8, 12]], tex: lk, render: 'cutout', light: lk === 'lantern' ? 15 : 10,
    hardness: 3.5, tool: 'pickaxe', needsTool: true, sound: 'metal', needsSupport: true });
}
// 末地烛：原版 end_rod.json（底座 4x4x1 + 2x2 长杆，独立 UV）；meta = DIRS 朝向（点击面法线方向）
const END_ROD_TPL = [
  { from: [6, 0, 6], to: [10, 1, 10], faces: { down: [6, 6, 2, 2, 'end_rod'], up: [2, 2, 6, 6, 'end_rod'], north: [2, 6, 6, 7, 'end_rod'], south: [2, 6, 6, 7, 'end_rod'], west: [2, 6, 6, 7, 'end_rod'], east: [2, 6, 6, 7, 'end_rod'] } },
  { from: [7, 1, 7], to: [9, 16, 9], faces: { up: [2, 0, 4, 2, 'end_rod'], north: [0, 0, 2, 15, 'end_rod'], south: [0, 0, 2, 15, 'end_rod'], west: [0, 0, 2, 15, 'end_rod'], east: [0, 0, 2, 15, 'end_rod'] } },
];
// 朝向 → 整体旋转（底座贴向依附面，杆指向 meta 方向）
const END_ROD_ROT = { 3: {}, 2: { tiltX: 180 }, 4: { tiltX: -90 }, 5: { tiltX: 90 }, 0: { tiltZ: 90 }, 1: { tiltZ: -90 } };
D('end_rod', '末地烛', { shape: SH_MODEL, model: (m) => Object.assign({ els: elsTpl(END_ROD_TPL, 'end_rod'), rot: 0 }, END_ROD_ROT[m & 7] || {}),
  boxes: (m) => m === 0 ? [[7, 0, 7, 16, 9, 9]] : m === 1 ? [[0, 0, 7, 9, 9, 9]] : m === 4 ? [[7, 0, 7, 9, 9, 16]] : m === 5 ? [[7, 0, 0, 9, 9, 9]] : [[7, 0, 7, 9, 16, 9]],
  tex: 'end_rod', render: 'cutout', light: 14, hardness: 0, sound: 'wood', needsSupport: true });
// 切石机：原版 stonecutter.json（底座 16x9x16 + 中间竖直圆锯平面，独立 UV）
const STONECUTTER_ELS = [
  { from: [0, 0, 0], to: [16, 9, 16], faces: { down: [0, 0, 16, 16, 'stonecutter_bottom'], up: [0, 0, 16, 16, 'stonecutter_top'], north: [0, 7, 16, 16, 'stonecutter_side'], south: [0, 7, 16, 16, 'stonecutter_side'], west: [0, 7, 16, 16, 'stonecutter_side'], east: [0, 7, 16, 16, 'stonecutter_side'] } },
  { from: [1, 9, 8], to: [15, 16, 8], faces: { north: [1, 9, 15, 16, 'stonecutter_saw'], south: [15, 9, 1, 16, 'stonecutter_saw'] } },
].map(e => ({ from: e.from, to: e.to, rot: null, faces: Object.fromEntries(Object.entries(e.faces).map(([f, a]) => [f, [a[0], a[1], a[2], a[3], T(a[4])]])) }));
D('stonecutter', '切石机', { shape: SH_MODEL, model: () => ({ els: STONECUTTER_ELS, rot: 0 }), boxes: () => [[0, 0, 0, 16, 9, 16]], tex: 'stonecutter_side', hardness: 3.5, tool: 'pickaxe', needsTool: true, sound: 'stone' });
cubeB('cartography_table', '制图台', { top: 'cartography_table_top', side: 'cartography_table_side1', bottom: 'oak_planks' }, { hardness: 2.5, tool: 'axe', sound: 'wood', fuel: 300 });
cubeB('fletching_table', '制箭台', { top: 'fletching_table_top', side: 'fletching_table_side', bottom: 'fletching_table_front' }, { hardness: 2.5, tool: 'axe', sound: 'wood', fuel: 300 });
cubeB('smithing_table', '锻造台', { top: 'smithing_table_top', side: 'smithing_table_side', front: 'smithing_table_front', bottom: 'smithing_table_bottom' }, { facing: true, hardness: 2.5, tool: 'axe', sound: 'wood', fuel: 300 });
// 砂轮：原版 grindstone.json（2 条深色橡木腿 + 2 个轴座 + 磨盘，独立 UV）
const GRINDSTONE_ELS = [
  { from: [12, 0, 6], to: [14, 7, 10], faces: { north: [2, 9, 4, 16, 'dark_oak_log'], east: [10, 16, 6, 9, 'dark_oak_log'], south: [12, 9, 14, 16, 'dark_oak_log'], west: [6, 9, 10, 16, 'dark_oak_log'], down: [12, 6, 14, 10, 'dark_oak_log'] } },
  { from: [2, 0, 6], to: [4, 7, 10], faces: { north: [12, 9, 14, 16, 'dark_oak_log'], east: [10, 16, 6, 9, 'dark_oak_log'], south: [2, 9, 4, 16, 'dark_oak_log'], west: [6, 9, 10, 16, 'dark_oak_log'], down: [2, 6, 4, 10, 'dark_oak_log'] } },
  { from: [12, 7, 5], to: [14, 13, 11], faces: { north: [6, 0, 8, 6, 'grindstone_pivot'], east: [0, 0, 6, 6, 'grindstone_pivot'], south: [6, 0, 8, 6, 'grindstone_pivot'], west: [0, 0, 6, 6, 'grindstone_pivot'], up: [8, 0, 10, 6, 'grindstone_pivot'], down: [8, 0, 10, 6, 'grindstone_pivot'] } },
  { from: [2, 7, 5], to: [4, 13, 11], faces: { north: [6, 0, 8, 6, 'grindstone_pivot'], east: [0, 0, 6, 6, 'grindstone_pivot'], south: [6, 0, 8, 6, 'grindstone_pivot'], west: [0, 0, 6, 6, 'grindstone_pivot'], up: [8, 0, 10, 6, 'grindstone_pivot'], down: [8, 0, 10, 6, 'grindstone_pivot'] } },
  { from: [4, 4, 2], to: [12, 16, 14], faces: { north: [0, 0, 8, 12, 'grindstone_round'], east: [0, 0, 12, 12, 'grindstone_side'], south: [0, 0, 8, 12, 'grindstone_round'], west: [0, 0, 12, 12, 'grindstone_side'], up: [0, 0, 8, 12, 'grindstone_round'], down: [0, 0, 8, 12, 'grindstone_round'] } },
].map(e => ({ from: e.from, to: e.to, rot: null, faces: Object.fromEntries(Object.entries(e.faces).map(([f, a]) => [f, [a[0], a[1], a[2], a[3], T(a[4])]])) }));
D('grindstone', '砂轮', { shape: SH_MODEL, model: () => ({ els: GRINDSTONE_ELS, rot: 0 }),
  boxes: () => [[2, 0, 6, 4, 7, 10], [12, 0, 6, 14, 7, 10], [2, 7, 5, 14, 13, 11], [4, 4, 2, 12, 16, 14]], tex: 'grindstone_side', hardness: 2, tool: 'pickaxe', needsTool: true, sound: 'stone' });
cubeB('loom', '织布机', { top: 'loom_top', side: 'loom_side', front: 'loom_front', bottom: 'loom_bottom' }, { facing: true, hardness: 2.5, tool: 'axe', sound: 'wood', fuel: 300 });
cubeB('smoker', '烟熏炉', { top: 'smoker_top', side: 'smoker_side', front: 'smoker_front', frontOn: 'smoker_front_on', bottom: 'smoker_bottom' }, { facing: true, hardness: 3.5, tool: 'pickaxe', needsTool: true, onUse: 'furnace' });
cubeB('blast_furnace', '高炉', { top: 'blast_furnace_top', side: 'blast_furnace_side', front: 'blast_furnace_front', frontOn: 'blast_furnace_front_on' }, { facing: true, hardness: 3.5, tool: 'pickaxe', needsTool: true, onUse: 'furnace' });
D('campfire', '营火', { shape: SH_BOXES, boxes: () => [[0, 0, 0, 16, 6, 16]], tex: { top: 'campfire_fire', side: 'campfire_log', bottom: 'campfire_log' }, render: 'cutout', light: 13, hardness: 2, tool: 'axe', sound: 'wood', flatIcon: 'campfire_fire' });
D('soul_campfire', '灵魂营火', { shape: SH_BOXES, boxes: () => [[0, 0, 0, 16, 6, 16]], tex: { top: 'soul_campfire_fire', side: 'soul_campfire_log_lit', bottom: 'soul_campfire_log_lit' }, render: 'cutout', light: 10, hardness: 2, tool: 'axe', sound: 'wood', flatIcon: 'soul_campfire_fire' });
D('anvil', '铁砧', { shape: SH_BOXES, boxes: () => [[3, 0, 3, 13, 4, 13], [5, 4, 5, 11, 10, 11], [1, 10, 1, 15, 16, 15]], tex: { top: 'anvil_top', side: 'anvil' }, hardness: 5, tool: 'pickaxe', needsTool: true, sound: 'metal' });
D('chipped_anvil', '开裂的铁砧', { shape: SH_BOXES, boxes: () => [[3, 0, 3, 13, 4, 13], [5, 4, 5, 11, 10, 11], [1, 10, 1, 15, 16, 15]], tex: { top: 'chipped_anvil_top', side: 'anvil' }, hardness: 5, tool: 'pickaxe', needsTool: true, sound: 'metal' });
D('damaged_anvil', '损坏的铁砧', { shape: SH_BOXES, boxes: () => [[3, 0, 3, 13, 4, 13], [5, 4, 5, 11, 10, 11], [1, 10, 1, 15, 16, 15]], tex: { top: 'damaged_anvil_top', side: 'anvil' }, hardness: 5, tool: 'pickaxe', needsTool: true, sound: 'metal' });
D('composter', '堆肥桶', { shape: SH_BOXES, boxes: () => [[0, 0, 0, 16, 3, 16], [0, 3, 0, 2, 13, 16], [14, 3, 0, 16, 13, 16], [0, 3, 0, 16, 13, 2], [2, 3, 14, 14, 13, 16]], tex: { top: 'composter_top', side: 'composter_side', bottom: 'composter_bottom' }, hardness: 0.6, tool: 'axe', sound: 'wood', fuel: 300 });
cubeB('jukebox', '唱片机', { top: 'jukebox_top', side: 'jukebox_side', bottom: 'jukebox_top' }, { hardness: 2, tool: 'axe', sound: 'wood', fuel: 300 });
D('enchanting_table', '附魔台', { shape: SH_BOXES, boxes: () => [[0, 0, 0, 16, 14, 16]], tex: { top: 'enchanting_table_top', side: 'enchanting_table_side', bottom: 'enchanting_table_bottom' }, render: 'cutout', light: 7, hardness: 5, tool: 'pickaxe', needsTool: true, sound: 'stone' });
crossB('brewing_stand', '酿造台', 'brewing_stand', { hardness: 0.5, tool: 'pickaxe', sound: 'stone', needsSupport: false });
// 炼药锅：原版 cauldron.json（4 面锅壁 + 8 条腿，内壁/锅底用 cauldron_inner，独立 UV）
const CAULDRON_ELS = [
  { from: [0, 3, 0], to: [2, 16, 16], faces: { north: [0, 0, 16, 13, 'cauldron_side'], east: [14, 0, 16, 13, 'cauldron_side'], south: [0, 0, 16, 13, 'cauldron_side'], west: [0, 0, 2, 13, 'cauldron_side'], up: [0, 0, 2, 16, 'cauldron_top'], down: [0, 0, 2, 16, 'cauldron_inner'] } },
  { from: [2, 3, 2], to: [14, 4, 14], faces: { up: [2, 2, 14, 14, 'cauldron_inner'], down: [2, 2, 14, 14, 'cauldron_inner'] } },
  { from: [14, 3, 0], to: [16, 16, 16], faces: { north: [0, 0, 16, 13, 'cauldron_side'], east: [0, 0, 2, 13, 'cauldron_side'], south: [0, 0, 16, 13, 'cauldron_side'], west: [14, 0, 16, 13, 'cauldron_side'], up: [14, 0, 16, 16, 'cauldron_top'], down: [14, 0, 16, 16, 'cauldron_inner'] } },
  { from: [2, 3, 0], to: [14, 16, 2], faces: { north: [0, 0, 16, 13, 'cauldron_side'], south: [2, 0, 14, 13, 'cauldron_side'], up: [2, 0, 14, 2, 'cauldron_top'], down: [2, 0, 14, 2, 'cauldron_inner'] } },
  { from: [2, 3, 14], to: [14, 16, 16], faces: { north: [2, 0, 14, 13, 'cauldron_side'], south: [0, 0, 16, 13, 'cauldron_side'], up: [2, 14, 14, 16, 'cauldron_top'], down: [2, 14, 14, 16, 'cauldron_inner'] } },
  { from: [0, 0, 0], to: [4, 3, 2], faces: { north: [0, 13, 4, 16, 'cauldron_side'], east: [14, 13, 16, 16, 'cauldron_side'], south: [12, 13, 16, 16, 'cauldron_side'], west: [0, 13, 2, 16, 'cauldron_side'], down: [0, 14, 4, 16, 'cauldron_bottom'] } },
  { from: [0, 0, 2], to: [2, 3, 4], faces: { east: [14, 13, 16, 16, 'cauldron_side'], south: [14, 13, 16, 16, 'cauldron_side'], west: [0, 13, 2, 16, 'cauldron_side'], down: [0, 12, 2, 14, 'cauldron_bottom'] } },
  { from: [12, 0, 0], to: [16, 3, 2], faces: { north: [12, 13, 16, 16, 'cauldron_side'], east: [0, 13, 2, 16, 'cauldron_side'], south: [0, 13, 4, 16, 'cauldron_side'], west: [12, 13, 14, 16, 'cauldron_side'], down: [12, 14, 16, 16, 'cauldron_bottom'] } },
  { from: [14, 0, 2], to: [16, 3, 4], faces: { east: [0, 13, 2, 16, 'cauldron_side'], south: [14, 13, 16, 16, 'cauldron_side'], west: [14, 13, 16, 16, 'cauldron_side'], down: [14, 12, 16, 14, 'cauldron_bottom'] } },
  { from: [0, 0, 14], to: [4, 3, 16], faces: { north: [12, 13, 16, 16, 'cauldron_side'], east: [14, 13, 16, 16, 'cauldron_side'], south: [0, 13, 4, 16, 'cauldron_side'], west: [0, 13, 2, 16, 'cauldron_side'], down: [0, 0, 4, 2, 'cauldron_bottom'] } },
  { from: [0, 0, 12], to: [2, 3, 14], faces: { north: [14, 13, 16, 16, 'cauldron_side'], east: [14, 13, 16, 16, 'cauldron_side'], west: [0, 13, 2, 16, 'cauldron_side'], down: [0, 2, 2, 4, 'cauldron_bottom'] } },
  { from: [12, 0, 14], to: [16, 3, 16], faces: { north: [0, 13, 4, 16, 'cauldron_side'], east: [0, 13, 2, 16, 'cauldron_side'], south: [12, 13, 16, 16, 'cauldron_side'], west: [12, 13, 14, 16, 'cauldron_side'], down: [12, 0, 16, 2, 'cauldron_bottom'] } },
  { from: [14, 0, 12], to: [16, 3, 14], faces: { north: [14, 13, 16, 16, 'cauldron_side'], east: [0, 13, 2, 16, 'cauldron_side'], west: [14, 13, 16, 16, 'cauldron_side'], down: [14, 2, 16, 4, 'cauldron_bottom'] } },
].map(e => ({ from: e.from, to: e.to, rot: null, faces: Object.fromEntries(Object.entries(e.faces).map(([f, a]) => [f, [a[0], a[1], a[2], a[3], T(a[4])]])) }));
D('cauldron', '炼药锅', { shape: SH_MODEL, model: () => ({ els: CAULDRON_ELS, rot: 0 }),
  boxes: () => [[0, 0, 0, 16, 3, 16], [0, 3, 0, 2, 16, 16], [14, 3, 0, 16, 16, 16], [0, 3, 0, 16, 16, 2], [0, 3, 14, 16, 16, 16]], tex: 'cauldron_side', hardness: 2, tool: 'pickaxe', needsTool: true, sound: 'stone' });
// 钟：原版 bell_floor.json（2 根石柱 + 深色橡木横梁）+ 钟体（bell_side/top/bottom 独立 UV，悬挂在梁下）。
// 钟体顶部 13..14 伸入横梁两侧（原版钟体即穿过梁下悬挂），避免钟体顶面与梁底面共面 z-fighting；
// 钟体侧面 UV 仍取 bell_side 的 8x9 钟形绘图区（纵向 1px 拉伸，肉眼不可辨）。
// 原版钟无碰撞箱（可穿过，仅选择盒）。
const BELL_ELS = [
  { from: [2, 13, 7], to: [14, 15, 9], faces: { north: [2, 2, 14, 4, 'dark_oak_planks'], south: [2, 3, 14, 5, 'dark_oak_planks'], up: [2, 3, 14, 5, 'dark_oak_planks'], down: [2, 3, 14, 5, 'dark_oak_planks'] } },
  { from: [14, 0, 6], to: [16, 16, 10], faces: { north: [0, 1, 2, 16, 'stone'], east: [0, 1, 4, 16, 'stone'], south: [0, 1, 2, 16, 'stone'], west: [0, 1, 4, 16, 'stone'], up: [0, 0, 2, 4, 'stone'], down: [0, 0, 2, 4, 'stone'] } },
  { from: [0, 0, 6], to: [2, 16, 10], faces: { north: [0, 1, 2, 16, 'stone'], east: [0, 1, 4, 16, 'stone'], south: [0, 1, 2, 16, 'stone'], west: [0, 1, 4, 16, 'stone'], up: [0, 0, 2, 4, 'stone'], down: [0, 0, 2, 4, 'stone'] } },
  { from: [4, 4, 4], to: [12, 14, 12], faces: { down: [0, 0, 8, 8, 'bell_bottom'], up: [0, 0, 8, 8, 'bell_top'], north: [0, 0, 8, 9, 'bell_side'], south: [0, 0, 8, 9, 'bell_side'], west: [0, 0, 8, 9, 'bell_side'], east: [0, 0, 8, 9, 'bell_side'] } },
].map(e => ({ from: e.from, to: e.to, rot: null, faces: Object.fromEntries(Object.entries(e.faces).map(([f, a]) => [f, [a[0], a[1], a[2], a[3], T(a[4])]])) }));
D('bell', '钟', { shape: SH_MODEL, model: () => ({ els: BELL_ELS, rot: 0 }), solid: false,
  boxes: () => [[0, 0, 6, 16, 16, 10], [4, 4, 4, 12, 14, 12]], tex: 'bell_side', render: 'cutout', hardness: 5, tool: 'pickaxe', needsTool: true, sound: 'metal', flatIcon: 'i_bell' });
cubeB('beacon', '信标', 'beacon', { light: 15, hardness: 3, sound: 'glass' });
cubeB('conduit', '潮涌核心', 'conduit', { light: 15, hardness: 3, tool: 'pickaxe', needsTool: true, sound: 'stone' });
cubeB('lodestone', '磁石', { top: 'lodestone_top', side: 'lodestone_side' }, { hardness: 3.5, tool: 'pickaxe', needsTool: true, sound: 'stone' });
cubeB('respawn_anchor', '重生锚', { top: 'respawn_anchor_top_off', bottom: 'respawn_anchor_bottom', side: 'respawn_anchor_side0' }, { hardness: 50, tool: 'pickaxe', needsTool: true, sound: 'stone' });
D('scaffolding', '脚手架', { tex: { top: 'scaffolding_top', side: 'scaffolding_side', bottom: 'scaffolding_bottom' }, render: 'cutout', hardness: 0, sound: 'wood', cullSame: true });
cubeB('bee_nest', '蜂巢', { top: 'bee_nest_top', side: 'bee_nest_side', front: 'bee_nest_front', bottom: 'bee_nest_bottom' }, { facing: true, hardness: 0.3, tool: 'axe', sound: 'wood' });
cubeB('beehive', '蜂箱', { top: 'beehive_end', side: 'beehive_side', front: 'beehive_front', bottom: 'beehive_end' }, { facing: true, hardness: 0.6, tool: 'axe', sound: 'wood', fuel: 300 });
cubeB('suspicious_sand', '可疑的沙子', 'suspicious_sand_0', { hardness: 0.25, tool: 'shovel', sound: 'sand', drops: nothing });
cubeB('suspicious_gravel', '可疑的沙砾', 'suspicious_gravel_0', { hardness: 0.25, tool: 'shovel', sound: 'gravel', drops: nothing });
// 避雷针：原版 lightning_rod.json（顶部 4x4 帽 + 2x2 长杆，各自独立 UV）
const LIGHTNING_ROD_ELS = [
  { from: [6, 12, 6], to: [10, 16, 10], faces: { north: [0, 0, 4, 4, 'lightning_rod'], south: [0, 0, 4, 4, 'lightning_rod'], west: [0, 0, 4, 4, 'lightning_rod'], east: [0, 0, 4, 4, 'lightning_rod'], down: [0, 0, 4, 4, 'lightning_rod'], up: [0, 0, 4, 4, 'lightning_rod'] } },
  { from: [7, 0, 7], to: [9, 12, 9], faces: { north: [0, 4, 2, 16, 'lightning_rod'], south: [0, 4, 2, 16, 'lightning_rod'], west: [0, 4, 2, 16, 'lightning_rod'], east: [0, 4, 2, 16, 'lightning_rod'], down: [0, 4, 2, 6, 'lightning_rod'] } },
].map(e => ({ from: e.from, to: e.to, rot: null, faces: Object.fromEntries(Object.entries(e.faces).map(([f, a]) => [f, [a[0], a[1], a[2], a[3], T(a[4])]])) }));
D('lightning_rod', '避雷针', { shape: SH_MODEL, model: () => ({ els: LIGHTNING_ROD_ELS, rot: 0 }), boxes: () => [[6, 0, 6, 10, 16, 10]], tex: 'lightning_rod', render: 'cutout', hardness: 3.5, tool: 'pickaxe', needsTool: true, needsSupport: true, sound: 'metal' });
// 花盆：原版 flower_pot.json（4 面壁 + 内部泥土底，各自独立 UV）
const FLOWER_POT_ELS = [
  { from: [5, 0, 5], to: [6, 6, 11], faces: { down: [5, 5, 6, 11, 'flower_pot'], up: [5, 5, 6, 11, 'flower_pot'], north: [10, 10, 11, 16, 'flower_pot'], south: [5, 10, 6, 16, 'flower_pot'], west: [5, 10, 11, 16, 'flower_pot'], east: [5, 10, 11, 16, 'flower_pot'] } },
  { from: [10, 0, 5], to: [11, 6, 11], faces: { down: [10, 5, 11, 11, 'flower_pot'], up: [10, 5, 11, 11, 'flower_pot'], north: [5, 10, 6, 16, 'flower_pot'], south: [10, 10, 11, 16, 'flower_pot'], west: [5, 10, 11, 16, 'flower_pot'], east: [5, 10, 11, 16, 'flower_pot'] } },
  { from: [6, 0, 5], to: [10, 6, 6], faces: { down: [6, 10, 10, 11, 'flower_pot'], up: [6, 5, 10, 6, 'flower_pot'], north: [6, 10, 10, 16, 'flower_pot'], south: [6, 10, 10, 16, 'flower_pot'] } },
  { from: [6, 0, 10], to: [10, 6, 11], faces: { down: [6, 5, 10, 6, 'flower_pot'], up: [6, 10, 10, 11, 'flower_pot'], north: [6, 10, 10, 16, 'flower_pot'], south: [6, 10, 10, 16, 'flower_pot'] } },
  { from: [6, 0, 6], to: [10, 4, 10], faces: { down: [6, 12, 10, 16, 'flower_pot'], up: [6, 6, 10, 10, 'dirt'] } },
].map(e => ({ from: e.from, to: e.to, rot: null, faces: Object.fromEntries(Object.entries(e.faces).map(([f, a]) => [f, [a[0], a[1], a[2], a[3], T(a[4])]])) }));
D('flower_pot', '花盆', { shape: SH_MODEL, model: () => ({ els: FLOWER_POT_ELS, rot: 0 }), boxes: () => [[5, 0, 5, 11, 6, 11]], tex: 'flower_pot', render: 'cutout', solid: false, hardness: 0, sound: 'stone', needsSupport: true });
D('potted_azalea_bush', '杜鹃花丛盆栽', { shape: SH_BOXES, boxes: () => [[1, 0, 1, 15, 12, 15]], tex: { top: 'potted_azalea_bush_top', side: 'potted_azalea_bush_side' }, render: 'cutout', hardness: 0, sound: 'grass', flatIcon: 'potted_azalea_bush_plant' });
D('potted_flowering_azalea_bush', '盛开的杜鹃花丛盆栽', { shape: SH_BOXES, boxes: () => [[1, 0, 1, 15, 12, 15]], tex: { top: 'potted_flowering_azalea_bush_top', side: 'potted_flowering_azalea_bush_side' }, render: 'cutout', hardness: 0, sound: 'grass', flatIcon: 'potted_flowering_azalea_bush_plant' });
cubeB('chiseled_bookshelf', '雕纹书架', { top: 'chiseled_bookshelf_top', side: 'chiseled_bookshelf_side' }, { render: 'cutout', hardness: 1.5, tool: 'axe', sound: 'wood', fuel: 300 });
// 讲台：原版 lectern.json（底座 + 立柱 + 顶部斜面板，元素绕 X 轴旋转 -22.5°）
const LECTERN_ELS = [
  { from: [0, 0, 0], to: [16, 2, 16], faces: { north: [0, 14, 16, 16, 'lectern_base'], east: [0, 6, 16, 8, 'lectern_base'], south: [0, 6, 16, 8, 'lectern_base'], west: [0, 6, 16, 8, 'lectern_base'], up: [0, 0, 16, 16, 'lectern_base'], down: [0, 0, 16, 16, 'lectern_base'] } },
  { from: [4, 2, 4], to: [12, 15, 12], faces: { north: [0, 0, 8, 13, 'lectern_sides'], east: [0, 0, 8, 13, 'lectern_sides'], south: [8, 3, 16, 16, 'lectern_sides'], west: [0, 0, 8, 13, 'lectern_sides'] } },
  { from: [0, 12, 3], to: [16, 16, 16], rot: { angle: -22.5, axis: 'x', origin: [8, 8, 8] }, faces: { north: [0, 0, 16, 4, 'lectern_sides'], east: [0, 4, 13, 8, 'lectern_sides'], south: [0, 4, 16, 8, 'lectern_sides'], west: [0, 4, 13, 8, 'lectern_sides'], up: [0, 1, 16, 14, 'lectern_top'], down: [0, 0, 16, 13, 'lectern_sides'] } },
].map(e => ({ from: e.from, to: e.to, rot: e.rot, faces: Object.fromEntries(Object.entries(e.faces).map(([f, a]) => [f, [a[0], a[1], a[2], a[3], T(a[4])]])) }));
D('lectern', '讲台', { shape: SH_MODEL, model: () => ({ els: LECTERN_ELS, rot: 0 }), boxes: () => [[0, 0, 0, 16, 2, 16], [4, 2, 4, 12, 15, 12], [0, 12, 3, 16, 16, 16]], tex: 'lectern_sides', hardness: 2.5, tool: 'axe', sound: 'wood', fuel: 300 });
D('trapped_chest', '陷阱箱', { shape: SH_BOXES, boxes: () => [[1, 0, 1, 15, 14, 15]], tex: { top: 'chest_top', side: 'chest_side', front: 'chest_front' }, render: 'opaque', facing: true, hardness: 2.5, tool: 'axe', sound: 'wood', onUse: 'chest', fuel: 300 });
cubeB('barrel', '木桶', { top: 'barrel_top', side: 'barrel_side', bottom: 'barrel_bottom' }, { hardness: 2.5, tool: 'axe', sound: 'wood', fuel: 300 });
// 蜡烛：原版 template_candle.json（单支 2x6x2 + 独立 UV）
const CANDLE_ELS = [
  { from: [7, 0, 7], to: [9, 6, 9], faces: { north: [0, 8, 2, 14, '%'], south: [0, 8, 2, 14, '%'], east: [0, 8, 2, 14, '%'], west: [0, 8, 2, 14, '%'], up: [0, 6, 2, 8, '%'], down: [0, 14, 2, 16, '%'] } },
];
for (const [ck, ccn] of [['candle', '蜡烛'], ['white_candle', '白色蜡烛'], ['orange_candle', '橙色蜡烛'], ['magenta_candle', '品红色蜡烛'], ['light_blue_candle', '淡蓝色蜡烛'], ['yellow_candle', '黄色蜡烛'], ['lime_candle', '黄绿色蜡烛'], ['pink_candle', '粉红色蜡烛'], ['gray_candle', '灰色蜡烛'], ['light_gray_candle', '淡灰色蜡烛'], ['cyan_candle', '青色蜡烛'], ['purple_candle', '紫色蜡烛'], ['blue_candle', '蓝色蜡烛'], ['brown_candle', '棕色蜡烛'], ['green_candle', '绿色蜡烛'], ['red_candle', '红色蜡烛'], ['black_candle', '黑色蜡烛']]) {
  D(ck, ccn, { shape: SH_MODEL, model: () => ({ els: elsTpl(CANDLE_ELS, ck), rot: 0 }), boxes: () => [[7, 0, 7, 9, 6, 9]], tex: ck, render: 'cutout', solid: false, hardness: 0.1, sound: 'wool', needsSupport: true });
}

crossB('dragon_egg', '龙蛋', 'dragon_egg', { light: 1, hardness: 3, sound: 'stone', needsSupport: false });
D('end_portal_frame', '末地传送门框架', { shape: SH_BOXES, boxes: () => [[0, 0, 0, 16, 13, 16]], tex: { top: 'end_portal_frame_top', side: 'end_portal_frame_side', bottom: 'end_stone' }, hardness: -1, sound: 'glass' });
cubeB('infested_stone', '虫蚀石头', 'stone', { hardness: 0.75, drops: nothing });
cubeB('infested_cobblestone', '虫蚀圆石', 'cobblestone', { hardness: 0.75, drops: nothing });
cubeB('infested_stone_bricks', '虫蚀石砖', 'stone_bricks', { hardness: 0.75, drops: nothing });
cubeB('infested_cracked_stone_bricks', '虫蚀裂纹石砖', 'cracked_stone_bricks', { hardness: 0.75, drops: nothing });
cubeB('infested_mossy_stone_bricks', '虫蚀苔石砖', 'mossy_stone_bricks', { hardness: 0.75, drops: nothing });
cubeB('infested_chiseled_stone_bricks', '虫蚀雕纹石砖', 'chiseled_stone_bricks', { hardness: 0.75, drops: nothing });
cubeB('infested_deepslate', '虫蚀深板岩', 'deepslate', { hardness: 0.75, drops: nothing });
cubeB('vault', '宝库', { top: 'vault_top', side: 'vault_side_off', front: 'vault_front_off', bottom: 'vault_bottom' }, { facing: true, render: 'cutout', hardness: 50, tool: 'pickaxe', needsTool: true, sound: 'stone' });
cubeB('trial_spawner', '试炼刷怪笼', { top: 'trial_spawner_top_inactive', side: 'trial_spawner_side_inactive', bottom: 'trial_spawner_bottom' }, { render: 'cutout', hardness: 50, tool: 'pickaxe', needsTool: true, sound: 'stone' });

D('cake', '蛋糕', { shape: SH_BOXES, boxes: () => [[1, 0, 1, 15, 8, 15]], tex: { top: 'cake_top', side: 'cake_side', bottom: 'cake_bottom' }, hardness: 0.5, sound: 'wool' });
cubeB('spawner', '刷怪笼', 'spawner', { render: 'cutout', hardness: 5, tool: 'pickaxe', needsTool: true, sound: 'stone' });
crossB('orange_tulip', '橙色郁金香', 'orange_tulip');
crossB('white_tulip', '白色郁金香', 'white_tulip');
crossB('pink_tulip', '粉红色郁金香', 'pink_tulip');

// ---- 红石方块 ----------------------------------------------------------------
// 红石中继器 / 红石比较器：原版模型（平滑石头底座 + 顶面贴图 + 红石火把，独立 UV）
// 中继器两支火把并排在后侧（原版 repeater_1tick：[7,2,2,9,7,4] 与 [7,2,6,9,7,8]，高 5px）；
// 比较器后侧两支 5px + 前侧 1 支 3px（原版 comparator.json）。
// meta bit0-1 = 朝向旋转（放置时按玩家视线旋转，原版规则）
function baseSlab(topTex) {
  const st = T('smooth_stone');
  return { from: [0, 0, 0], to: [16, 2, 16], rot: null, faces: { down: [0, 0, 16, 16, st], up: [0, 0, 16, 16, T(topTex)], north: [0, 14, 16, 16, st], south: [0, 14, 16, 16, st], west: [0, 14, 16, 16, st], east: [0, 14, 16, 16, st] } };
}
function torchEl(from, to, h) {
  // 火把元素：redstone_torch_off 贴图，侧 [7,6,9,6+h]，顶 [7,6,9,8]，底 [7,13,9,15]（原版 UV）
  const toff = T('redstone_torch_off');
  return { from, to, rot: null, faces: { down: [7, 13, 9, 15, toff], up: [7, 6, 9, 8, toff], north: [7, 6, 9, 6 + h, toff], south: [7, 6, 9, 6 + h, toff], west: [7, 6, 9, 6 + h, toff], east: [7, 6, 9, 6 + h, toff] } };
}
const REPEATER_ELS = [baseSlab('repeater'), torchEl([7, 2, 2], [9, 7, 4], 5), torchEl([7, 2, 6], [9, 7, 8], 5)];
const COMPARATOR_ELS = [baseSlab('comparator'), torchEl([4, 2, 11], [6, 7, 13], 5), torchEl([10, 2, 11], [12, 7, 13], 5), torchEl([7, 2, 2], [9, 5, 4], 3)];
D('repeater', '红石中继器', { shape: SH_MODEL, model: (m) => ({ els: REPEATER_ELS, rot: m & 3 }), boxes: () => [[0, 0, 0, 16, 2, 16]], tex: 'repeater', hardness: 0, sound: 'stone', flatIcon: 'i_repeater', drops: (m) => [['repeater', 1]] });
D('comparator', '红石比较器', { shape: SH_MODEL, model: (m) => ({ els: COMPARATOR_ELS, rot: m & 3 }), boxes: () => [[0, 0, 0, 16, 2, 16]], tex: 'comparator', hardness: 0, sound: 'stone', flatIcon: 'i_comparator' });
D('lever', '拉杆', { shape: SH_BOXES, boxes: () => [[5, 0, 5, 11, 3, 11]], tex: 'lever', render: 'cutout', hardness: 0.5, sound: 'wood', flatIcon: 'lever' });
D('tripwire_hook', '绊线钩', { shape: SH_BOXES, boxes: () => [[5, 0, 5, 11, 10, 11]], tex: 'tripwire_hook', render: 'cutout', solid: false, hardness: 0, sound: 'wood', flatIcon: 'tripwire_hook' });
D('daylight_detector', '阳光探测器', { shape: SH_BOXES, boxes: () => [[0, 0, 0, 16, 6, 16]], tex: { top: 'daylight_detector_top', side: 'daylight_detector_side', bottom: 'oak_planks' }, hardness: 0.2, tool: 'axe', sound: 'wood' });
cubeB('piston', '活塞', { top: 'piston_top', bottom: 'piston_bottom', side: 'piston_side' }, { facing: true, hardness: 1.5, sound: 'stone' });
cubeB('sticky_piston', '黏性活塞', { top: 'piston_top_sticky', bottom: 'piston_bottom', side: 'piston_side' }, { facing: true, hardness: 1.5, sound: 'stone' });
cubeB('dispenser', '发射器', { top: 'furnace_top', bottom: 'furnace_top', side: 'furnace_side', front: 'dispenser_front' }, { facing: true, hardness: 3.5, tool: 'pickaxe', needsTool: true });
cubeB('dropper', '投掷器', { top: 'furnace_top', bottom: 'furnace_top', side: 'furnace_side', front: 'dropper_front' }, { facing: true, hardness: 3.5, tool: 'pickaxe', needsTool: true });
cubeB('crafter', '合成器', { top: 'crafter_top', bottom: 'crafter_bottom', side: 'crafter_east', front: 'crafter_north' }, { facing: true, hardness: 1.5, tool: 'axe', sound: 'wood' });
// 漏斗：原版 hopper.json 全套 7 元素（顶部沿口 + 内胆 + 漏颈，hopper_top/outside/inside 独立 UV）
const HOPPER_ELS = [
  { from: [0, 10, 0], to: [16, 11, 16], faces: { down: [0, 0, 16, 16, 'hopper_inside'], up: [0, 0, 16, 16, 'hopper_inside'], north: [0, 5, 16, 6, 'hopper_outside'], south: [0, 5, 16, 6, 'hopper_outside'], west: [0, 5, 16, 6, 'hopper_outside'], east: [0, 5, 16, 6, 'hopper_outside'] } },
  { from: [0, 11, 0], to: [2, 16, 16], faces: { up: [0, 0, 2, 16, 'hopper_top'], north: [14, 0, 16, 5, 'hopper_outside'], south: [0, 0, 2, 5, 'hopper_outside'], west: [0, 0, 16, 5, 'hopper_outside'], east: [0, 0, 16, 5, 'hopper_outside'] } },
  { from: [14, 11, 0], to: [16, 16, 16], faces: { up: [14, 0, 16, 16, 'hopper_top'], north: [0, 0, 2, 5, 'hopper_outside'], south: [14, 0, 16, 5, 'hopper_outside'], west: [0, 0, 16, 5, 'hopper_outside'], east: [0, 0, 16, 5, 'hopper_outside'] } },
  { from: [2, 11, 0], to: [14, 16, 2], faces: { up: [2, 0, 14, 2, 'hopper_top'], north: [2, 0, 14, 5, 'hopper_outside'], south: [2, 0, 14, 5, 'hopper_outside'] } },
  { from: [2, 11, 14], to: [14, 16, 16], faces: { up: [2, 14, 14, 16, 'hopper_top'], north: [2, 0, 14, 5, 'hopper_outside'], south: [2, 0, 14, 5, 'hopper_outside'] } },
  { from: [4, 4, 4], to: [12, 10, 12], faces: { down: [4, 4, 12, 12, 'hopper_inside'], north: [4, 6, 12, 12, 'hopper_outside'], south: [4, 6, 12, 12, 'hopper_outside'], west: [4, 6, 12, 12, 'hopper_outside'], east: [4, 6, 12, 12, 'hopper_outside'] } },
  { from: [6, 0, 6], to: [10, 4, 10], faces: { down: [6, 6, 10, 10, 'hopper_inside'], north: [6, 12, 10, 16, 'hopper_outside'], south: [6, 12, 10, 16, 'hopper_outside'], west: [6, 12, 10, 16, 'hopper_outside'], east: [6, 12, 10, 16, 'hopper_outside'] } },
].map(e => ({ from: e.from, to: e.to, rot: null, faces: Object.fromEntries(Object.entries(e.faces).map(([f, a]) => [f, [a[0], a[1], a[2], a[3], T(a[4])]])) }));
D('hopper', '漏斗', { shape: SH_MODEL, model: () => ({ els: HOPPER_ELS, rot: 0 }), boxes: () => [[0, 4, 0, 16, 8, 16], [6, 0, 6, 10, 4, 10]], tex: 'hopper_outside', hardness: 3, tool: 'pickaxe', needsTool: true, sound: 'metal' });
cubeB('observer', '侦测器', { top: 'observer_top', bottom: 'observer_top', side: 'observer_side', front: 'observer_front' }, { facing: true, hardness: 3, tool: 'pickaxe', needsTool: true });
railB('rail', '铁轨', 'rail');
railB('powered_rail', '动力铁轨', 'powered_rail');
railB('detector_rail', '探测铁轨', 'detector_rail');
railB('activator_rail', '激活铁轨', 'activator_rail');
cubeB('redstone_lamp', '红石灯', 'redstone_lamp', { hardness: 0.3, sound: 'glass' });
cubeB('target', '标靶', { top: 'target_top', side: 'target_side' }, { hardness: 0.5, sound: 'grass' });
plateB('light_weighted_pressure_plate', '轻质测重压力板', 'gold_block', { hardness: 0.5, tool: 'pickaxe', needsTool: true, sound: 'metal' });
plateB('heavy_weighted_pressure_plate', '重质测重压力板', 'iron_block', { hardness: 0.5, tool: 'pickaxe', needsTool: true, sound: 'metal' });

// ---- 操作员实用物品 ------------------------------------------------------------
cubeB('command_block', '命令方块', { top: 'command_block_side', side: 'command_block_side', front: 'command_block_front' }, { facing: true, hardness: -1, sound: 'metal' });
cubeB('chain_command_block', '连锁型命令方块', { top: 'chain_command_block_side', side: 'chain_command_block_side', front: 'chain_command_block_front' }, { facing: true, hardness: -1, sound: 'metal' });
cubeB('repeating_command_block', '循环型命令方块', { top: 'repeating_command_block_side', side: 'repeating_command_block_side', front: 'repeating_command_block_front' }, { facing: true, hardness: -1, sound: 'metal' });
cubeB('structure_block', '结构方块', 'structure_block', { hardness: -1, sound: 'stone' });
cubeB('jigsaw', '拼图方块', { top: 'jigsaw_top', bottom: 'jigsaw_bottom', side: 'jigsaw_side' }, { hardness: -1, sound: 'stone' });

// 原版 Java 版创造模式物品栏 14 选项卡分类已迁移至 js/items_full.js（1.21.1 原版布局）

// ---- 门物品统一延迟注册（方块 ID 分配结束后；items_full.js 注册其新增门后再次调用）----
function __flushDoorItems() {
  for (const [dk, dcn, dtex0, dopt] of __doorItems) {
    if (ITEM_KEY[dk] !== undefined) continue;
    defItem(dk, dcn, Object.assign({ places: dk, tex: ASSETS.tiles['i_' + dk] !== undefined ? T('i_' + dk) : T(dtex0) }, dopt.doorItem || {}));
  }
}
// 注意：此处不立即刷新 —— items_full.js 会先注册补缺方块再调用 __flushDoorItems()，
// 避免门物品 ID 与补缺方块的自动物品 ID 冲突（两者都从 ITEMS.length 起分配）。

// ---- 彩色床（与 red_bed 同一原版模板几何，仅毯子贴图按颜色生成）----------------
// 模板中 'BED' 占位符替换为 '<color>_bed'；bed_down / bed_head_north（枕头正面）为公用贴图
const BED_HEAD_TPL = [
  { from: [0, 3, 0], to: [16, 9, 16], faces: { down: [0, 0, 16, 16, 'bed_down'], up: [0, 0, 16, 16, '%_head_up'], north: [0, 7, 16, 13, 'bed_head_north'], west: [0, 7, 16, 13, '%_head_west'], east: [0, 7, 16, 13, '%_head_east'] } },
  { from: [0, 0, 0], to: [3, 3, 3], faces: { down: [6, 13, 9, 16, '%_head_west'], north: [13, 13, 16, 16, 'bed_head_north'], south: [3, 13, 6, 16, '%_head_west'], west: [0, 13, 3, 16, '%_head_west'], east: [10, 13, 13, 16, 'bed_head_north'] } },
  { from: [13, 0, 0], to: [16, 3, 3], faces: { down: [7, 13, 10, 16, '%_head_east'], north: [0, 13, 3, 16, 'bed_head_north'], south: [10, 13, 13, 16, '%_head_east'], west: [3, 13, 6, 16, 'bed_head_north'], east: [13, 13, 16, 16, '%_head_east'] } },
];
const BED_FOOT_TPL = [
  { from: [0, 3, 0], to: [16, 9, 16], faces: { down: [0, 0, 16, 16, 'bed_down'], up: [0, 0, 16, 16, '%_foot_up'], south: [0, 7, 16, 13, '%_foot_south'], west: [0, 7, 16, 13, '%_foot_west'], east: [0, 7, 16, 13, '%_foot_east'] } },
  { from: [0, 0, 13], to: [3, 3, 16], faces: { down: [7, 13, 10, 16, '%_foot_west'], north: [10, 13, 13, 16, '%_foot_west'], south: [0, 13, 3, 16, '%_foot_south'], west: [13, 13, 16, 16, '%_foot_west'], east: [3, 13, 6, 16, '%_foot_south'] } },
  { from: [13, 0, 13], to: [16, 3, 16], faces: { down: [6, 13, 9, 16, '%_foot_east'], north: [3, 13, 6, 16, '%_foot_east'], south: [13, 13, 16, 16, '%_foot_south'], west: [10, 13, 13, 16, '%_foot_south'], east: [0, 13, 3, 16, '%_foot_east'] } },
];
for (const [c, cn] of WOOLS) {
  if (c === 'red') continue;   // 红色床 = blocks.js 的 red_bed（id 118），保持旧存档兼容
  D(c + '_bed', cn + '床', { shape: SH_MODEL, model: (m) => ({ els: elsTpl((m & 4) ? BED_HEAD_TPL : BED_FOOT_TPL, c + '_bed'), rot: m & 3 }),
    boxes: () => [[0, 0, 0, 16, 9, 16]], tex: c + '_bed_foot_up', render: 'opaque', hardness: 0.2, sound: 'wool', bed: true, stack: 1,
    particle: c + '_bed_head_up', drops: (m) => (m & 4) ? [] : [[c + '_bed', 1]] });
}

// ---- 彩色旗帜（原版立式旗帜几何：12 宽 x 16 高 x 1 厚布面 + 燕尾缺口贴图）--------
const BANNER_TPL = [
  { from: [2, 0, 7], to: [14, 16, 9], faces: { north: [2, 0, 14, 16, '%_banner'], south: [2, 0, 14, 16, '%_banner'], west: [2, 0, 3, 16, '%_banner'], east: [13, 0, 14, 16, '%_banner'], up: [2, 0, 14, 1, '%_banner'], down: [2, 15, 14, 16, '%_banner'] } },
];
for (const [c, cn] of WOOLS) {
  D(c + '_banner', cn + '旗帜', { shape: SH_MODEL, model: (m) => ({ els: elsTpl(BANNER_TPL, c), rot: m & 3 }),
    boxes: () => [[2, 0, 7, 14, 16, 9]], tex: c + '_banner', render: 'cutout', solid: false, hardness: 1, sound: 'wool',
    needsSupport: true, rotDir: true, stack: 16, drops: () => [[c + '_banner', 1]] });
}

// ---- 床 / 旗帜配方（原版：对应颜色羊毛 + 木板 / 木棍）---------------------------
for (const [c] of WOOLS) {
  shaped(c + '_bed', 1, ['WWW', 'PPP'], { W: c + '_wool', P: 'planks' });
  shaped(c + '_banner', 1, ['WWW', 'WWW', ' S '], { W: c + '_wool', S: 'stick' });
}
