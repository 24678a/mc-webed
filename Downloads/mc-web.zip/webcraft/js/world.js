'use strict';
// ---------------------------------------------------------------------------
// World: chunk storage, generation, lighting, fluids, block updates
// ---------------------------------------------------------------------------
// 方块 ID 空间已扩展到 16 位（blocks_full.js 注册全部 1.21.1 方块）
const MAXBLOCK = 65536;
const OPACITY = new Uint8Array(MAXBLOCK), EMIT = new Uint8Array(MAXBLOCK), SOLIDCUBE = new Uint8Array(MAXBLOCK);
const IS_FLUID = new Uint8Array(MAXBLOCK), REPLACEABLE = new Uint8Array(MAXBLOCK);
for (let i = 0; i < MAXBLOCK; i++) {
  const b = BLOCKS[i]; if (!b) { OPACITY[i] = 15; continue; }
  OPACITY[i] = b.opacity; EMIT[i] = b.light; SOLIDCUBE[i] = b.opaque ? 1 : 0;
  IS_FLUID[i] = b.shape === SH_LIQUID ? 1 : 0; REPLACEABLE[i] = b.replaceable ? 1 : 0;
}
const AIR = 0, WATER = 7, LAVA = 8;

function ckey(cx, cz) { return (cx + 32768) * 65536 + (cz + 32768); }

// ---------------------------------------------------------------- 方块纪元地形噪声（移植）
// Simplex 噪声（带种子），含 fbm 多倍频与随机偏移；从《方块纪元》原样移植
const BE_GRAD3 = new Float32Array([1,1,0,-1,1,0,1,-1,0,-1,-1,0,1,0,1,-1,0,1,1,0,-1,-1,0,-1,0,1,1,0,-1,1,0,1,-1,0,-1,-1]);
const BE_F2 = 0.5 * (Math.sqrt(3) - 1), BE_G2 = (3 - Math.sqrt(3)) / 6, BE_F3 = 1 / 3, BE_G3 = 1 / 6;
class SimplexNoise {
  constructor(seed) {
    const r = RNG(seed >>> 0); const p = new Uint8Array(256);
    for (let i = 0; i < 256; i++) p[i] = i;
    for (let i = 255; i > 0; i--) { const j = (r() * (i + 1)) | 0; const t = p[i]; p[i] = p[j]; p[j] = t; }
    this.perm = new Uint8Array(512); this.pm = new Uint8Array(512);
    for (let i = 0; i < 512; i++) { this.perm[i] = p[i & 255]; this.pm[i] = (this.perm[i] % 12) * 3; }
    this.ox = r() * 1000; this.oz = r() * 1000;
  }
  noise2(xin, yin) {
    const perm = this.perm, pm = this.pm;
    const s = (xin + yin) * BE_F2; const i = Math.floor(xin + s), j = Math.floor(yin + s);
    const t = (i + j) * BE_G2; const x0 = xin - (i - t), y0 = yin - (j - t);
    let i1, j1; if (x0 > y0) { i1 = 1; j1 = 0; } else { i1 = 0; j1 = 1; }
    const x1 = x0 - i1 + BE_G2, y1 = y0 - j1 + BE_G2, x2 = x0 - 1 + 2 * BE_G2, y2 = y0 - 1 + 2 * BE_G2;
    const ii = i & 255, jj = j & 255; let n = 0;
    let t0 = 0.5 - x0 * x0 - y0 * y0; if (t0 > 0) { const g = pm[ii + perm[jj]]; t0 *= t0; n += t0 * t0 * (BE_GRAD3[g] * x0 + BE_GRAD3[g + 1] * y0); }
    let t1 = 0.5 - x1 * x1 - y1 * y1; if (t1 > 0) { const g = pm[ii + i1 + perm[jj + j1]]; t1 *= t1; n += t1 * t1 * (BE_GRAD3[g] * x1 + BE_GRAD3[g + 1] * y1); }
    let t2 = 0.5 - x2 * x2 - y2 * y2; if (t2 > 0) { const g = pm[ii + 1 + perm[jj + 1]]; t2 *= t2; n += t2 * t2 * (BE_GRAD3[g] * x2 + BE_GRAD3[g + 1] * y2); }
    return 70 * n;
  }
  noise3(xin, yin, zin) {
    const perm = this.perm, pm = this.pm;
    const s = (xin + yin + zin) * BE_F3; const i = Math.floor(xin + s), j = Math.floor(yin + s), k = Math.floor(zin + s);
    const t = (i + j + k) * BE_G3; const x0 = xin - (i - t), y0 = yin - (j - t), z0 = zin - (k - t);
    let i1, j1, k1, i2, j2, k2;
    if (x0 >= y0) { if (y0 >= z0) { i1 = 1; j1 = 0; k1 = 0; i2 = 1; j2 = 1; k2 = 0; } else if (x0 >= z0) { i1 = 1; j1 = 0; k1 = 0; i2 = 1; j2 = 0; k2 = 1; } else { i1 = 0; j1 = 0; k1 = 1; i2 = 1; j2 = 0; k2 = 1; } }
    else { if (y0 < z0) { i1 = 0; j1 = 0; k1 = 1; i2 = 0; j2 = 1; k2 = 1; } else if (x0 < z0) { i1 = 0; j1 = 1; k1 = 0; i2 = 0; j2 = 1; k2 = 1; } else { i1 = 0; j1 = 1; k1 = 0; i2 = 1; j2 = 1; k2 = 0; } }
    const x1 = x0 - i1 + BE_G3, y1 = y0 - j1 + BE_G3, z1 = z0 - k1 + BE_G3;
    const x2 = x0 - i2 + 2 * BE_G3, y2 = y0 - j2 + 2 * BE_G3, z2 = z0 - k2 + 2 * BE_G3;
    const x3 = x0 - 1 + 3 * BE_G3, y3 = y0 - 1 + 3 * BE_G3, z3 = z0 - 1 + 3 * BE_G3;
    const ii = i & 255, jj = j & 255, kk = k & 255; let n = 0;
    let t0 = 0.6 - x0 * x0 - y0 * y0 - z0 * z0; if (t0 > 0) { const g = pm[ii + perm[jj + perm[kk]]]; t0 *= t0; n += t0 * t0 * (BE_GRAD3[g] * x0 + BE_GRAD3[g + 1] * y0 + BE_GRAD3[g + 2] * z0); }
    let t1 = 0.6 - x1 * x1 - y1 * y1 - z1 * z1; if (t1 > 0) { const g = pm[ii + i1 + perm[jj + j1 + perm[kk + k1]]]; t1 *= t1; n += t1 * t1 * (BE_GRAD3[g] * x1 + BE_GRAD3[g + 1] * y1 + BE_GRAD3[g + 2] * z1); }
    let t2 = 0.6 - x2 * x2 - y2 * y2 - z2 * z2; if (t2 > 0) { const g = pm[ii + i2 + perm[jj + j2 + perm[kk + k2]]]; t2 *= t2; n += t2 * t2 * (BE_GRAD3[g] * x2 + BE_GRAD3[g + 1] * y2 + BE_GRAD3[g + 2] * z2); }
    let t3 = 0.6 - x3 * x3 - y3 * y3 - z3 * z3; if (t3 > 0) { const g = pm[ii + 1 + perm[jj + 1 + perm[kk + 1]]]; t3 *= t3; n += t3 * t3 * (BE_GRAD3[g] * x3 + BE_GRAD3[g + 1] * y3 + BE_GRAD3[g + 2] * z3); }
    return 32 * n;
  }
  fbm2(x, z, oct, lac = 2, gain = 0.5) {
    let s = 0, a = 1, f = 1, w = 0; x += this.ox; z += this.oz;
    for (let o = 0; o < oct; o++) { s += a * this.noise2(x * f, z * f); w += a; a *= gain; f *= lac; }
    return s / w;
  }
}
// 大陆度样条（《方块纪元》CONT）：控制点 [噪声值, 高度]
const BE_CONT = [[-1, 26], [-0.5, 34], [-0.3, 48], [-0.2, 58], [-0.13, 63.5], [-0.05, 66], [0.15, 69], [0.45, 76], [1, 84]];
function beSpline(pts, x) {
  if (x <= pts[0][0]) return pts[0][1];
  for (let i = 1; i < pts.length; i++) if (x < pts[i][0]) { const a = pts[i - 1], b = pts[i]; const t = (x - a[0]) / (b[0] - a[0]); return a[1] + (b[1] - a[1]) * (t * t * (3 - 2 * t)); }
  return pts[pts.length - 1][1];
}
const beRand3 = (x, y, z, s) => hash3u(x, y, z, s) / 4294967296; // [0,1)（原误用 hash3 二次除法，恒为 0）
// 植物判定（可替换植物 + 花卉，装饰时允许被树/结构覆盖）
const BE_PLANT = id => REPLACEABLE[id] === 1 || (id >= 41 && id <= 44) || (id >= 98 && id <= 102);
const BE_LEAF = id => id === 15 || id === 47 || id === 50;
const BE_LOG = id => id === 14 || id === 46 || id === 49;
const BE_GSEA = 63; // 方块纪元海平面常量：水面顶部 y=62，与本项目 SEA=62 对齐

class Chunk {
  constructor(cx, cz) {
    this.cx = cx; this.cz = cz;
    this.blocks = new Uint16Array(16 * 16 * HEIGHT);   // 16 位方块 ID（blocks_full.js 全方块）
    this.meta = new Uint8Array(16 * 16 * HEIGHT);
    this.light = new Uint8Array(16 * 16 * HEIGHT);
    this.grass = new Uint8Array(256 * 3);   // biome tint per column
    this.foliage = new Uint8Array(256 * 3);
    this.biome = new Uint8Array(256);
    this.dirty = 0;           // bitmask of sections needing remesh
    this.lit = false;
    this.decorated = false;   // 两阶段生成：地形完成后需装饰（树/植被/村庄）再光照
    this.meshes = new Array(SECTIONS).fill(null);
    this.modified = false;
    this.sectionCount = new Uint16Array(SECTIONS); // non-air block count per section
  }
  idx(x, y, z) { return (y << 8) | (z << 4) | x; }
  recount() {
    this.sectionCount.fill(0);
    const b = this.blocks;
    for (let i = 0; i < b.length; i++) if (b[i]) this.sectionCount[i >> 12]++;
  }
}

const BIOMES = ['海洋', '沙滩', '平原', '森林', '桦木森林', '针叶林', '雪原', '沙漠', '山地', '河流', '雪山', '冻洋', '草甸', '恶地', '石林', '冰刺之地', '樱花林'];
const BI = { OCEAN: 0, BEACH: 1, PLAINS: 2, FOREST: 3, BIRCH: 4, TAIGA: 5, SNOWY: 6, DESERT: 7, MOUNTAIN: 8, RIVER: 9, SNOWPEAK: 10, FROZEN_OCEAN: 11, MEADOW: 12, BADLANDS: 13, SPIRES: 14, ICE_SPIKES: 15, CHERRY: 16 };

class World {
  constructor(seed) {
    this.seed = seed | 0;
    this.chunks = new Map();
    // 《方块纪元》生成器噪声组（大陆/侵蚀/温度/湿度/山脊/细节/河流/洞穴…）
    const s = seed | 0;
    this.nC = new SimplexNoise(s ^ 0x1234); this.nE = new SimplexNoise(s ^ 0x2345); this.nM = new SimplexNoise(s ^ 0x3456);
    this.nD = new SimplexNoise(s ^ 0x4567); this.nT = new SimplexNoise(s ^ 0x5678); this.nH = new SimplexNoise(s ^ 0x6789);
    this.nR = new SimplexNoise(s ^ 0x789a); this.n3 = new SimplexNoise(s ^ 0x89ab); this.nCave = new SimplexNoise(s ^ 0x9abc);
    this.nSa = new SimplexNoise(s ^ 0xabcd); this.nSb = new SimplexNoise(s ^ 0xbcde); this.nS = new SimplexNoise(s ^ 0xcdef);
    this.nP = new SimplexNoise(s ^ 0xdef0);
    this.nW = new SimplexNoise(s ^ 0x1357); this.nMesa = new SimplexNoise(s ^ 0x2468); this.nI = new SimplexNoise(s ^ 0x3579); this.nI3 = new SimplexNoise(s ^ 0x468a);
    // 恶地层带调色板（映射为本项目方块：83 陶瓦 / 89 泥砖 / 97 红沙）
    const br = RNG(s ^ 0x77); this.BAND = []; const bc = [83, 89, 89, 97, 83, 97, 83, 89, 97];
    for (let i = 0; i < 64; i++) this.BAND.push(bc[(br() * bc.length) | 0]);
    for (let i = 0; i < 64; i += 1 + ((br() * 3) | 0)) { const c = bc[(br() * bc.length) | 0]; this.BAND[i] = c; if (i + 1 < 64 && br() < 0.5) this.BAND[i + 1] = c; }
    this.listener = null;     // game hooks
    this.ticks = new Map();   // scheduled block ticks: key -> {x,y,z,t}
    this.time = 0;            // game tick counter
    this.savedChunks = null;  // map key -> saved data, filled by save system
    this.lightQ = [];
    this.grassMap = null; this.foliageMap = null;
    this.hasIslands = false;  // 浮空岛世界类型（默认地形无浮空岛；仅"浮空岛"世界类型开启）
  }

  // ---- access -------------------------------------------------------------
  getChunk(cx, cz) { return this.chunks.get(ckey(cx, cz)); }
  getBlock(x, y, z) {
    if (y < 0) return 6; if (y >= HEIGHT) return 0;
    const c = this.chunks.get(ckey(x >> 4, z >> 4));
    return c ? c.blocks[(y << 8) | ((z & 15) << 4) | (x & 15)] : 0;
  }
  getMeta(x, y, z) {
    if (y < 0 || y >= HEIGHT) return 0;
    const c = this.chunks.get(ckey(x >> 4, z >> 4));
    return c ? c.meta[(y << 8) | ((z & 15) << 4) | (x & 15)] : 0;
  }
  isLoaded(x, z) { return this.chunks.has(ckey(x >> 4, z >> 4)); }
  getLight(x, y, z) {
    if (y >= HEIGHT) return 0xF0; if (y < 0) return 0;
    const c = this.chunks.get(ckey(x >> 4, z >> 4));
    return c ? c.light[(y << 8) | ((z & 15) << 4) | (x & 15)] : 0xF0;
  }
  skyAt(x, y, z) { return this.getLight(x, y, z) >> 4; }
  blockLightAt(x, y, z) { return this.getLight(x, y, z) & 15; }
  surfaceY(x, z) {
    for (let y = HEIGHT - 1; y > 0; y--) { const b = this.getBlock(x, y, z); if (b && BLOCKS[b].solid) return y; }
    return 0;
  }

  // ---- terrain functions（《方块纪元》移植） ---------------------------------------
  column(x, z, out) {
    const o = out || {};
    const c = this.nC.fbm2(x / 1400, z / 1400, 5, 2, 0.5) * 1.55 + 0.3;          // 大陆度
    const e = this.nE.fbm2(x / 700, z / 700, 4, 2, 0.5) * 1.5;                   // 侵蚀度
    const t = this.nT.fbm2(x / 1300, z / 1300, 3, 2, 0.5) * 1.6;                 // 温度
    const hm = this.nH.fbm2(x / 900, z / 900, 3, 2, 0.5) * 1.6;                  // 湿度
    let base = beSpline(BE_CONT, c);
    const land = smoothstep(-0.22, -0.05, c);
    const mw = smoothstep(0.02, -0.42, e) * land;                                // 山地权重
    // ridged multifractal 山脊分形山脉
    let sum = 0, amp = 1, f = 1 / 330, ws = 0, prev = 1;
    const mx = x + this.nM.ox, mz = z + this.nM.oz;
    for (let o = 0; o < 5; o++) {
      let n = 1 - Math.abs(this.nM.noise2(mx * f, mz * f)); n *= n; n *= (0.35 + 0.65 * prev); prev = n;
      sum += n * amp; ws += amp; amp *= 0.5; f *= 2.05;
    }
    const ridge = sum / ws;
    const mH = mw * (Math.pow(ridge, 1.6) * 175 + 8);
    const hilly = smoothstep(0.35, -0.1, e) * land;
    const hills = this.nD.fbm2(x / 160, z / 160, 4, 2, 0.5) * (5 + 16 * hilly) * (1 - 0.6 * mw) + this.nD.noise2(x / 37 + 400, z / 37) * 1.6;
    let h = base + hills * land + mH;
    // 特殊地貌区域：恶地台地
    const w = this.nW.fbm2(x / 520, z / 520, 3, 2, 0.5) * 1.6;
    const bw = smoothstep(0.3, 0.5, t) * smoothstep(0.15, -0.05, hm) * smoothstep(-0.05, 0.2, w) * land * (1 - mw);
    if (bw > 0) {
      const m = this.nMesa.fbm2(x / 170, z / 170, 3, 2, 0.5) * 1.6;
      const raw = smoothstep(-0.15, 0.35, m) * 42 + this.nMesa.noise2(x / 23, z / 23) * 2.5;
      const st = 7; const fr = raw / st; const tv = Math.floor(fr) * st + smoothstep(0.72, 1.0, fr - Math.floor(fr)) * st;
      h += tv * bw;
    }
    const sw = smoothstep(-0.28, -0.5, w) * land * (1 - mw) * smoothstep(-0.35, -0.1, t) * smoothstep(0.55, 0.3, t); // 石林权重
    const isl = smoothstep(0.2, 0.34, this.nI.fbm2(x / 650, z / 650, 3, 2, 0.5) * 1.6);                             // 浮岛权重
    // 河流：脊线噪声零带 → 下切河谷
    const rn = this.nR.fbm2(x / 520, z / 520, 3, 2, 0.45);
    const rv = Math.abs(rn);
    const width = 0.022 + 0.01 * land;
    let river = 0;
    if (base > 57 && h > 58) {
      const bank = 0.05 + mw * 0.16;
      const k = smoothstep(width, width + bank, rv);
      const target = rv < width ? lerp(55.5, 60.5, rv / width) : 60.5 + (rv - width) * 30;
      const nh = target + (h - target) * Math.pow(k, 1.3);
      if (nh < h) h = nh;
      if (rv < width + 0.004) river = 1;
    }
    o.h = h; o.mw = mw; o.t = t; o.hm = hm; o.c = c; o.river = river; o.land = land; o.w = w; o.bw = bw; o.sw = sw; o.isl = isl;
    // 兼容本项目旧消费方（game.js 生成点/色带查找）
    o.temp = t; o.humid = hm; o.cont = c; o.mount = mw;
    return o;
  }
  biomeOf(p, top) {
    if (top === undefined || top === null) top = Math.floor(p.h);
    if (p.river && top < BE_GSEA) return BI.RIVER;
    if (top < 61 && p.c < -0.2) return p.t < -0.45 ? BI.FROZEN_OCEAN : BI.OCEAN;
    if (p.mw > 0.35 && top > 150) return BI.SNOWPEAK;
    if (p.mw > 0.35 && top > 105) return p.t < 0.3 ? BI.MOUNTAIN : BI.MEADOW;
    if (p.c < -0.08 && top <= 66 && p.mw < 0.2) return p.t < -0.45 ? BI.SNOWY : BI.BEACH;
    if (p.bw > 0.45) return BI.BADLANDS;
    if (p.t < -0.45) return p.w > 0.25 && p.mw < 0.25 ? BI.ICE_SPIKES : BI.SNOWY;
    if (p.sw > 0.35) return BI.SPIRES;
    if (p.t < -0.15) return BI.TAIGA;
    if (p.t > 0.5 && p.hm < 0.0) return BI.DESERT;
    if (p.mw > 0.04 && p.mw < 0.55 && p.t > -0.12 && p.t < 0.45 && p.hm > -0.08 && p.w > -0.05 && top > 70) return BI.CHERRY;
    if (p.hm > 0.28) return BI.FOREST;
    if (p.hm > 0.08 && p.t < 0.25) return BI.BIRCH;
    if (p.mw > 0.2) return BI.MEADOW;
    return BI.PLAINS;
  }
  tintFor(map, temp, humid, out, o) {
    const T = clamp(temp * 0.5 + 0.5, 0, 1), H = clamp(humid * 0.5 + 0.5, 0, 1) * T;
    const px = Math.floor((1 - T) * 255), py = Math.floor((1 - H) * 255);
    const i = (py * 256 + px) * 4;
    out[o] = map[i]; out[o + 1] = map[i + 1]; out[o + 2] = map[i + 2];
  }

  // ---- generation ------------------------------------------------------------
  generateFlat(cx, cz) {
    const ch = new Chunk(cx, cz);
    for (let z = 0; z < 16; z++) for (let x = 0; x < 16; x++) {
      for (let y = 0; y <= 60; y++) ch.blocks[(y << 8) | (z << 4) | x] = y === 0 ? 6 : y < 57 ? 1 : y < 60 ? 3 : 2;
      ch.biome[z * 16 + x] = BI.PLAINS;
      this.tintFor(this.grassMap, 0.3, 0.2, ch.grass, (z * 16 + x) * 3);
      this.tintFor(this.foliageMap, 0.3, 0.2, ch.foliage, (z * 16 + x) * 3);
    }
    ch.recount();
    return ch;
  }
  generate(cx, cz) {
    if (this.flat) return this.generateFlat(cx, cz);
    const ch = new Chunk(cx, cz);
    const blocks = ch.blocks, meta = ch.meta;
    const x0 = cx * 16, z0 = cz * 16;
    // 18×18 高度场（含 1 格边界）供坡度计算
    const hs = new Float32Array(18 * 18), ps = new Array(256);
    const tmp = {};
    for (let z = -1; z <= 16; z++) for (let x = -1; x <= 16; x++) {
      const p = this.column(x0 + x, z0 + z, tmp);
      hs[(z + 1) * 18 + x + 1] = p.h;
      if (x >= 0 && x < 16 && z >= 0 && z < 16) ps[z * 16 + x] = { h: p.h, mw: p.mw, t: p.t, hm: p.hm, c: p.c, river: p.river, land: p.land, w: p.w, bw: p.bw, sw: p.sw, isl: p.isl };
    }
    // 粗粒度 3D 网格：表面扰动（y 步长 8）与洞穴（y 步长 4），三线性插值
    const G3 = new Float32Array(5 * 5 * 33), GC = new Float32Array(5 * 5 * 65), GS = new Float32Array(5 * 5 * 65);
    for (let gz = 0; gz < 5; gz++) for (let gx = 0; gx < 5; gx++) {
      const wx = x0 + gx * 4, wz = z0 + gz * 4;
      for (let gy = 0; gy < 33; gy++) G3[(gz * 5 + gx) * 33 + gy] = this.n3.noise3(wx / 28, gy * 8 / 18, wz / 28) + 0.5 * this.n3.noise3(wx / 11, gy * 8 / 9, wz / 11);
      for (let gy = 0; gy < 65; gy++) {
        const wy = gy * 4;
        GC[(gz * 5 + gx) * 65 + gy] = this.nCave.noise3(wx / 64, wy / 36, wz / 64) * 0.75 + this.nCave.noise3(wx / 22, wy / 16, wz / 22) * 0.25;
        const a = this.nSa.noise3(wx / 80, wy / 48, wz / 80), b = this.nSb.noise3(wx / 80, wy / 48, wz / 80);
        GS[(gz * 5 + gx) * 65 + gy] = a * a + b * b;
      }
    }
    const rng = RNG(hash3u(cx, 7, cz, this.seed)); // 每区块独立地形随机序列（原误用 hash3 小数作种子，全服同序列）
    for (let z = 0; z < 16; z++) for (let x = 0; x < 16; x++) {
      const col = z * 16 + x; const p = ps[col];
      const gx = x >> 2, gz = z >> 2, fx = (x & 3) / 4, fz = (z & 3) / 4;
      const i00 = (gz * 5 + gx), i10 = i00 + 1, i01 = i00 + 5, i11 = i00 + 6;
      const w00 = (1 - fx) * (1 - fz), w10 = fx * (1 - fz), w01 = (1 - fx) * fz, w11 = fx * fz;
      const h = p.h; const amp = 1.2 + p.mw * 9;
      const yTop = Math.min(254, Math.floor(h + amp + 2));
      let top = 0;
      for (let y = 0; y <= yTop; y++) {
        let solid;
        if (y < h - amp - 1) solid = true;
        else {
          const gy = y >> 3, fy = (y & 7) / 8;
          const a0 = G3[i00 * 33 + gy] * w00 + G3[i10 * 33 + gy] * w10 + G3[i01 * 33 + gy] * w01 + G3[i11 * 33 + gy] * w11;
          const a1 = G3[i00 * 33 + gy + 1] * w00 + G3[i10 * 33 + gy + 1] * w10 + G3[i01 * 33 + gy + 1] * w01 + G3[i11 * 33 + gy + 1] * w11;
          const n = a0 + (a1 - a0) * fy;
          solid = (h - y) + n * amp > 0;
        }
        // 保留本项目特色：深板岩层（y<18 渐变）
        if (solid) { blocks[(y << 8) | col] = (y < 10 || (y < 18 && rng() < (18 - y) / 10)) ? 75 : 1; top = y; }
      }
      if (p.sw > 0.15) top = this.spires(blocks, col, x0 + x, z0 + z, top, p.sw);
      // 表面层：坡度、群系、雪线
      const sl = Math.max(Math.abs(hs[(z + 1) * 18 + x + 2] - hs[(z + 1) * 18 + x]), Math.abs(hs[(z + 2) * 18 + x + 1] - hs[z * 18 + x + 1]));
      const bi = this.biomeOf(p, top); ch.biome[col] = bi;
      this.tintFor(this.grassMap, p.t, p.hm, ch.grass, col * 3);
      this.tintFor(this.foliageMap, p.t, p.hm, ch.foliage, col * 3);
      const snowLine = 158 + this.nS.noise2((x0 + x) / 40, (z0 + z) / 40) * 10;
      const steep = sl > 2.6 || (p.mw > 0.3 && sl > 1.7);
      let depth = -1;
      const dirtDepth = 3 + ((rng() * 2) | 0);
      for (let y = top; y >= 1; y--) {
        const i = (y << 8) | col;
        if (blocks[i] !== 1 && blocks[i] !== 75) { depth = -1; continue; }
        depth++;
        if (bi === BI.BADLANDS && y >= BE_GSEA - 2) {
          if (depth === 0 && !steep && y < 110) blocks[i] = rng() < 0.9 ? 97 : 83;
          else if (depth < 40) blocks[i] = this.BAND[(y + ((this.nMesa.noise2((x0 + x) / 60, (z0 + z) / 60) * 2) | 0)) & 63];
          if (depth > 40) break;
          continue;
        }
        if (depth > 6) { if (y < top - 12) break; else continue; }
        const under = top < BE_GSEA - 1 && y < BE_GSEA;
        if (bi === BI.DESERT) { if (depth < 4) blocks[i] = 9; else if (depth < 7) blocks[i] = 17; }
        else if (bi === BI.BEACH || (under && (bi === BI.OCEAN || bi === BI.RIVER || bi === BI.FROZEN_OCEAN) && depth < 3)) {
          if (under && bi === BI.OCEAN && top < 50) blocks[i] = depth < 2 ? 10 : blocks[i];
          else if (under && bi === BI.RIVER) blocks[i] = depth < 2 ? (rng() < 0.25 ? 36 : 9) : 3;
          else if (depth < 4) blocks[i] = 9; else if (depth < 6) blocks[i] = 17;
        }
        else if (under) { if (depth < 2) blocks[i] = rng() < 0.7 ? 3 : 10; }
        else if (y > snowLine + 12 && depth < 3) blocks[i] = 33;
        else if (steep && (bi === BI.SNOWPEAK || bi === BI.MOUNTAIN || p.mw > 0.3)) {
          if (y > snowLine && depth === 0 && sl < 4.5) blocks[i] = 33;
          else if (depth === 0 && rng() < 0.08) blocks[i] = 10;
        }
        else if (bi === BI.SNOWPEAK) { if (depth === 0 || depth < 2) blocks[i] = 33; }
        else if (y > snowLine) { if (depth === 0) { blocks[i] = 2; meta[i] = 1; } else if (depth < dirtDepth) blocks[i] = 3; }
        else if (bi === BI.SNOWY || bi === BI.ICE_SPIKES) { if (depth === 0) { blocks[i] = bi === BI.ICE_SPIKES ? 33 : 2; if (bi !== BI.ICE_SPIKES) meta[i] = 1; } else if (depth < dirtDepth) blocks[i] = 3; }
        else { if (depth === 0) blocks[i] = y >= BE_GSEA - 1 ? 2 : 3; else if (depth < dirtDepth) blocks[i] = 3; }
      }
      // 薄雪覆盖（本项目雪片段落，meta 0 = 2/16 薄雪）
      const snowTop = bi === BI.SNOWY || bi === BI.ICE_SPIKES || bi === BI.SNOWPEAK || top > snowLine;
      if (snowTop && top + 1 < HEIGHT && blocks[((top + 1) << 8) | col] === 0) {
        const tb = blocks[(top << 8) | col];
        if (tb !== 0 && !IS_FLUID[tb]) blocks[((top + 1) << 8) | col] = 34;
      }
      // 洞穴（粗网格插值 + 双阈值：隧道/蠕行）
      for (let y = 1; y < top + 1; y++) {
        const i = (y << 8) | col; if (blocks[i] === 0) continue;
        const gy = y >> 2, fy = (y & 3) / 4;
        const c0 = GC[i00 * 65 + gy] * w00 + GC[i10 * 65 + gy] * w10 + GC[i01 * 65 + gy] * w01 + GC[i11 * 65 + gy] * w11;
        const c1 = GC[i00 * 65 + gy + 1] * w00 + GC[i10 * 65 + gy + 1] * w10 + GC[i01 * 65 + gy + 1] * w01 + GC[i11 * 65 + gy + 1] * w11;
        const cv = c0 + (c1 - c0) * fy;
        const s0 = GS[i00 * 65 + gy] * w00 + GS[i10 * 65 + gy] * w10 + GS[i01 * 65 + gy] * w01 + GS[i11 * 65 + gy] * w11;
        const s1 = GS[i00 * 65 + gy + 1] * w00 + GS[i10 * 65 + gy + 1] * w10 + GS[i01 * 65 + gy + 1] * w01 + GS[i11 * 65 + gy + 1] * w11;
        const sv = s0 + (s1 - s0) * fy;
        const nearSurf = y > top - 9;
        if (nearSurf && top < BE_GSEA + 2) continue;
        let thr = 0.56 + (y < 20 ? (20 - y) * 0.006 : 0);
        if (nearSurf) thr += (y - (top - 9)) * 0.06;
        const sthr = nearSurf ? 0.0028 : 0.0052;
        if (cv > thr || sv < sthr) blocks[i] = y <= 10 ? LAVA : 0;
      }
      // 基岩 + 水体/冰面
      blocks[col] = 6;
      for (let y = 1; y < 5; y++) if (rng() < (5 - y) / 5) blocks[(y << 8) | col] = 6;
      if (top < BE_GSEA - 1 || blocks[(top << 8) | col] === 0) {
        for (let y = BE_GSEA - 1; y > 0; y--) {
          const i = (y << 8) | col; if (blocks[i] !== 0) break;
          blocks[i] = 7;
        }
        if ((bi === BI.FROZEN_OCEAN || bi === BI.SNOWY || p.t < -0.65) && top > 45 && blocks[((BE_GSEA - 1) << 8) | col] === 7) blocks[((BE_GSEA - 1) << 8) | col] = 35;
      }
    }
    // 浮岛、冰刺、晶洞（浮空岛仅"浮空岛"世界类型生成）
    if (this.hasIslands) this.islands(blocks, meta, ps, x0, z0, rng);
    for (let z = 0; z < 16; z++) for (let x = 0; x < 16; x++) { const col = z * 16 + x; if (ch.biome[col] === BI.ICE_SPIKES) this.iceSpike(blocks, col, x0 + x, z0 + z); }
    if (rng() < 0.09) this.geode(blocks, rng);
    this.genOres(ch, rng);
    const cols18 = new Array(324);
    for (let z = -1; z <= 16; z++) for (let x = -1; x <= 16; x++) cols18[(z + 1) * 18 + x + 1] = { h: hs[(z + 1) * 18 + x + 1] };
    if (rng() < 0.11) this.genDungeon(ch, cols18, rng);
    ch.recount();
    return ch;
  }

  genOres(ch, rng) {
    const B = ch.blocks;
    const vein = (ore, deepOre, count, ymin, ymax, size) => {
      for (let n = 0; n < count; n++) {
        let x = rng() * 16, y = ymin + rng() * (ymax - ymin), z = rng() * 16;
        const s = size * (0.6 + rng() * 0.6);
        for (let i = 0; i < s; i++) {
          const ix = x | 0, iy = y | 0, iz = z | 0;
          if (ix >= 0 && ix < 16 && iz >= 0 && iz < 16 && iy > 0 && iy < HEIGHT) {
            const k = (iy << 8) | (iz << 4) | ix;
            if (B[k] === 1) B[k] = ore; else if (B[k] === 75 && deepOre) B[k] = deepOre;
          }
          x += rng() * 2 - 1; y += rng() * 2 - 1; z += rng() * 2 - 1;
        }
      }
    };
    vein(74, 74, 6, 0, 90, 30); vein(73, 73, 5, 0, 90, 30); vein(72, 72, 6, 0, 90, 30);
    vein(3, 0, 6, 10, 100, 24); vein(10, 0, 5, 5, 100, 24);
    vein(13, 76, 22, 5, 130, 12);
    vein(12, 77, 16, 1, 72, 9);
    vein(11, 78, 3, 1, 32, 8);
    vein(80, 0, 6, 1, 16, 7);
    vein(81, 0, 2, 1, 32, 6);
    vein(18, 79, 2, 1, 16, 6);
  }

  genDungeon(ch, cols, rng) {
    const B = ch.blocks, M = ch.meta;
    const lx0 = rng.int(7), lz0 = rng.int(7), W = 8 + rng.int(2), D = 8 + rng.int(2);
    if (lx0 + W > 15 || lz0 + D > 15) return;
    let minH = 999;
    for (let z = lz0; z <= lz0 + D; z++) for (let x = lx0; x <= lx0 + W; x++) minH = Math.min(minH, cols[(z + 1) * 18 + x + 1].h);
    const y0 = 8 + rng.int(Math.max(1, Math.min(40, minH - 20)));
    if (y0 + 12 > minH) return;
    for (let y = 0; y <= 5; y++) for (let z = 0; z <= D; z++) for (let x = 0; x <= W; x++) {
      const i = ((y0 + y) << 8) | ((lz0 + z) << 4) | (lx0 + x);
      const edge = x === 0 || z === 0 || x === W || z === D || y === 0 || y === 5;
      if (edge) { if (y === 5 && B[i] === AIR) continue; B[i] = (y === 0 && rng() < 0.6) || rng() < 0.25 ? 24 : 4; }
      else B[i] = AIR;
      M[i] = 0;
    }
    // openings so caves can connect
    const chests = 1 + (rng() < 0.5 ? 1 : 0);
    const spots = [[1, Math.floor(D / 2), 1], [W - 1, Math.floor(D / 2), 0], [Math.floor(W / 2), 1, 5], [Math.floor(W / 2), D - 1, 4]];
    for (let k = 0; k < chests; k++) {
      const [x, z, face] = spots[rng.int(4)];
      const i = ((y0 + 1) << 8) | ((lz0 + z) << 4) | (lx0 + x);
      B[i] = 52; M[i] = face | 8;
    }
    // a few cobwebs-like decorations: mossy pillars
    for (let k = 0; k < 3; k++) { const i = ((y0 + 1) << 8) | ((lz0 + 2 + rng.int(D - 3)) << 4) | (lx0 + 2 + rng.int(W - 3)); if (B[i] === AIR && rng() < 0.5) B[i] = 70 + rng.int(2); }
    ch.dungeon = [ch.cx * 16 + lx0 + W / 2, y0 + 1, ch.cz * 16 + lz0 + D / 2];
  }

  // ---- 特殊地形结构（《方块纪元》移植） ---------------------------------------
  cellPt(cx, cz, salt) {
    const h = hash3u(cx, salt, cz, this.seed); // 需 32 位整数做位运算取样（原误用 hash3 小数，恒为 [0,0,0]）
    return [(h & 1023) / 1023, ((h >>> 10) & 1023) / 1023, ((h >>> 20) & 1023) / 1023];
  }
  // 石林：锥形石柱与天然石拱
  spires(blocks, col, wx, wz, top, sw) {
    const CS = 22; const gx = Math.floor(wx / CS), gz = Math.floor(wz / CS);
    let newTop = top;
    for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) {
      const cx = gx + dx, cz = gz + dz; const r = this.cellPt(cx, cz, 911);
      const px = (cx + 0.2 + r[0] * 0.6) * CS, pz = (cz + 0.2 + r[1] * 0.6) * CS;
      const k = r[2];
      if (k < 0.5) {
        const r0 = (2.2 + k * 7) * (0.6 + 0.4 * sw), H = (26 + ((k * 7919) % 1) * 48) * sw;
        const d = Math.hypot(wx + 0.5 - px, wz + 0.5 - pz); if (d > r0 + 2) continue;
        const gyBase = top;
        for (let y = gyBase - 4; y < Math.min(252, gyBase + H); y++) {
          const f = (y - gyBase) / H; const wob = this.n3.noise3(wx / 6, y / 7, wz / 6) * 0.9;
          const rr = r0 * (1 - 0.55 * Math.max(0, f)) + wob + (f > 0.92 ? -1.2 : 0);
          if (d <= rr) { const band = (y % 11 < 2) ? 72 : (y % 17 < 1) ? 74 : 1; blocks[(y << 8) | col] = band; if (y > newTop) newTop = y; }
        }
      } else if (k < 0.66 && sw > 0.45) {
        const ang = r[0] * Math.PI; const ax = Math.cos(ang), az = Math.sin(ang);
        const R = 9 + r[1] * 9, tube = 2.2 + r[2] * 2.5, thick = 2.5 + r[1] * 1.5;
        const ox = wx + 0.5 - px, oz = wz + 0.5 - pz; const along = ox * ax + oz * az, perp = -ox * az + oz * ax;
        if (Math.abs(perp) > thick || Math.abs(along) > R + tube) continue;
        for (let y = top - 3; y < Math.min(252, top + R + tube + 2); y++) {
          const dd = Math.abs(Math.hypot(along, y - top) - R) + this.n3.noise3(wx / 5, y / 5, wz / 5) * 0.8;
          if (dd < tube * (1 - (perp * perp) / (thick * thick) * 0.5)) { blocks[(y << 8) | col] = (y % 9 < 2) ? 72 : 1; if (y > newTop) newTop = y; }
        }
      }
    }
    return newTop;
  }
  // 冰刺之地：浮冰尖柱
  iceSpike(blocks, col, wx, wz) {
    const CS = 11; const gx = Math.floor(wx / CS), gz = Math.floor(wz / CS);
    let top = 255; while (top > 1 && !blocks[(top << 8) | col]) top--;
    for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) {
      const cx = gx + dx, cz = gz + dz; const r = this.cellPt(cx, cz, 313); if (r[2] > 0.45) continue;
      const px = (cx + 0.25 + r[0] * 0.5) * CS, pz = (cz + 0.25 + r[1] * 0.5) * CS;
      const r0 = 1.2 + r[2] * 4.5, H = 8 + r[2] * r[2] * 90 + r[0] * 6;
      const d = Math.hypot(wx + 0.5 - px, wz + 0.5 - pz); if (d > r0) continue;
      for (let y = top; y < Math.min(252, top + H); y++) { const f = (y - top) / H; if (d <= r0 * Math.pow(1 - f, 0.9) + 0.35) blocks[(y << 8) | col] = 96; }
    }
  }
  // 浮空岛群（含岛缘瀑布）
  islands(blocks, meta, ps, x0, z0, rng) {
    let any = false; for (const p of ps) if (p.isl > 0.01) { any = true; break; } if (!any) return;
    const tops = new Int16Array(256).fill(-1);
    for (let z = 0; z < 16; z++) for (let x = 0; x < 16; x++) {
      const col = z * 16 + x; const p = ps[col]; if (p.isl <= 0.01) continue;
      const wx = x0 + x, wz = z0 + z;
      const yc = 158 + this.nI.noise2(wx / 110, wz / 110) * 16;
      const depthB = 6 + 26 * p.isl;
      for (let y = Math.floor(yc - depthB - 4); y <= Math.ceil(yc + 5); y++) {
        let d = p.isl * 1.25 + this.nI3.noise3(wx / 30, y / 18, wz / 30) * 0.55 + this.nI3.noise3(wx / 11, y / 9, wz / 11) * 0.22 - 0.72;
        d -= y > yc ? (y - yc) / 5 : (yc - y) / depthB;
        if (d > 0) { blocks[(y << 8) | col] = 1; if (y > tops[col]) tops[col] = y; }
      }
      if (tops[col] > 0) {
        let depth = 0; for (let y = tops[col]; y > tops[col] - 6; y--) { const i = (y << 8) | col; if (!blocks[i]) break; blocks[i] = depth === 0 ? 2 : 3; depth++; }
      }
    }
    for (let a = 0; a < 3; a++) {
      const col = (rng() * 256) | 0; const t = tops[col]; if (t < 100) continue;
      const x = col & 15, z = col >> 4;
      const dirs = [[1, 0], [-1, 0], [0, 1], [0, -1]];
      for (const [dx, dz] of dirs) {
        const nx = x + dx, nz = z + dz; if (nx < 0 || nx > 15 || nz < 0 || nz > 15) continue;
        const ncol = nz * 16 + nx; if (blocks[(t << 8) | ncol] || tops[ncol] > t - 2) continue;
        blocks[(t << 8) | col] = 7; meta[(t << 8) | col] = 0;
        let y = t; while (y > 1 && !blocks[(y << 8) | ncol]) { blocks[(y << 8) | ncol] = 7; meta[(y << 8) | ncol] = y === t ? 1 : 8; y--; }
        if (blocks[(y << 8) | ncol] !== 7) { blocks[(y << 8) | ncol] = 7; meta[(y << 8) | ncol] = 0; }
        a = 99; break;
      }
    }
  }
  // 晶洞（映射为本项目方块：安山岩外壳 / 闪长岩中层 / 青金石内衬）
  geode(blocks, rng) {
    const cy = 12 + ((rng() * 30) | 0), cx = 8, cz = 8, R = 5.5 + rng() * 1.2; const cl = [];
    for (let y = cy - 7; y <= cy + 7; y++) for (let z = 1; z < 15; z++) for (let x = 1; x < 15; x++) {
      const d = Math.hypot(x - cx, (y - cy) * 1.1, z - cz) + this.nI3.noise3(x / 3, y / 3, z / 3) * 0.6;
      const i = (y << 8) | (z << 4) | x; if (d > R) continue;
      if (d > R - 1) blocks[i] = 72; else if (d > R - 2) blocks[i] = 73; else if (d > R - 3) blocks[i] = 108; else { blocks[i] = 0; cl.push([x, y, z]); }
    }
    for (const [x, y, z] of cl) {
      let n = 0; for (const [dx, dy, dz] of [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]]) if (blocks[((y + dy) << 8) | ((z + dz) << 4) | (x + dx)] === 108) n++;
      if (n && rng() < 0.35) blocks[(y << 8) | (z << 4) | x] = 108;
    }
  }

  // ---- 装饰阶段（《方块纪元》移植：树/植被/村庄；8 邻域地形就绪后执行） ----------
  // 生成期原始写入：可跨区块，不触发光照/存档标记，只置脏供重网格化
  setGen(x, y, z, id, meta = 0) {
    if (y < 1 || y >= HEIGHT) return;
    const c = this.chunks.get(ckey(x >> 4, z >> 4)); if (!c) return;
    const i = (y << 8) | ((z & 15) << 4) | (x & 15);
    const old = c.blocks[i];
    if (old === id && c.meta[i] === meta) return;
    c.blocks[i] = id; c.meta[i] = meta;
    if (!old && id) c.sectionCount[y >> 4]++; else if (old && !id) c.sectionCount[y >> 4]--;
    c.dirty |= 1 << (y >> 4);
  }
  decorateChunk(ch) {
    if (this.flat) { ch.decorated = true; return; }
    const A = { get: (x, y, z) => this.getBlock(x, y, z), set: (x, y, z, id, m) => this.setGen(x, y, z, id, m) };
    this.decorateChunkImpl(A, ch.cx, ch.cz, this.seed, ch.biome);
    this.decorateVillages(A, ch.cx, ch.cz);
    ch.decorated = true;
  }
  surfAt(A, x, z) {
    for (let y = 250; y > 1; y--) { const b = A.get(x, y, z); if (b !== 0 && !BE_PLANT(b) && !BE_LEAF(b)) return y; }
    return -1;
  }
  // 兼容旧接口（树苗生长 growTree 使用）
  placeTree(set, tr) {
    const A = { get: (x, y, z) => this.getBlock(x, y, z), set: (x, y, z, id, m) => set(x, y, z, id, m || 0, true) };
    return this.beTree(A, tr.x, tr.y, tr.z, tr.type === 'big' ? 'bigoak' : tr.type, RNG(tr.seed || 1));
  }
  // 树形（《方块纪元》7 种：橡树/大橡树/桦树/高桦/云杉/大云杉/灌木/樱花冠）
  // 注：大云杉仅原版老生长针叶林生成（本项目无该群系）；灌木不在原版森林自然生成；
  // 这两种树形仅保留树形接口，世界生成不再产出
  beTree(A, x, y, z, kind, rng) {
    const LOG = (kind === 'spruce' || kind === 'bigspruce') ? 49 : (kind === 'birch' || kind === 'birchtall') ? 46 : 14;
    const LEAF = (kind === 'spruce' || kind === 'bigspruce') ? 50 : (kind === 'birch' || kind === 'birchtall') ? 47 : 15;
    const setLeaf = (xx, yy, zz) => { const b = A.get(xx, yy, zz); if (b === 0 || BE_PLANT(b)) A.set(xx, yy, zz, LEAF, 0); };
    if (kind === 'cherry') { // 樱花冠形（本项目无樱木，用橡木+橡叶还原冠形）
      const hgt = 4 + ((rng() * 3) | 0); if (y + hgt + 5 > 252) return false;
      const ang = rng() * Math.PI * 2; const bx = Math.round(Math.cos(ang) * 3), bz = Math.round(Math.sin(ang) * 3);
      for (let i = 0; i < hgt; i++) A.set(x, y + i, z, LOG, 0);
      const tops = [[x, y + hgt, z]];
      for (let i = 1; i <= 3; i++) A.set(x + Math.round(bx * i / 3), y + hgt - 2 + i, z + Math.round(bz * i / 3), LOG, 0);
      tops.push([x + bx, y + hgt + 1, z + bz]);
      for (const [tx, ty, tz] of tops) {
        for (let dy = -1; dy <= 2; dy++) { const rad = dy === 2 ? 2 : dy === -1 ? 3 : 4 - (dy === 1 ? 1 : 0);
          for (let dx = -rad; dx <= rad; dx++) for (let dz = -rad; dz <= rad; dz++) { const d = dx * dx + dz * dz; if (d > rad * rad + 1 || (d > (rad - 1) * (rad - 1) && rng() < 0.3)) continue; setLeaf(tx + dx, ty + dy, tz + dz); }
        }
        for (let k = 0; k < 7; k++) { const dx = ((rng() * 7) | 0) - 3, dz = ((rng() * 7) | 0) - 3; const l = 1 + ((rng() * 2) | 0); for (let j = 1; j <= l; j++) setLeaf(tx + dx, ty - 1 - j, tz + dz); }
      }
      A.set(x, y + hgt, z, LOG, 0);
      return true;
    }
    if (kind === 'spruce' || kind === 'bigspruce') {
      const big = kind === 'bigspruce';
      const hgt = big ? 14 + ((rng() * 9) | 0) : 7 + ((rng() * 5) | 0);
      for (let i = -1; i <= hgt + 1; i++) if (y + i > 253) return false;
      for (let i = 0; i < hgt; i++) A.set(x, y + i, z, LOG, 0);
      let cr = 0, step = 1;
      const bottom = big ? Math.floor(hgt * 0.35) : 2 + ((rng() * 2) | 0);
      const maxR = big ? 3 : 2 + (rng() < 0.4 ? 1 : 0);
      for (let yy = y + hgt; yy >= y + bottom; yy--) {
        const rr = cr;
        for (let dx = -rr; dx <= rr; dx++) for (let dz = -rr; dz <= rr; dz++) {
          if (Math.abs(dx) === rr && Math.abs(dz) === rr && rr > 0) continue;
          if (dx === 0 && dz === 0 && yy < y + hgt) continue;
          setLeaf(x + dx, yy, z + dz);
        }
        if (cr >= step) { cr = 1; step = Math.min(maxR, step + 1); } else cr++;
      }
      setLeaf(x, y + hgt, z); setLeaf(x, y + hgt + 1, z);
      return true;
    }
    if (kind === 'bigoak') {
      const hgt = 8 + ((rng() * 5) | 0); if (y + hgt + 5 > 252) return false;
      const blob = (cx2, cy2, cz2, r) => { const R2 = r * r + 0.6;
        for (let dy = -r; dy <= r; dy++) for (let dx = -r - 1; dx <= r + 1; dx++) for (let dz = -r - 1; dz <= r + 1; dz++) {
          const d = dx * dx + dy * dy * 1.2 + dz * dz; if (d > R2 || (d > R2 - 2.5 && rng() < 0.3)) continue; setLeaf(cx2 + dx, cy2 + dy, cz2 + dz); } };
      const ends = [[x, y + hgt - 1, z, 3], [x, y + hgt - 3, z, 3]];
      const nb = 3 + ((rng() * 3) | 0); const a0 = rng() * Math.PI * 2;
      for (let b = 0; b < nb; b++) {
        const ang = a0 + b * Math.PI * 2 / nb + (rng() - 0.5) * 0.8; const sy = y + Math.floor(hgt * (0.4 + rng() * 0.3)); const len = 2 + ((rng() * 3) | 0);
        let ex = x, ey = sy, ez = z;
        for (let j = 1; j <= len; j++) { ex = x + Math.round(Math.cos(ang) * j); ey = sy + Math.round(j * 0.75); ez = z + Math.round(Math.sin(ang) * j); A.set(ex, ey, ez, LOG, 0); }
        ends.push([ex, ey, ez, 2 + (rng() < 0.6 ? 1 : 0)]);
      }
      for (const [ex, ey, ez, r] of ends) blob(ex, ey, ez, r);
      for (let i = 0; i < hgt; i++) A.set(x, y + i, z, LOG, 0);
      for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) if (rng() < 0.4 && A.get(x + dx, y - 1, z + dz) === 2) { A.set(x + dx, y, z + dz, LOG, 0); }
      return true;
    }
    if (kind === 'bush') {
      A.set(x, y, z, LOG, 0);
      for (let dy = 0; dy <= 1; dy++) { const r = dy === 0 ? 2 : 1; for (let dx = -r; dx <= r; dx++) for (let dz = -r; dz <= r; dz++) { if (Math.abs(dx) + Math.abs(dz) > r + (dy === 0 ? 1 : 0) || (Math.abs(dx) === r && Math.abs(dz) === r)) continue; if (dx || dz || dy) setLeaf(x + dx, y + dy, z + dz); } }
      setLeaf(x, y + 1, z);
      return true;
    }
    const hgt = kind === 'birchtall' ? 9 + ((rng() * 4) | 0) : kind === 'birch' ? 5 + ((rng() * 3) | 0) : 4 + ((rng() * 3) | 0);
    if (y + hgt + 2 > 254) return false;
    for (let yy = y + hgt - 3; yy <= y + hgt; yy++) {
      const d = yy - (y + hgt); const rad = d >= -1 ? 1 : 2;
      for (let dx = -rad; dx <= rad; dx++) for (let dz = -rad; dz <= rad; dz++) {
        if (Math.abs(dx) === rad && Math.abs(dz) === rad && (d === 0 || rng() < 0.5)) continue;
        setLeaf(x + dx, yy, z + dz);
      }
    }
    for (let i = 0; i < hgt; i++) A.set(x, y + i, z, LOG, 0);
    return true;
  }
  decorateChunkImpl(A, cx, cz, seed, biomeArr) {
    const rng = RNG(hash3u(cx, 99, cz, seed)); // 每区块独立装饰随机序列（原误用 hash3 小数作种子→全服同序列，树木品种/位置逐区块重复）
    const x0 = cx * 16, z0 = cz * 16;
    const surf = (x, z) => this.surfAt(A, x, z);
    const b0 = biomeArr[8 * 16 + 8];
    // 每区块树木尝试次数（对齐原版 placed_feature 的 count 加权分布，w9:1 → 10% 进位）
    const count = (bi) => bi === BI.CHERRY ? (rng() < 0.1 ? 11 : 10)      // trees_cherry
      : bi === BI.SPIRES ? 2                                              // 石林：自定义群系，保持稀疏
      : bi === BI.FOREST ? (rng() < 0.1 ? 11 : 10)                        // trees_birch_and_oak
      : bi === BI.BIRCH ? (rng() < 0.1 ? 11 : 10)                         // trees_birch
      : bi === BI.TAIGA ? (rng() < 0.1 ? 11 : 10)                         // trees_taiga
      : bi === BI.SNOWY ? (rng() < 0.1 ? 1 : 0)                           // trees_snowy {0:w19,1:w1}
      : bi === BI.MOUNTAIN ? (rng() < 0.1 ? 1 : 0)                        // trees_windswept_hills
      : bi === BI.MEADOW ? (rng() < 0.01 ? 1 : 0)                         // trees_meadow rarity 1/100
      : bi === BI.PLAINS ? (rng() < 0.05 ? 1 : 0)                         // trees_plains {0:w19,1:w1}
      : bi === BI.RIVER ? (rng() < 0.1 ? 1 : 0)                           // trees_water（仅河岸）
      : 0;
    const n = count(b0);
    for (let i = 0; i < n; i++) {
      const lx = (rng() * 16) | 0, lz = (rng() * 16) | 0; const bi = biomeArr[lz * 16 + lx];
      const x = x0 + lx, z = z0 + lz; const y = surf(x, z); if (y < BE_GSEA) continue;
      const g = A.get(x, y, z); if (g !== 2 && g !== 3) continue;
      if (A.get(x, y + 1, z) !== 0 && !REPLACEABLE[A.get(x, y + 1, z)]) continue;
      // 品种选择（对齐原版 configured_feature 的 random_selector 概率）
      let kind = 'oak';
      if (bi === BI.BIRCH) kind = 'birch';                                          // 桦木森林：桦树 100%
      else if (bi === BI.FOREST) { const r = rng(); kind = r < 0.2 ? 'birch' : r < 0.3 ? 'bigoak' : 'oak'; } // 森林：桦 20% / 大橡 10% / 橡 70%
      else if (bi === BI.PLAINS) kind = rng() < 1 / 3 ? 'bigoak' : 'oak';           // 平原：大橡 1/3 / 橡 2/3（仅 5% 区块出树）
      else if (bi === BI.RIVER) kind = rng() < 0.1 ? 'bigoak' : 'oak';              // 河流：大橡 10% / 橡 90%
      else if (bi === BI.TAIGA || bi === BI.SNOWY) kind = 'spruce';                 // 针叶林/雪原：云杉 100%（松形由树形内部随机）
      else if (bi === BI.MOUNTAIN || bi === BI.SPIRES) { const r = rng(); kind = r < 0.666 ? 'spruce' : r < 0.766 ? 'bigoak' : 'oak'; } // 山地：云杉 66.6% / 大橡 10% / 橡 23.4%
      else if (bi === BI.MEADOW) kind = rng() < 0.5 ? 'birchtall' : 'bigoak';       // 草甸：原版高桦 50% / 大橡 50%
      else if (bi === BI.CHERRY) kind = 'cherry';
      A.set(x, y, z, 3, 0);
      this.beTree(A, x, y + 1, z, kind, rng);
    }
    // 浮岛上的树与花（仅"浮空岛"世界类型）
    if (this.hasIslands) {
      for (let i = 0; i < 6; i++) {
        const lx = (rng() * 16) | 0, lz = (rng() * 16) | 0; const x = x0 + lx, z = z0 + lz; const y = surf(x, z);
        if (y < 125 || A.get(x, y, z) !== 2 || A.get(x, y + 1, z) !== 0) continue;
        if (i < 2) { A.set(x, y, z, 3, 0); this.beTree(A, x, y + 1, z, rng() < 0.3 ? 'birch' : 'oak', rng); }
        else A.set(x, y + 1, z, rng() < 0.2 ? [41, 44, 43][(rng() * 3) | 0] : 39, 0);
      }
    }
    // 植被
    const veg = (bi) => bi === BI.CHERRY ? 34 : bi === BI.SPIRES ? 20 : bi === BI.BADLANDS ? 4 : bi === BI.PLAINS ? 22 : bi === BI.MEADOW ? 30 : bi === BI.FOREST ? 14 : bi === BI.BIRCH ? 14 : bi === BI.TAIGA ? 10 : bi === BI.MOUNTAIN ? 6 : bi === BI.DESERT ? 2 : bi === BI.RIVER ? 4 : bi === BI.SNOWY ? 1 : 0;
    const nv = veg(b0);
    const flowerKind = [41, 42, 44, 43][(beRand3(cx >> 2, 5, cz >> 2, seed) * 4) | 0];
    for (let i = 0; i < nv; i++) {
      const lx = (rng() * 16) | 0, lz = (rng() * 16) | 0; const bi = biomeArr[lz * 16 + lx];
      const x = x0 + lx, z = z0 + lz; const y = surf(x, z); if (y < BE_GSEA - 1) continue;
      const g = A.get(x, y, z); if (A.get(x, y + 1, z) !== 0) continue;
      if (bi === BI.CHERRY && g === 2) { A.set(x, y + 1, z, rng() < 0.55 ? [41, 42, 44, 43][(rng() * 4) | 0] : 39, 0); continue; }
      if (bi === BI.DESERT || bi === BI.BADLANDS) { if (g === 9 || g === 97) { if (rng() < 0.5) A.set(x, y + 1, z, 45, 0); else { const hh = 1 + ((rng() * 3) | 0); for (let k = 1; k <= hh; k++) A.set(x, y + k, z, 37, 0); } } continue; }
      if (g !== 2) continue;
      const r = rng();
      if ((bi === BI.PLAINS || bi === BI.MEADOW || bi === BI.FOREST) && r < (bi === BI.MEADOW ? 0.3 : 0.12)) A.set(x, y + 1, z, rng() < 0.7 ? flowerKind : [41, 42, 44, 43][(rng() * 4) | 0], 0);
      else if (bi === BI.TAIGA && r < 0.35) A.set(x, y + 1, z, 40, 0);
      else A.set(x, y + 1, z, 39, 0);
    }
    // 草丛簇
    if (b0 === BI.PLAINS || b0 === BI.MEADOW || b0 === BI.FOREST || b0 === BI.BIRCH) {
      for (let k = 0; k < 2; k++) {
        const cxl = (rng() * 16) | 0, czl = (rng() * 16) | 0;
        for (let i = 0; i < 18; i++) {
          const x = x0 + clamp(cxl + ((rng() * 7) | 0) - 3, 0, 15), z = z0 + clamp(czl + ((rng() * 7) | 0) - 3, 0, 15);
          const y = surf(x, z); if (y < BE_GSEA) continue;
          if (A.get(x, y, z) === 2 && A.get(x, y + 1, z) === 0) A.set(x, y + 1, z, (b0 === BI.MEADOW && rng() < 0.3) ? [41, 44, 43][(rng() * 3) | 0] : 39, 0);
        }
      }
    }
    // 水边甘蔗
    for (let i = 0; i < 6; i++) {
      const x = x0 + ((rng() * 16) | 0), z = z0 + ((rng() * 16) | 0); const y = surf(x, z);
      if (y !== BE_GSEA - 1 && y !== BE_GSEA) continue;
      const g = A.get(x, y, z); if (g !== 2 && g !== 9 && g !== 3) continue;
      if (A.get(x, y + 1, z) !== 0) continue;
      if (A.get(x + 1, y, z) === 7 || A.get(x - 1, y, z) === 7 || A.get(x, y, z + 1) === 7 || A.get(x, y, z - 1) === 7) {
        const hh = 1 + ((rng() * 3) | 0); for (let k = 1; k <= hh; k++) A.set(x, y + k, z, 38, 0);
      }
    }
    // 森林/针叶林蘑菇
    if ((b0 === BI.FOREST || b0 === BI.TAIGA) && rng() < 0.25) {
      const x = x0 + ((rng() * 16) | 0), z = z0 + ((rng() * 16) | 0); const y = surf(x, z);
      if (y > BE_GSEA && A.get(x, y, z) === 2 && A.get(x, y + 1, z) === 0) A.set(x, y + 1, z, rng() < 0.6 ? 71 : 70, 0);
    }
  }

  // ---- 村庄（《方块纪元》移植：每 40×40 区块最多一座，确定性生成） ----------
  villageAt(rx, rz) {
    const r = RNG(hash3u(rx, 77, rz, this.seed)); // 每区域独立村庄随机（原误用 hash3 小数作种子）
    if (r() > 0.55) return null;
    const cx = rx * 40 + 6 + ((r() * 28) | 0), cz = rz * 40 + 6 + ((r() * 28) | 0);
    const wx = cx * 16 + 8, wz = cz * 16 + 8;
    const tmp = {}; const p = this.column(wx, wz, tmp);
    if (p.mw > 0.12 || p.h < 64 || p.h > 100 || p.river || p.c < -0.05) return null;
    if (p.t < -0.15 || (p.t > 0.5 && p.hm < 0) || p.hm > 0.28) return null;
    let mn = 1e9, mx = -1e9;
    for (let k = 0; k < 9; k++) { const q = this.column(wx + ((k % 3) - 1) * 24, wz + (((k / 3) | 0) - 1) * 24, tmp); mn = Math.min(mn, q.h); mx = Math.max(mx, q.h); if (q.river) return null; }
    if (mx - mn > 7) return null;
    const parts = [];
    parts.push({ type: 'well', x: wx, z: wz });
    const dirs = [[1, 0], [-1, 0], [0, 1], [0, -1]];
    for (const d of dirs) {
      const len = 18 + ((r() * 14) | 0);
      parts.push({ type: 'path', x: wx, z: wz, dx: d[0], dz: d[1], len });
      for (let s = 7; s < len - 3; s += 8 + ((r() * 3) | 0)) {
        const side = r() < 0.5 ? 1 : -1;
        const px = wx + d[0] * s + (d[1] !== 0 ? side * 6 : 0), pz = wz + d[1] * s + (d[0] !== 0 ? side * 6 : 0);
        const kind = r();
        parts.push({ type: kind < 0.25 ? 'farm' : kind < 0.35 ? 'tower' : kind < 0.45 ? 'lamp' : 'house', x: px, z: pz, face: d[0] !== 0 ? (side > 0 ? 2 : 0) : (side > 0 ? 1 : 3), size: 5 + ((r() * 2) | 0) * 2, seed: (r() * 1e9) | 0 });
      }
    }
    return parts;
  }
  buildVillagePart(A, part, clip) {
    const S = (x, y, z, id, m) => { if (x < clip.x0 || x > clip.x1 || z < clip.z0 || z > clip.z1) return; A.set(x, y, z, id, m || 0); };
    const ground = (x, z) => { for (let y = 200; y > 30; y--) { const b = A.get(x, y, z); if (b !== 0 && SOLIDCUBE[b] && !BE_PLANT(b) && !BE_LEAF(b) && !BE_LOG(b)) return y; if (b === 7) return -1; } return -1; };
    const clear = (x, y, z) => { S(x, y, z, 0); };
    if (part.type === 'path') {
      for (let s = 2; s <= part.len; s++) for (let w = -1; w <= 1; w++) {
        const x = part.x + part.dx * s + (part.dz !== 0 ? w : 0), z = part.z + part.dz * s + (part.dx !== 0 ? w : 0);
        if (x < clip.x0 || x > clip.x1 || z < clip.z0 || z > clip.z1) continue;
        const y = ground(x, z); if (y < 0) continue;
        const b = A.get(x, y, z); if (b === 2 || b === 3) S(x, y, z, 3);
        const a = A.get(x, y + 1, z); if (a !== 0 && (BE_PLANT(a) || a === 34)) clear(x, y + 1, z);
      }
      return;
    }
    const cy = Math.ceil(this.column(part.x, part.z, {}).h) - 1; if (cy < BE_GSEA) return;
    if (part.type === 'well') {
      for (let dx = -2; dx <= 2; dx++) for (let dz = -2; dz <= 2; dz++) {
        const x = part.x + dx, z = part.z + dz;
        for (let y = cy - 3; y <= cy; y++) S(x, y, z, 4);
        for (let y = cy + 1; y <= cy + 5; y++) clear(x, y, z);
        S(x, cy, z, 3);
      }
      for (let dx = -1; dx <= 1; dx++) for (let dz = -1; dz <= 1; dz++) {
        const x = part.x + dx, z = part.z + dz; const edge = Math.abs(dx) === 1 || Math.abs(dz) === 1;
        if (edge) { S(x, cy + 1, z, 4); } else { for (let y = cy - 2; y <= cy; y++) S(x, y, z, 7); }
      }
      for (const c of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) { S(part.x + c[0], cy + 2, part.z + c[1], 14); S(part.x + c[0], cy + 3, part.z + c[1], 14); }
      for (let dx = -1; dx <= 1; dx++) for (let dz = -1; dz <= 1; dz++) S(part.x + dx, cy + 4, part.z + dz, 4);
      S(part.x, cy + 5, part.z, 21);
      return;
    }
    if (part.type === 'lamp') {
      S(part.x, cy + 1, part.z, 14); S(part.x, cy + 2, part.z, 14); S(part.x, cy + 3, part.z, 85);
      return;
    }
    if (part.type === 'farm') {
      for (let dx = -3; dx <= 3; dx++) for (let dz = -4; dz <= 4; dz++) {
        const x = part.x + dx, z = part.z + dz; const edge = Math.abs(dx) === 3 || Math.abs(dz) === 4;
        for (let y = cy + 1; y <= cy + 4; y++) clear(x, y, z);
        S(x, cy - 1, z, 3);
        if (edge) S(x, cy, z, 14);
        else if (dx === 0) S(x, cy, z, 7);
        else { S(x, cy, z, 63, 1); S(x, cy + 1, z, 64, 3 + ((part.seed >> (dz + 5)) & 3) + ((Math.abs(dx) === 1) ? 1 : 0)); }
      }
      return;
    }
    const r = RNG(part.seed);
    const half = part.type === 'tower' ? 2 : (part.size >> 1);
    const wallH = part.type === 'tower' ? 9 : 4;
    const hx = half, hz = part.type === 'tower' ? 2 : half + 1;
    const wall = r() < 0.5 ? 5 : 51, corner = wall === 5 ? 14 : 49;
    // 地基与清场
    for (let dx = -hx - 1; dx <= hx + 1; dx++) for (let dz = -hz - 1; dz <= hz + 1; dz++) {
      const x = part.x + dx, z = part.z + dz;
      for (let y = cy + 1; y <= cy + wallH + hx + 4; y++) clear(x, y, z);
      for (let y = cy - 4; y <= cy; y++) { const b = A.get(x, y, z); if (y === cy || b === 0 || b === 7 || !SOLIDCUBE[b]) S(x, y, z, (Math.abs(dx) <= hx && Math.abs(dz) <= hz) ? 4 : 3); }
      if (Math.abs(dx) > hx || Math.abs(dz) > hz) S(x, cy, z, 2);
    }
    for (let dx = -hx; dx <= hx; dx++) for (let dz = -hz; dz <= hz; dz++) {
      const x = part.x + dx, z = part.z + dz;
      const ex = Math.abs(dx) === hx, ez = Math.abs(dz) === hz;
      S(x, cy, z, 4);
      if (!ex && !ez) { S(x, cy + 1, z, 0); continue; }
      for (let y = cy + 1; y <= cy + wallH; y++) {
        let id = (ex && ez) ? corner : (part.type === 'tower' ? 4 : wall);
        if (y === cy + 1 && !(ex && ez) && part.type !== 'tower') id = 4;
        const winY = part.type === 'tower' ? (y === cy + 3 || y === cy + 7) : (y === cy + 2 || y === cy + 3);
        if (!(ex && ez) && winY && ((ex && Math.abs(dz) === 1) || (ez && Math.abs(dx) === 1 && part.type !== 'tower') || (part.type === 'tower' && ((ex && dz === 0) || (ez && dx === 0))))) id = 16;
        S(x, y, z, id);
      }
    }
    // 门口开洞朝向道路
    const fdx = [0, 1, 0, -1][part.face], fdz = [-1, 0, 1, 0][part.face];
    const dxp = part.x + fdx * hx, dzp = part.z + fdz * hz;
    S(dxp, cy + 1, dzp, 0); S(dxp, cy + 2, dzp, 0);
    S(dxp + fdx, cy, dzp + fdz, 3);
    if (part.type === 'tower') {
      for (let k = 0; k <= 2; k++) for (let dx = -hx - 1 + k; dx <= hx + 1 - k; dx++) for (let dz = -hz - 1 + k; dz <= hz + 1 - k; dz++) {
        if (Math.abs(dx) === hx + 1 - k || Math.abs(dz) === hz + 1 - k) S(part.x + dx, cy + wallH + 1 + k, part.z + dz, 51);
      }
      S(part.x, cy + wallH + 4, part.z, 51); S(part.x, cy + wallH + 5, part.z, 14); S(part.x, cy + wallH + 6, part.z, 14);
      S(part.x + 1, cy + wallH + 5, part.z, 14); S(part.x - 1, cy + wallH + 5, part.z, 14);
      S(part.x, cy + wallH - 1, part.z, 85);
    } else {
      for (let k = 0; k <= hx + 1; k++) {
        const y = cy + wallH + 1 + k; const w = hx + 1 - k;
        for (let dz = -hz - 1; dz <= hz + 1; dz++) {
          S(part.x - w, y, part.z + dz, 51); S(part.x + w, y, part.z + dz, 51);
          if (w > 0 && dz >= -hz && dz <= hz) for (let dx = -w + 1; dx <= w - 1; dx++) S(part.x + dx, y, part.z + dz, 0);
        }
        if (w > 0) for (let dx = -w + 1; dx <= w - 1; dx++) for (const sgn of [-1, 1]) S(part.x + dx, y, part.z + sgn * hz, k === 0 ? corner : wall);
      }
      S(part.x, cy + wallH, part.z, 85);
      S(part.x - hx + 1, cy + 1, part.z - hz + 1, 19);
      if (r() < 0.6) S(part.x + hx - 1, cy + 1, part.z - hz + 1, 20, 0);
      if (r() < 0.5) S(part.x + hx - 1, cy + 1, part.z + hz - 1, 25);
    }
    // 门前路边火把（本项目火把为落地式）
    S(dxp + fdx, cy + 1, dzp + fdz, 21);
  }
  decorateVillages(A, cx, cz) {
    const rx = Math.floor(cx / 40), rz = Math.floor(cz / 40);
    const clip = { x0: cx * 16, z0: cz * 16, x1: cx * 16 + 15, z1: cz * 16 + 15 };
    const parts = this.villageAt(rx, rz);
    if (!parts) return;
    const vx = parts[0].x, vz = parts[0].z;
    if (Math.abs(vx - (cx * 16 + 8)) > 72 || Math.abs(vz - (cz * 16 + 8)) > 72) return;
    for (const p of parts) if (p.type === 'path') this.buildVillagePart(A, p, clip);
    for (const p of parts) if (p.type !== 'path') {
      const ext = 9;
      if (p.x + ext < clip.x0 || p.x - ext > clip.x1 || p.z + ext < clip.z0 || p.z - ext > clip.z1) continue;
      this.buildVillagePart(A, p, clip);
    }
  }

  // ---- lighting -------------------------------------------------------------
  initLight(ch) {
    const B = ch.blocks, L = ch.light;
    L.fill(0);
    const heights = new Int16Array(256);
    for (let z = 0; z < 16; z++) for (let x = 0; x < 16; x++) {
      let l = 15, top = 0;
      for (let y = HEIGHT - 1; y >= 0; y--) {
        const i = (y << 8) | (z << 4) | x, op = OPACITY[B[i]];
        if (op >= 15) l = 0; else if (op > 0 || l < 15) l = Math.max(0, l - Math.max(1, op));
        if (l === 15) top = y;
        L[i] = l << 4;
        if (l === 0) break;
      }
      heights[z * 16 + x] = top;
    }
    ch.heights = heights;
    const q = this.lightQ; q.length = 0;
    const x0 = ch.cx * 16, z0 = ch.cz * 16;
    // horizontal sky seeds
    for (let z = 0; z < 16; z++) for (let x = 0; x < 16; x++) {
      const h = heights[z * 16 + x];
      let mx = h;
      if (x > 0) mx = Math.max(mx, heights[z * 16 + x - 1]); if (x < 15) mx = Math.max(mx, heights[z * 16 + x + 1]);
      if (z > 0) mx = Math.max(mx, heights[z * 16 + x - 16]); if (z < 15) mx = Math.max(mx, heights[z * 16 + x + 16]);
      for (let y = h; y <= mx && y < HEIGHT; y++) if ((L[(y << 8) | (z << 4) | x] >> 4) > 1) q.push(x0 + x, y, z0 + z);
    }
    this.propagate(q, 4);
    // block light
    q.length = 0;
    for (let i = 0; i < B.length; i++) {
      const e = EMIT[B[i]];
      if (e) { L[i] = (L[i] & 0xF0) | e; q.push(x0 + (i & 15), i >> 8, z0 + ((i >> 4) & 15)); }
    }
    this.propagate(q, 0);
    // exchange with neighbours
    for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
      const n = this.getChunk(ch.cx + dx, ch.cz + dz);
      if (!n) continue;
      const qs = [], qb = [];
      for (let y = 0; y < HEIGHT; y++) for (let k = 0; k < 16; k++) {
        let ax, az, bx, bz; // a in ch, b in n (local)
        if (dx === 1) { ax = 15; az = k; bx = 0; bz = k; } else if (dx === -1) { ax = 0; az = k; bx = 15; bz = k; }
        else if (dz === 1) { ax = k; az = 15; bx = k; bz = 0; } else { ax = k; az = 0; bx = k; bz = 15; }
        const la = ch.light[(y << 8) | (az << 4) | ax], lb = n.light[(y << 8) | (bz << 4) | bx];
        if ((la >> 4) > 1) qs.push(x0 + ax, y, z0 + az);
        if ((lb >> 4) > 1) qs.push(n.cx * 16 + bx, y, n.cz * 16 + bz);
        if ((la & 15) > 1) qb.push(x0 + ax, y, z0 + az);
        if ((lb & 15) > 1) qb.push(n.cx * 16 + bx, y, n.cz * 16 + bz);
      }
      this.propagate(qs, 4);
      this.propagate(qb, 0);
    }
    ch.lit = true;
  }

  markLight(ch, lx, y, lz) {
    const s = 1 << (y >> 4);
    let m = s; const yy = y & 15;
    if (yy === 0 && y > 0) m |= s >> 1; else if (yy === 15) m |= s << 1;
    ch.dirty |= m;
    if (lx === 0 || lx === 15 || lz === 0 || lz === 15) {
      const dx = lx === 0 ? -1 : lx === 15 ? 1 : 0, dz = lz === 0 ? -1 : lz === 15 ? 1 : 0;
      if (dx) { const n = this.chunks.get(ckey(ch.cx + dx, ch.cz)); if (n) n.dirty |= m; }
      if (dz) { const n = this.chunks.get(ckey(ch.cx, ch.cz + dz)); if (n) n.dirty |= m; }
      if (dx && dz) { const n = this.chunks.get(ckey(ch.cx + dx, ch.cz + dz)); if (n) n.dirty |= m; }
    }
  }

  // BFS light propagation; q holds flat x,y,z triples. shift 4 = sky, 0 = block
  propagate(q, shift) {
    const sky = shift === 4;
    let head = 0;
    let cache = null, ccx = 0, ccz = 0;
    while (head < q.length) {
      const x = q[head++], y = q[head++], z = q[head++];
      const cx = x >> 4, cz = z >> 4;
      if (!cache || cx !== ccx || cz !== ccz) { cache = this.chunks.get(ckey(cx, cz)); ccx = cx; ccz = cz; }
      if (!cache) continue;
      const l = (cache.light[(y << 8) | ((z & 15) << 4) | (x & 15)] >> shift) & 15;
      if (l <= 1) continue;
      for (let d = 0; d < 6; d++) {
        const D = DIRS[d];
        const nx = x + D[0], ny = y + D[1], nz = z + D[2];
        if (ny < 0 || ny >= HEIGHT) continue;
        const nc = (nx >> 4 === cx && nz >> 4 === cz) ? cache : this.chunks.get(ckey(nx >> 4, nz >> 4));
        if (!nc) continue;
        const i = (ny << 8) | ((nz & 15) << 4) | (nx & 15);
        const op = OPACITY[nc.blocks[i]];
        if (op >= 15) continue;
        const nl = (sky && d === 2 && l === 15 && op === 0) ? 15 : l - Math.max(1, op);
        const cur = (nc.light[i] >> shift) & 15;
        if (nl > cur) {
          nc.light[i] = sky ? ((nc.light[i] & 0x0F) | (nl << 4)) : ((nc.light[i] & 0xF0) | nl);
          this.markLight(nc, nx & 15, ny, nz & 15);
          q.push(nx, ny, nz);
        }
      }
    }
    q.length = 0;
  }

  // light update after block change at x,y,z
  relight(x, y, z) {
    for (const shift of [4, 0]) {
      const sky = shift === 4;
      const rem = [], add = [];
      const ch = this.getChunk(x >> 4, z >> 4);
      const i0 = (y << 8) | ((z & 15) << 4) | (x & 15);
      const v0 = (ch.light[i0] >> shift) & 15;
      if (v0 > 0) {
        ch.light[i0] &= sky ? 0x0F : 0xF0;
        this.markLight(ch, x & 15, y, z & 15);
        rem.push(x, y, z, v0);
      }
      let h = 0;
      while (h < rem.length) {
        const rx = rem[h++], ry = rem[h++], rz = rem[h++], rv = rem[h++];
        for (let d = 0; d < 6; d++) {
          const D = DIRS[d];
          const nx = rx + D[0], ny = ry + D[1], nz = rz + D[2];
          if (ny < 0 || ny >= HEIGHT) continue;
          const nc = this.chunks.get(ckey(nx >> 4, nz >> 4));
          if (!nc) continue;
          const i = (ny << 8) | ((nz & 15) << 4) | (nx & 15);
          const nl = (nc.light[i] >> shift) & 15;
          if (nl === 0) continue;
          if (nl < rv || (sky && d === 2 && rv === 15 && nl === 15)) {
            nc.light[i] &= sky ? 0x0F : 0xF0;
            this.markLight(nc, nx & 15, ny, nz & 15);
            rem.push(nx, ny, nz, nl);
          } else add.push(nx, ny, nz);
        }
      }
      // emission
      if (!sky) {
        const e = EMIT[ch.blocks[i0]];
        if (e) { ch.light[i0] = (ch.light[i0] & 0xF0) | e; add.push(x, y, z); }
      } else if (y === HEIGHT - 1 && OPACITY[ch.blocks[i0]] === 0) { ch.light[i0] |= 0xF0; add.push(x, y, z); }
      for (let d = 0; d < 6; d++) add.push(x + DIRS[d][0], Math.max(0, Math.min(HEIGHT - 1, y + DIRS[d][1])), z + DIRS[d][2]);
      this.propagate(add, shift);
    }
  }

  // ---- block modification -----------------------------------------------------
  markBlock(ch, lx, y, lz) {
    const s = 1 << (y >> 4); let m = s;
    const yy = y & 15;
    if (yy === 0 && y > 0) m |= s >> 1; else if (yy === 15) m |= s << 1;
    ch.dirty |= m;
    if (lx === 0 || lx === 15 || lz === 0 || lz === 15) {
      const dx = lx === 0 ? -1 : lx === 15 ? 1 : 0, dz = lz === 0 ? -1 : lz === 15 ? 1 : 0;
      if (dx) { const n = this.chunks.get(ckey(ch.cx + dx, ch.cz)); if (n) n.dirty |= m; }
      if (dz) { const n = this.chunks.get(ckey(ch.cx, ch.cz + dz)); if (n) n.dirty |= m; }
      if (dx && dz) { const n = this.chunks.get(ckey(ch.cx + dx, ch.cz + dz)); if (n) n.dirty |= m; }
    }
  }

  // flags: 1 = notify neighbours, 2 = skip light
  setBlock(x, y, z, id, meta = 0, flags = 1) {
    if (y < 0 || y >= HEIGHT) return false;
    const ch = this.getChunk(x >> 4, z >> 4);
    if (!ch) return false;
    const i = (y << 8) | ((z & 15) << 4) | (x & 15);
    const old = ch.blocks[i], oldMeta = ch.meta[i];
    if (old === id && oldMeta === meta) return false;
    ch.blocks[i] = id; ch.meta[i] = meta;
    if (!old && id) ch.sectionCount[y >> 4]++; else if (old && !id) ch.sectionCount[y >> 4]--;
    ch.modified = true;
    this.markBlock(ch, x & 15, y, z & 15);
    if (!(flags & 2) && (OPACITY[old] !== OPACITY[id] || EMIT[old] !== EMIT[id])) this.relight(x, y, z);
    if (flags & 1) {
      this.notify(x, y, z, old);
      for (let d = 0; d < 6; d++) this.notify(x + DIRS[d][0], y + DIRS[d][1], z + DIRS[d][2], -1);
    }
    if (this.listener) this.listener.onBlockChanged(x, y, z, old, id, oldMeta);
    return true;
  }
  setMeta(x, y, z, meta) {
    const ch = this.getChunk(x >> 4, z >> 4);
    if (!ch || y < 0 || y >= HEIGHT) return;
    const i = (y << 8) | ((z & 15) << 4) | (x & 15);
    if (ch.meta[i] === meta) return;
    ch.meta[i] = meta; ch.modified = true;
    this.markBlock(ch, x & 15, y, z & 15);
  }

  notify(x, y, z, changedOld) {
    if (y < 0 || y >= HEIGHT) return;
    const id = this.getBlock(x, y, z);
    if (IS_FLUID[id]) this.schedule(x, y, z, id === WATER ? 5 : 30);
    if (this.listener && id) this.listener.onNeighborUpdate(x, y, z, id);
  }

  schedule(x, y, z, delay) {
    const k = `${x},${y},${z}`;
    if (!this.ticks.has(k)) this.ticks.set(k, { x, y, z, t: this.time + delay });
  }

  tickScheduled() {
    if (!this.ticks.size) return;
    const due = [];
    for (const [k, v] of this.ticks) if (v.t <= this.time) { due.push(v); this.ticks.delete(k); if (due.length > 400) break; }
    for (const t of due) this.fluidTick(t.x, t.y, t.z);
  }

  canFlowInto(id) { return id === AIR || (REPLACEABLE[id] && !IS_FLUID[id]) || (BLOCKS[id] && BLOCKS[id].needsSupport && !BLOCKS[id].solid && id !== 21 ? true : id === 21); }

  fluidTick(x, y, z) {
    if (!this.isLoaded(x, z)) return;
    const id = this.getBlock(x, y, z);
    if (!IS_FLUID[id]) return;
    let meta = this.getMeta(x, y, z);
    const water = id === WATER, drop = water ? 1 : 2, other = water ? LAVA : WATER;
    // fluid contact
    if (!water) {
      for (let d = 0; d < 6; d++) {
        if (d === 2) continue;
        if (this.getBlock(x + DIRS[d][0], y + DIRS[d][1], z + DIRS[d][2]) === WATER) {
          this.setBlock(x, y, z, meta === 0 ? 28 : 4, 0);
          if (this.listener) this.listener.onFizz(x, y, z);
          return;
        }
      }
    }
    if (meta !== 0) {
      let nm;
      const above = this.getBlock(x, y + 1, z);
      if (above === id) nm = 8;
      else {
        let min = 8, sources = 0;
        for (const d of [0, 1, 4, 5]) {
          const nx = x + DIRS[d][0], nz = z + DIRS[d][2];
          if (this.getBlock(nx, y, nz) !== id) continue;
          const m = this.getMeta(nx, y, nz);
          if (m === 0) sources++;
          min = Math.min(min, (m & 8) ? 0 : (m & 7));
        }
        const below = this.getBlock(x, y - 1, z);
        if (water && sources >= 2 && (BLOCKS[below].solid || (below === WATER && this.getMeta(x, y - 1, z) === 0))) nm = 0;
        else if (min + drop >= 8) nm = -1;
        else nm = min + drop;
      }
      if (nm !== meta) {
        if (nm < 0) { this.setBlock(x, y, z, AIR, 0); return; }
        this.setBlock(x, y, z, id, nm);
        meta = nm;
      }
    }
    // spread down
    const bid = this.getBlock(x, y - 1, z);
    if (y > 0 && (this.canFlowInto(bid) || bid === other)) {
      if (bid === other) { this.setBlock(x, y - 1, z, water ? (this.getMeta(x, y - 1, z) === 0 ? 28 : 1) : 1, 0); if (this.listener) this.listener.onFizz(x, y - 1, z); }
      else { if (bid && this.listener) this.listener.onFluidDestroy(x, y - 1, z, bid); this.setBlock(x, y - 1, z, id, 8); }
      if (meta !== 0) return;
    }
    if (bid === id && meta !== 0) return;
    const lvl = (meta & 8) ? 0 : meta;
    const nl = lvl + drop;
    if (nl >= 8) return;
    // prefer directions leading to a drop within 4 blocks
    const dirs = [0, 1, 4, 5];
    let best = 99; const dist = [99, 99, 99, 99];
    dirs.forEach((d, k) => {
      const nx = x + DIRS[d][0], nz = z + DIRS[d][2];
      const nid = this.getBlock(nx, y, nz);
      if (!(this.canFlowInto(nid) || (nid === id && (this.getMeta(nx, y, nz) & 7) > nl && !(this.getMeta(nx, y, nz) & 8)))) return;
      for (let s = 1; s <= (water ? 4 : 2); s++) {
        const px = x + DIRS[d][0] * s, pz = z + DIRS[d][2] * s;
        const pid = this.getBlock(px, y, pz);
        if (BLOCKS[pid].solid && pid !== id) break;
        const under = this.getBlock(px, y - 1, pz);
        if (this.canFlowInto(under) || under === id) { dist[k] = s; break; }
      }
      if (dist[k] === 99) dist[k] = 50;
      best = Math.min(best, dist[k]);
    });
    dirs.forEach((d, k) => {
      if (dist[k] === 99 || dist[k] !== best) return;
      const nx = x + DIRS[d][0], nz = z + DIRS[d][2];
      const nid = this.getBlock(nx, y, nz);
      if (nid === other) { this.setBlock(nx, y, nz, water ? (this.getMeta(nx, y, nz) === 0 ? 28 : 4) : 1, 0); if (this.listener) this.listener.onFizz(nx, y, nz); return; }
      if (nid && nid !== id && this.listener) this.listener.onFluidDestroy(nx, y, nz, nid);
      this.setBlock(nx, y, nz, id, nl);
    });
  }

  // ---- random ticks ----------------------------------------------------------
  randomTick(px, pz, rng) {
    const pcx = px >> 4, pcz = pz >> 4;
    for (let dx = -4; dx <= 4; dx++) for (let dz = -4; dz <= 4; dz++) {
      const ch = this.getChunk(pcx + dx, pcz + dz);
      if (!ch || !ch.lit) continue;
      for (let s = 0; s < SECTIONS; s++) {
        if (!ch.sectionCount[s]) continue;
        for (let k = 0; k < 3; k++) {
          const lx = rng.int(16), ly = (s << 4) + rng.int(16), lz = rng.int(16);
          const id = ch.blocks[(ly << 8) | (lz << 4) | lx];
          if (id && this.listener) this.listener.onRandomTick(ch.cx * 16 + lx, ly, ch.cz * 16 + lz, id, ch);
        }
      }
    }
  }
}
