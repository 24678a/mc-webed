'use strict';
// ============================================================================
// 全物品注册 + 原版创造模式选项卡（14 个，1.21.1 布局）
// 由 tools/gen_items_full.py 依据官方 1.21.1 数据生成：
//   - 物品清单/顺序 = CreativeModeTabs 反编译提取（displayItems 精确顺序）
//   - 中文名 = 官方 zh_cn.json；贴图 = 官方 item 文件夹（spawn_egg 官方染色）
//   - 新物品 ID 接在 blocks_full.js 全部物品之后，不影响旧存档方块/物品 ID
// ============================================================================

// ---- 补注册的原版缺失方块（建筑/功能选项卡中 1.21.1 有而项目原本缺少的）----
stairB('smooth_sandstone_stairs', '平滑砂岩楼梯', 'sandstone_top', { hardness: 2, tool: 'pickaxe', needsTool: true });
stairB('smooth_red_sandstone_stairs', '平滑红砂岩楼梯', 'red_sandstone_top', { hardness: 2, tool: 'pickaxe', needsTool: true });
stairB('red_nether_brick_stairs', '红色下界砖楼梯', 'red_nether_bricks', { hardness: 2, tool: 'pickaxe', needsTool: true });
slabB('red_nether_brick_slab', '红色下界砖台阶', 'red_nether_bricks', { hardness: 2, tool: 'pickaxe', needsTool: true });
wallB('red_nether_brick_wall', '红色下界砖墙', 'red_nether_bricks', { hardness: 2, tool: 'pickaxe', needsTool: true });
trapB('iron_trapdoor', '铁活板门', 'iron_trapdoor', { hardness: 5, tool: 'pickaxe', needsTool: true, sound: 'metal' });
cubeB('chorus_flower', '紫颂花', 'chorus_flower', { hardness: 0.4, sound: 'grass' });
D('chorus_plant', '紫颂植株', { shape: SH_BOXES, boxes: () => [[6, 0, 6, 10, 16, 10]], tex: 'chorus_plant', render: 'cutout', solid: false, hardness: 0.4, sound: 'grass' });
D('big_dripleaf', '大型垂滴叶', { shape: SH_BOXES, boxes: () => [[0, 13, 0, 16, 16, 16]], tex: 'big_dripleaf_top', render: 'cutout', solid: false, hardness: 0, sound: 'grass', texFn(face) { return face === 3 ? T('big_dripleaf_top') : T('big_dripleaf_side'); } });
crossB('small_dripleaf', '小型垂滴叶', 'small_dripleaf_side', { sound: 'grass' });
cubeB('heavy_core', '沉重核心', 'heavy_core', { hardness: 10, tool: 'pickaxe', needsTool: true, sound: 'metal' });
cubeB('ender_chest', '末影箱', { top: 'ender_chest_top', bottom: 'ender_chest_top', side: 'ender_chest_side', front: 'ender_chest_front' }, { facing: true, hardness: 22.5, tool: 'pickaxe', needsTool: true, sound: 'stone' });
// 饰纹陶罐：1:1 复刻原版 1.21.1 DecoratedPotRenderer（官方 client.jar 反编译校准）。
// 原版结构 = 4 块 14x16 侧面平面（x/z 内缩 1px，中空方形柱，罐身满格高 0..16）
//   + 肩部环顶面(y=16)/罐底面(y=0)（14x14，base 贴图 32-space 区域）
//   + 颈部下段 8x3x8（addBox(4,17,4,8,3,8) inflate -0.1，texOffs(0,0)）
//   + 罐口沿 6x1x6（addBox(5,20,5,6,1,6) inflate +0.2，texOffs(0,5)）
// 颈部/口沿凸出方块上表面 4px（原版如此，无碰撞；上方可正常放置方块）。
// 贴图：decorated_pot_side = 官方 16x16 原图；dpot_* = 官方 base(32x32) 各面 UV 区域裁片。
// UV 已按原版实体盒子 UV 公式逐面推导（含 up/down 面因 180° 翻转导致的取区互换与镜像）。
const DECORATED_POT_ELS = [
  // 罐身四面平面（原版 sides 层：texOffs(1,0)，14 宽 x 16 高，仅外向面）
  { from: [1, 0, 1], to: [15, 16, 1], faces: { north: [1, 0, 15, 16, 'decorated_pot_side'] } },
  { from: [1, 0, 15], to: [15, 16, 15], faces: { south: [1, 0, 15, 16, 'decorated_pot_side'] } },
  { from: [1, 0, 1], to: [1, 16, 15], faces: { west: [1, 0, 15, 16, 'decorated_pot_side'] } },
  { from: [15, 0, 1], to: [15, 16, 15], faces: { east: [1, 0, 15, 16, 'decorated_pot_side'] } },
  // 肩部环（y=16 顶面）与罐底（y=0 底面）：原版 base 区域 (14,13)-(28,27) / (0,13)-(14,27)
  { from: [1, 16, 1], to: [15, 16, 15], faces: { up: [0, 14, 14, 0, 'dpot_sh_top'] } },
  { from: [1, 0, 1], to: [15, 0, 15], faces: { down: [0, 0, 14, 14, 'dpot_sh_bottom'] } },
  // 颈部下段（原版 texOffs(0,0)，up/down 取区因 180° 翻转互换：模型顶面←原版down区(8,0)-(16,8)）
  { from: [4.1, 17, 4.1], to: [11.9, 20, 11.9], faces: {
    up: [0, 0, 8, 8, 'dpot_n1_down'], down: [0, 8, 8, 0, 'dpot_n1_up'],
    west: [8, 3, 0, 0, 'dpot_n1_west'], north: [8, 3, 0, 0, 'dpot_n1_north'],
    east: [8, 3, 0, 0, 'dpot_n1_east'], south: [8, 3, 0, 0, 'dpot_n1_south'] } },
  // 罐口沿（原版 texOffs(0,5)，同样翻转互换：模型顶面←原版down区(6,5)-(12,11)）
  { from: [4.8, 15.8, 4.8], to: [11.2, 17.2, 11.2], faces: {
    up: [0, 0, 6, 6, 'dpot_n2_down'], down: [0, 6, 6, 0, 'dpot_n2_up'],
    west: [0, 1, 6, 0, 'dpot_n2_west'], north: [6, 1, 0, 0, 'dpot_n2_north'],
    east: [6, 1, 0, 0, 'dpot_n2_east'], south: [6, 1, 0, 0, 'dpot_n2_south'] } },
].map(e => ({ from: e.from, to: e.to, rot: null, faces: Object.fromEntries(Object.entries(e.faces).map(([f, a]) => [f, [a[0], a[1], a[2], a[3], T(a[4])]])) }));
// 原版碰撞/选择盒：Block.box(1,0,1, 15,16,15)（dhy.java BOUNDING_BOX，罐身满格高）。
// 凸出上方的颈部（y16..20）无碰撞 —— 与原版一致，上方可放置方块（含花盆）。
D('decorated_pot', '饰纹陶罐', { shape: SH_MODEL, model: () => ({ els: DECORATED_POT_ELS, rot: 0 }),
  boxes: () => [[1, 0, 1, 15, 16, 15]], collisionBoxes: () => [[1, 0, 1, 15, 16, 15]],
  tex: 'decorated_pot_side', render: 'cutout', hardness: 0, sound: 'stone', stack: 1 });
doorB('iron_door', '铁门', 'iron_door_bottom', 'iron_door_top', { hardness: 5, tool: 'pickaxe', sound: 'metal' });
__flushDoorItems();  // 注册 doorB 新增的门（如铁门）的物品

// 历史遗留：拼写错误的占位物品（保留以固定后续物品 ID，旧存档兼容；不进入选项卡）
defItem('cut_standstone_slab', "切制砂岩台阶", { tex: T('cut_sandstone') });

// ---- 染色方块 ----

// ---- 自然方块 ----
defItem('pitcher_plant', "瓶子草");
defItem('cocoa_beans', "可可豆");
defItem('pumpkin_seeds', "南瓜种子");
defItem('melon_seeds', "西瓜种子");
defItem('beetroot_seeds', "甜菜种子");
defItem('torchflower_seeds', "火把花种子");
defItem('pitcher_pod', "瓶子草荚果");
defItem('glow_berries', "发光浆果");

// ---- 功能方块 ----
defItem('end_crystal', "末地水晶");
defItem('armor_stand', "盔甲架", { stack: 16 });
defItem('item_frame', "物品展示框");
defItem('glow_item_frame', "荧光物品展示框");
defItem('painting', "画");
defItem('oak_sign', "橡木告示牌", { stack: 16 });
defItem('oak_hanging_sign', "悬挂式橡木告示牌", { stack: 16 });
defItem('spruce_sign', "云杉木告示牌", { stack: 16 });
defItem('spruce_hanging_sign', "悬挂式云杉木告示牌", { stack: 16 });
defItem('birch_sign', "白桦木告示牌", { stack: 16 });
defItem('birch_hanging_sign', "悬挂式白桦木告示牌", { stack: 16 });
defItem('jungle_sign', "丛林木告示牌", { stack: 16 });
defItem('jungle_hanging_sign', "悬挂式丛林木告示牌", { stack: 16 });
defItem('acacia_sign', "金合欢木告示牌", { stack: 16 });
defItem('acacia_hanging_sign', "悬挂式金合欢木告示牌", { stack: 16 });
defItem('dark_oak_sign', "深色橡木告示牌", { stack: 16 });
defItem('dark_oak_hanging_sign', "悬挂式深色橡木告示牌", { stack: 16 });
defItem('mangrove_sign', "红树木告示牌", { stack: 16 });
defItem('mangrove_hanging_sign', "悬挂式红树木告示牌", { stack: 16 });
defItem('cherry_sign', "樱花木告示牌", { stack: 16 });
defItem('cherry_hanging_sign', "悬挂式樱花木告示牌", { stack: 16 });
defItem('bamboo_sign', "竹告示牌", { stack: 16 });
defItem('bamboo_hanging_sign', "悬挂式竹告示牌", { stack: 16 });
defItem('crimson_sign', "绯红木告示牌", { stack: 16 });
defItem('crimson_hanging_sign', "悬挂式绯红木告示牌", { stack: 16 });
defItem('warped_sign', "诡异木告示牌", { stack: 16 });
defItem('warped_hanging_sign', "悬挂式诡异木告示牌", { stack: 16 });
defItem('skeleton_skull', "骷髅头颅");
defItem('wither_skeleton_skull', "凋灵骷髅头颅");
defItem('player_head', "玩家的头");
defItem('zombie_head', "僵尸的头");
defItem('creeper_head', "苦力怕的头");
defItem('piglin_head', "猪灵的头");
defItem('dragon_head', "龙首");
defItem('ender_eye', "末影之眼");

// ---- 红石方块 ----
defItem('minecart', "矿车", { stack: 1 });
defItem('hopper_minecart', "漏斗矿车", { stack: 1 });
defItem('chest_minecart', "运输矿车", { stack: 1 });
defItem('furnace_minecart', "动力矿车", { stack: 1 });
defItem('tnt_minecart', "TNT矿车", { stack: 1 });
defItem('oak_chest_boat', "橡木运输船", { stack: 1 });
defItem('bamboo_chest_raft', "运输竹筏");
defItem('armor_stand', "盔甲架", { stack: 16 });

// ---- 工具与实用物品 ----
defItem('netherite_shovel', "下界合金锹", { stack: 1, durability: 2031, tool: { type: 'shovel', level: 4, speed: 9 }, attack: 6.5 });
defItem('netherite_pickaxe', "下界合金镐", { stack: 1, durability: 2031, tool: { type: 'pickaxe', level: 4, speed: 9 }, attack: 6 });
defItem('netherite_axe', "下界合金斧", { stack: 1, durability: 2031, tool: { type: 'axe', level: 4, speed: 9 }, attack: 10 });
defItem('netherite_hoe', "下界合金锄", { stack: 1, durability: 2031, tool: { type: 'hoe', level: 4, speed: 9 }, attack: 1 });
defItem('cod_bucket', "鳕鱼桶", { stack: 1 });
defItem('salmon_bucket', "鲑鱼桶", { stack: 1 });
defItem('tropical_fish_bucket', "热带鱼桶", { stack: 1 });
defItem('pufferfish_bucket', "河豚桶", { stack: 1 });
defItem('axolotl_bucket', "美西螈桶", { stack: 1 });
defItem('tadpole_bucket', "蝌蚪桶", { stack: 1 });
defItem('powder_snow_bucket', "细雪桶", { stack: 1 });
defItem('milk_bucket', "奶桶", { stack: 1 });
defItem('fishing_rod', "钓鱼竿", { stack: 1 });
defItem('fire_charge', "火焰弹");
defItem('brush', "刷子");
defItem('name_tag', "命名牌");
defItem('lead', "拴绳");
defItem('bundle', "收纳袋", { stack: 1 });
defItem('compass', "指南针");
defItem('recovery_compass', "追溯指针");
defItem('clock', "时钟");
defItem('spyglass', "望远镜");
defItem('map', "空地图");
defItem('writable_book', "书与笔", { stack: 1 });
defItem('wind_charge', "风弹");
defItem('ender_pearl', "末影珍珠", { stack: 16 });
defItem('ender_eye', "末影之眼");
defItem('elytra', "鞘翅", { stack: 1 });
defItem('firework_rocket', "烟花火箭");
defItem('saddle', "鞍", { stack: 1 });
defItem('carrot_on_a_stick', "胡萝卜钓竿", { stack: 1 });
defItem('warped_fungus_on_a_stick', "诡异菌钓竿", { stack: 1 });
defItem('oak_boat', "橡木船", { stack: 1 });
defItem('oak_chest_boat', "橡木运输船", { stack: 1 });
defItem('spruce_boat', "云杉木船", { stack: 1 });
defItem('spruce_chest_boat', "云杉木运输船", { stack: 1 });
defItem('birch_boat', "白桦木船", { stack: 1 });
defItem('birch_chest_boat', "白桦木运输船", { stack: 1 });
defItem('jungle_boat', "丛林木船", { stack: 1 });
defItem('jungle_chest_boat', "丛林木运输船", { stack: 1 });
defItem('acacia_boat', "金合欢木船", { stack: 1 });
defItem('acacia_chest_boat', "金合欢木运输船", { stack: 1 });
defItem('dark_oak_boat', "深色橡木船", { stack: 1 });
defItem('dark_oak_chest_boat', "深色橡木运输船", { stack: 1 });
defItem('mangrove_boat', "红树木船", { stack: 1 });
defItem('mangrove_chest_boat', "红树木运输船", { stack: 1 });
defItem('cherry_boat', "樱花木船", { stack: 1 });
defItem('cherry_chest_boat', "樱花木运输船", { stack: 1 });
defItem('bamboo_raft', "竹筏");
defItem('bamboo_chest_raft', "运输竹筏");
defItem('minecart', "矿车", { stack: 1 });
defItem('hopper_minecart', "漏斗矿车", { stack: 1 });
defItem('chest_minecart', "运输矿车", { stack: 1 });
defItem('furnace_minecart', "动力矿车", { stack: 1 });
defItem('tnt_minecart', "TNT矿车", { stack: 1 });
defItem('music_disc_13', "音乐唱片", { stack: 1 });
defItem('music_disc_cat', "音乐唱片", { stack: 1 });
defItem('music_disc_blocks', "音乐唱片", { stack: 1 });
defItem('music_disc_chirp', "音乐唱片", { stack: 1 });
defItem('music_disc_far', "音乐唱片", { stack: 1 });
defItem('music_disc_mall', "音乐唱片", { stack: 1 });
defItem('music_disc_mellohi', "音乐唱片", { stack: 1 });
defItem('music_disc_stal', "音乐唱片", { stack: 1 });
defItem('music_disc_strad', "音乐唱片", { stack: 1 });
defItem('music_disc_ward', "音乐唱片", { stack: 1 });
defItem('music_disc_11', "音乐唱片", { stack: 1 });
defItem('music_disc_creator_music_box', "音乐唱片", { stack: 1 });
defItem('music_disc_wait', "音乐唱片", { stack: 1 });
defItem('music_disc_creator', "音乐唱片", { stack: 1 });
defItem('music_disc_precipice', "音乐唱片", { stack: 1 });
defItem('music_disc_otherside', "音乐唱片", { stack: 1 });
defItem('music_disc_relic', "音乐唱片", { stack: 1 });
defItem('music_disc_5', "音乐唱片", { stack: 1 });
defItem('music_disc_pigstep', "音乐唱片", { stack: 1 });

// ---- 战斗用品 ----
defItem('netherite_sword', "下界合金剑", { stack: 1, durability: 2031, tool: { type: 'sword', level: 4, speed: 9 }, attack: 8 });
defItem('netherite_axe', "下界合金斧", { stack: 1, durability: 2031, tool: { type: 'axe', level: 4, speed: 9 }, attack: 10 });
defItem('trident', "三叉戟", { stack: 1 });
defItem('mace', "重锤", { stack: 1 });
defItem('shield', "盾牌", { stack: 1, tex: T('oak_planks') });
defItem('chainmail_helmet', "锁链头盔", { stack: 1, durability: 165, armor: { slot: 0, points: 2 } });
defItem('chainmail_chestplate', "锁链胸甲", { stack: 1, durability: 240, armor: { slot: 1, points: 5 } });
defItem('chainmail_leggings', "锁链护腿", { stack: 1, durability: 304, armor: { slot: 2, points: 4 } });
defItem('chainmail_boots', "锁链靴子", { stack: 1, durability: 208, armor: { slot: 3, points: 2 } });
defItem('golden_helmet', "金头盔", { stack: 1, durability: 77, armor: { slot: 0, points: 2 } });
defItem('golden_chestplate', "金胸甲", { stack: 1, durability: 112, armor: { slot: 1, points: 5 } });
defItem('golden_leggings', "金护腿", { stack: 1, durability: 93, armor: { slot: 2, points: 3 } });
defItem('golden_boots', "金靴子", { stack: 1, durability: 91, armor: { slot: 3, points: 1 } });
defItem('netherite_helmet', "下界合金头盔", { stack: 1, durability: 407, armor: { slot: 0, points: 3 } });
defItem('netherite_chestplate', "下界合金胸甲", { stack: 1, durability: 592, armor: { slot: 1, points: 8 } });
defItem('netherite_leggings', "下界合金护腿", { stack: 1, durability: 555, armor: { slot: 2, points: 6 } });
defItem('netherite_boots', "下界合金靴子", { stack: 1, durability: 481, armor: { slot: 3, points: 3 } });
defItem('turtle_helmet', "海龟壳", { stack: 1, durability: 275, armor: { slot: 0, points: 2 } });
defItem('leather_horse_armor', "皮革马铠", { stack: 1 });
defItem('iron_horse_armor', "铁马铠", { stack: 1 });
defItem('golden_horse_armor', "金马铠", { stack: 1 });
defItem('diamond_horse_armor', "钻石马铠", { stack: 1 });
defItem('wolf_armor', "狼铠", { stack: 1 });
defItem('totem_of_undying', "不死图腾", { stack: 1 });
defItem('end_crystal', "末地水晶");
defItem('wind_charge', "风弹");
defItem('crossbow', "弩", { stack: 1 });
defItem('firework_rocket', "烟花火箭");
defItem('spectral_arrow', "光灵箭");

// ---- 食物与饮品 ----
defItem('enchanted_golden_apple', "附魔金苹果");
defItem('glow_berries', "发光浆果");
defItem('chorus_fruit', "紫颂果", { food: [4, 2.4] });
defItem('poisonous_potato', "毒马铃薯", { food: [2, 0.6] });
defItem('beetroot', "甜菜根", { food: [1, 0.6] });
defItem('dried_kelp', "干海带", { food: [1, 0.6] });
defItem('rabbit', "生兔肉", { food: [3, 1.8] });
defItem('cooked_rabbit', "熟兔肉", { food: [5, 6] });
defItem('salmon', "生鲑鱼", { food: [2, 0.4] });
defItem('cooked_salmon', "熟鲑鱼", { food: [6, 9.6] });
defItem('tropical_fish', "热带鱼", { food: [1, 0.2] });
defItem('pufferfish', "河豚");
defItem('spider_eye', "蜘蛛眼", { food: [2, 3.2] });
defItem('beetroot_soup', "甜菜汤", { food: [6, 7.2] });
defItem('rabbit_stew', "兔肉煲", { food: [10, 12] });
defItem('suspicious_stew', "谜之炖菜", { food: [6, 7.2] });
defItem('milk_bucket', "奶桶", { stack: 1 });
defItem('honey_bottle', "蜂蜜瓶", { food: [6, 1.2] });
defItem('ominous_bottle', "不祥之瓶");

// ---- 原材料 ----
defItem('iron_nugget', "铁粒");
defItem('gold_nugget', "金粒");
defItem('copper_ingot', "铜锭");
defItem('netherite_scrap', "下界合金碎片");
defItem('netherite_ingot', "下界合金锭");
defItem('rabbit_hide', "兔子皮");
defItem('honeycomb', "蜜脾");
defItem('ink_sac', "墨囊");
defItem('glow_ink_sac', "荧光墨囊");
defItem('turtle_scute', "海龟鳞甲");
defItem('armadillo_scute', "犰狳鳞甲");
defItem('slime_ball', "黏液球");
defItem('prismarine_shard', "海晶碎片");
defItem('prismarine_crystals', "海晶砂粒");
defItem('nautilus_shell', "鹦鹉螺壳");
defItem('heart_of_the_sea', "海洋之心");
defItem('fire_charge', "火焰弹");
defItem('blaze_rod', "烈焰棒");
defItem('breeze_rod', "旋风棒");
defItem('nether_star', "下界之星");
defItem('ender_pearl', "末影珍珠", { stack: 16 });
defItem('ender_eye', "末影之眼");
defItem('shulker_shell', "潜影壳");
defItem('popped_chorus_fruit', "爆裂紫颂果");
defItem('echo_shard', "回响碎片");
defItem('disc_fragment_5', "唱片残片");
defItem('white_dye', "白色染料");
defItem('light_gray_dye', "淡灰色染料");
defItem('gray_dye', "灰色染料");
defItem('black_dye', "黑色染料");
defItem('brown_dye', "棕色染料");
defItem('red_dye', "红色染料");
defItem('orange_dye', "橙色染料");
defItem('yellow_dye', "黄色染料");
defItem('lime_dye', "黄绿色染料");
defItem('green_dye', "绿色染料");
defItem('cyan_dye', "青色染料");
defItem('light_blue_dye', "淡蓝色染料");
defItem('blue_dye', "蓝色染料");
defItem('purple_dye', "紫色染料");
defItem('magenta_dye', "品红色染料");
defItem('pink_dye', "粉红色染料");
defItem('nether_brick', "下界砖");
defItem('firework_star', "烟火之星");
defItem('glass_bottle', "玻璃瓶");
defItem('glowstone_dust', "荧石粉");
defItem('dragon_breath', "龙息");
defItem('fermented_spider_eye', "发酵蛛眼");
defItem('blaze_powder', "烈焰粉");
defItem('rabbit_foot', "兔子脚");
defItem('glistering_melon_slice', "闪烁的西瓜片");
defItem('spider_eye', "蜘蛛眼", { food: [2, 3.2] });
defItem('pufferfish', "河豚");
defItem('magma_cream', "岩浆膏");
defItem('ghast_tear', "恶魂之泪");
defItem('turtle_helmet', "海龟壳", { stack: 1, durability: 275, armor: { slot: 0, points: 2 } });
defItem('phantom_membrane', "幻翼膜");
defItem('flower_banner_pattern', "旗帜图案");
defItem('creeper_banner_pattern', "旗帜图案");
defItem('skull_banner_pattern', "旗帜图案");
defItem('mojang_banner_pattern', "旗帜图案");
defItem('globe_banner_pattern', "旗帜图案");
defItem('piglin_banner_pattern', "旗帜图案");
defItem('flow_banner_pattern', "旗帜图案");
defItem('guster_banner_pattern', "旗帜图案");
defItem('angler_pottery_sherd', "垂钓纹样陶片");
defItem('archer_pottery_sherd', "弓箭纹样陶片");
defItem('arms_up_pottery_sherd', "举臂纹样陶片");
defItem('blade_pottery_sherd', "利刃纹样陶片");
defItem('brewer_pottery_sherd', "佳酿纹样陶片");
defItem('burn_pottery_sherd', "烈焰纹样陶片");
defItem('danger_pottery_sherd', "危机纹样陶片");
defItem('flow_pottery_sherd', "涡流纹样陶片");
defItem('explorer_pottery_sherd', "探险纹样陶片");
defItem('friend_pottery_sherd', "挚友纹样陶片");
defItem('guster_pottery_sherd', "旋风纹样陶片");
defItem('heart_pottery_sherd', "爱心纹样陶片");
defItem('heartbreak_pottery_sherd', "心碎纹样陶片");
defItem('howl_pottery_sherd', "狼嚎纹样陶片");
defItem('miner_pottery_sherd', "采矿纹样陶片");
defItem('mourner_pottery_sherd', "悲恸纹样陶片");
defItem('plenty_pottery_sherd', "富饶纹样陶片");
defItem('prize_pottery_sherd', "珍宝纹样陶片");
defItem('scrape_pottery_sherd', "刮削纹样陶片");
defItem('sheaf_pottery_sherd', "麦捆纹样陶片");
defItem('shelter_pottery_sherd', "树荫纹样陶片");
defItem('skull_pottery_sherd', "头颅纹样陶片");
defItem('snort_pottery_sherd', "嗅探纹样陶片");
defItem('netherite_upgrade_smithing_template', "锻造模板");
defItem('sentry_armor_trim_smithing_template', "锻造模板", { stack: 1 });
defItem('vex_armor_trim_smithing_template', "锻造模板", { stack: 1 });
defItem('wild_armor_trim_smithing_template', "锻造模板", { stack: 1 });
defItem('coast_armor_trim_smithing_template', "锻造模板", { stack: 1 });
defItem('dune_armor_trim_smithing_template', "锻造模板", { stack: 1 });
defItem('wayfinder_armor_trim_smithing_template', "锻造模板", { stack: 1 });
defItem('raiser_armor_trim_smithing_template', "锻造模板", { stack: 1 });
defItem('shaper_armor_trim_smithing_template', "锻造模板", { stack: 1 });
defItem('host_armor_trim_smithing_template', "锻造模板", { stack: 1 });
defItem('ward_armor_trim_smithing_template', "锻造模板", { stack: 1 });
defItem('silence_armor_trim_smithing_template', "锻造模板", { stack: 1 });
defItem('tide_armor_trim_smithing_template', "锻造模板", { stack: 1 });
defItem('snout_armor_trim_smithing_template', "锻造模板", { stack: 1 });
defItem('rib_armor_trim_smithing_template', "锻造模板", { stack: 1 });
defItem('eye_armor_trim_smithing_template', "锻造模板", { stack: 1 });
defItem('spire_armor_trim_smithing_template', "锻造模板", { stack: 1 });
defItem('flow_armor_trim_smithing_template', "锻造模板", { stack: 1 });
defItem('bolt_armor_trim_smithing_template', "锻造模板", { stack: 1 });
defItem('experience_bottle', "附魔之瓶");
defItem('trial_key', "试炼钥匙");
defItem('ominous_trial_key', "不祥试炼钥匙");

// ---- 刷怪蛋 ----
defItem('allay_spawn_egg', "悦灵刷怪蛋");
defItem('armadillo_spawn_egg', "犰狳刷怪蛋");
defItem('axolotl_spawn_egg', "美西螈刷怪蛋");
defItem('bat_spawn_egg', "蝙蝠刷怪蛋");
defItem('bee_spawn_egg', "蜜蜂刷怪蛋");
defItem('blaze_spawn_egg', "烈焰人刷怪蛋");
defItem('bogged_spawn_egg', "沼骸刷怪蛋");
defItem('breeze_spawn_egg', "旋风人刷怪蛋");
defItem('camel_spawn_egg', "骆驼刷怪蛋");
defItem('cat_spawn_egg', "猫刷怪蛋");
defItem('cave_spider_spawn_egg', "洞穴蜘蛛刷怪蛋");
defItem('cod_spawn_egg', "鳕鱼刷怪蛋");
defItem('dolphin_spawn_egg', "海豚刷怪蛋");
defItem('donkey_spawn_egg', "驴刷怪蛋");
defItem('drowned_spawn_egg', "溺尸刷怪蛋");
defItem('elder_guardian_spawn_egg', "远古守卫者刷怪蛋");
defItem('enderman_spawn_egg', "末影人刷怪蛋");
defItem('endermite_spawn_egg', "末影螨刷怪蛋");
defItem('evoker_spawn_egg', "唤魔者刷怪蛋");
defItem('fox_spawn_egg', "狐狸刷怪蛋");
defItem('frog_spawn_egg', "青蛙刷怪蛋");
defItem('ghast_spawn_egg', "恶魂刷怪蛋");
defItem('glow_squid_spawn_egg', "发光鱿鱼刷怪蛋");
defItem('goat_spawn_egg', "山羊刷怪蛋");
defItem('guardian_spawn_egg', "守卫者刷怪蛋");
defItem('hoglin_spawn_egg', "疣猪兽刷怪蛋");
defItem('horse_spawn_egg', "马刷怪蛋");
defItem('husk_spawn_egg', "尸壳刷怪蛋");
defItem('iron_golem_spawn_egg', "铁傀儡刷怪蛋");
defItem('llama_spawn_egg', "羊驼刷怪蛋");
defItem('magma_cube_spawn_egg', "岩浆怪刷怪蛋");
defItem('mooshroom_spawn_egg', "哞菇刷怪蛋");
defItem('mule_spawn_egg', "骡刷怪蛋");
defItem('ocelot_spawn_egg', "豹猫刷怪蛋");
defItem('panda_spawn_egg', "熊猫刷怪蛋");
defItem('parrot_spawn_egg', "鹦鹉刷怪蛋");
defItem('phantom_spawn_egg', "幻翼刷怪蛋");
defItem('piglin_spawn_egg', "猪灵刷怪蛋");
defItem('piglin_brute_spawn_egg', "猪灵蛮兵刷怪蛋");
defItem('pillager_spawn_egg', "掠夺者刷怪蛋");
defItem('polar_bear_spawn_egg', "北极熊刷怪蛋");
defItem('pufferfish_spawn_egg', "河豚刷怪蛋");
defItem('rabbit_spawn_egg', "兔子刷怪蛋");
defItem('ravager_spawn_egg', "劫掠兽刷怪蛋");
defItem('salmon_spawn_egg', "鲑鱼刷怪蛋");
defItem('shulker_spawn_egg', "潜影贝刷怪蛋");
defItem('silverfish_spawn_egg', "蠹虫刷怪蛋");
defItem('skeleton_horse_spawn_egg', "骷髅马刷怪蛋");
defItem('slime_spawn_egg', "史莱姆刷怪蛋");
defItem('sniffer_spawn_egg', "嗅探兽刷怪蛋");
defItem('snow_golem_spawn_egg', "雪傀儡刷怪蛋");
defItem('squid_spawn_egg', "鱿鱼刷怪蛋");
defItem('stray_spawn_egg', "流浪者刷怪蛋");
defItem('strider_spawn_egg', "炽足兽刷怪蛋");
defItem('tadpole_spawn_egg', "蝌蚪刷怪蛋");
defItem('trader_llama_spawn_egg', "行商羊驼刷怪蛋");
defItem('tropical_fish_spawn_egg', "热带鱼刷怪蛋");
defItem('turtle_spawn_egg', "海龟刷怪蛋");
defItem('vex_spawn_egg', "恼鬼刷怪蛋");
defItem('villager_spawn_egg', "村民刷怪蛋");
defItem('vindicator_spawn_egg', "卫道士刷怪蛋");
defItem('wandering_trader_spawn_egg', "流浪商人刷怪蛋");
defItem('warden_spawn_egg', "监守者刷怪蛋");
defItem('witch_spawn_egg', "女巫刷怪蛋");
defItem('wither_skeleton_spawn_egg', "凋灵骷髅刷怪蛋");
defItem('wolf_spawn_egg', "狼刷怪蛋");
defItem('zoglin_spawn_egg', "僵尸疣猪兽刷怪蛋");
defItem('zombie_horse_spawn_egg', "僵尸马刷怪蛋");
defItem('zombie_villager_spawn_egg', "僵尸村民刷怪蛋");
defItem('zombified_piglin_spawn_egg', "僵尸猪灵刷怪蛋");

// ---- 管理员用品 ----
defItem('command_block_minecart', "命令方块矿车", { stack: 1 });
defItem('structure_void', "结构空位");
defItem('barrier', "屏障");
defItem('debug_stick', "调试棒", { stack: 1 });
defItem('light', "光源方块");

// ---- 原版 1.21.1 创造模式选项卡（row: 0=上排 1=下排；x: 面板左缘起 27px 栏距；右对齐组右缘对齐）----
const CREATIVE_TABS = [
  { name: "建筑方块", icon: 'bricks', row: 0, col: 0, x: 0, items: [
    'oak_log', 'oak_wood', 'stripped_oak_log', 'stripped_oak_wood', 'oak_planks', 'oak_stairs', 'oak_slab', 'oak_fence',
    'oak_fence_gate', 'oak_door', 'oak_trapdoor', 'oak_pressure_plate', 'oak_button', 'spruce_log', 'spruce_wood', 'stripped_spruce_log',
    'stripped_spruce_wood', 'spruce_planks', 'spruce_stairs', 'spruce_slab', 'spruce_fence', 'spruce_fence_gate', 'spruce_door', 'spruce_trapdoor',
    'spruce_pressure_plate', 'spruce_button', 'birch_log', 'birch_wood', 'stripped_birch_log', 'stripped_birch_wood', 'birch_planks', 'birch_stairs',
    'birch_slab', 'birch_fence', 'birch_fence_gate', 'birch_door', 'birch_trapdoor', 'birch_pressure_plate', 'birch_button', 'jungle_log',
    'jungle_wood', 'stripped_jungle_log', 'stripped_jungle_wood', 'jungle_planks', 'jungle_stairs', 'jungle_slab', 'jungle_fence', 'jungle_fence_gate',
    'jungle_door', 'jungle_trapdoor', 'jungle_pressure_plate', 'jungle_button', 'acacia_log', 'acacia_wood', 'stripped_acacia_log', 'stripped_acacia_wood',
    'acacia_planks', 'acacia_stairs', 'acacia_slab', 'acacia_fence', 'acacia_fence_gate', 'acacia_door', 'acacia_trapdoor', 'acacia_pressure_plate',
    'acacia_button', 'dark_oak_log', 'dark_oak_wood', 'stripped_dark_oak_log', 'stripped_dark_oak_wood', 'dark_oak_planks', 'dark_oak_stairs', 'dark_oak_slab',
    'dark_oak_fence', 'dark_oak_fence_gate', 'dark_oak_door', 'dark_oak_trapdoor', 'dark_oak_pressure_plate', 'dark_oak_button', 'mangrove_log', 'mangrove_wood',
    'stripped_mangrove_log', 'stripped_mangrove_wood', 'mangrove_planks', 'mangrove_stairs', 'mangrove_slab', 'mangrove_fence', 'mangrove_fence_gate', 'mangrove_door',
    'mangrove_trapdoor', 'mangrove_pressure_plate', 'mangrove_button', 'cherry_log', 'cherry_wood', 'stripped_cherry_log', 'stripped_cherry_wood', 'cherry_planks',
    'cherry_stairs', 'cherry_slab', 'cherry_fence', 'cherry_fence_gate', 'cherry_door', 'cherry_trapdoor', 'cherry_pressure_plate', 'cherry_button',
    'bamboo_block', 'stripped_bamboo_block', 'bamboo_planks', 'bamboo_mosaic', 'bamboo_stairs', 'bamboo_mosaic_stairs', 'bamboo_slab', 'bamboo_mosaic_slab',
    'bamboo_fence', 'bamboo_fence_gate', 'bamboo_door', 'bamboo_trapdoor', 'bamboo_pressure_plate', 'bamboo_button', 'crimson_stem', 'crimson_hyphae',
    'stripped_crimson_stem', 'stripped_crimson_hyphae', 'crimson_planks', 'crimson_stairs', 'crimson_slab', 'crimson_fence', 'crimson_fence_gate', 'crimson_door',
    'crimson_trapdoor', 'crimson_pressure_plate', 'crimson_button', 'warped_stem', 'warped_hyphae', 'stripped_warped_stem', 'stripped_warped_hyphae', 'warped_planks',
    'warped_stairs', 'warped_slab', 'warped_fence', 'warped_fence_gate', 'warped_door', 'warped_trapdoor', 'warped_pressure_plate', 'warped_button',
    'stone', 'stone_stairs', 'stone_slab', 'stone_pressure_plate', 'stone_button', 'cobblestone', 'cobblestone_stairs', 'cobblestone_slab',
    'cobblestone_wall', 'mossy_cobblestone', 'mossy_cobblestone_stairs', 'mossy_cobblestone_slab', 'mossy_cobblestone_wall', 'smooth_stone', 'smooth_stone_slab', 'stone_bricks',
    'cracked_stone_bricks', 'stone_brick_stairs', 'stone_brick_slab', 'stone_brick_wall', 'chiseled_stone_bricks', 'mossy_stone_bricks', 'mossy_stone_brick_stairs', 'mossy_stone_brick_slab',
    'mossy_stone_brick_wall', 'granite', 'granite_stairs', 'granite_slab', 'granite_wall', 'polished_granite', 'polished_granite_stairs', 'polished_granite_slab',
    'diorite', 'diorite_stairs', 'diorite_slab', 'diorite_wall', 'polished_diorite', 'polished_diorite_stairs', 'polished_diorite_slab', 'andesite',
    'andesite_stairs', 'andesite_slab', 'andesite_wall', 'polished_andesite', 'polished_andesite_stairs', 'polished_andesite_slab', 'deepslate', 'cobbled_deepslate',
    'cobbled_deepslate_stairs', 'cobbled_deepslate_slab', 'cobbled_deepslate_wall', 'chiseled_deepslate', 'polished_deepslate', 'polished_deepslate_stairs', 'polished_deepslate_slab', 'polished_deepslate_wall',
    'deepslate_bricks', 'cracked_deepslate_bricks', 'deepslate_brick_stairs', 'deepslate_brick_slab', 'deepslate_brick_wall', 'deepslate_tiles', 'cracked_deepslate_tiles', 'deepslate_tile_stairs',
    'deepslate_tile_slab', 'deepslate_tile_wall', 'reinforced_deepslate', 'tuff', 'tuff_stairs', 'tuff_slab', 'tuff_wall', 'chiseled_tuff',
    'polished_tuff', 'polished_tuff_stairs', 'polished_tuff_slab', 'polished_tuff_wall', 'tuff_bricks', 'tuff_brick_stairs', 'tuff_brick_slab', 'tuff_brick_wall',
    'chiseled_tuff_bricks', 'bricks', 'brick_stairs', 'brick_slab', 'brick_wall', 'packed_mud', 'mud_bricks', 'mud_brick_stairs',
    'mud_brick_slab', 'mud_brick_wall', 'sandstone', 'sandstone_stairs', 'sandstone_slab', 'sandstone_wall', 'chiseled_sandstone', 'smooth_sandstone',
    'smooth_sandstone_stairs', 'smooth_sandstone_slab', 'cut_sandstone', 'cut_sandstone_slab', 'red_sandstone', 'red_sandstone_stairs', 'red_sandstone_slab', 'red_sandstone_wall',
    'chiseled_red_sandstone', 'smooth_red_sandstone', 'smooth_red_sandstone_stairs', 'smooth_red_sandstone_slab', 'cut_red_sandstone', 'cut_red_sandstone_slab', 'sea_lantern', 'prismarine',
    'prismarine_stairs', 'prismarine_slab', 'prismarine_wall', 'prismarine_bricks', 'prismarine_brick_stairs', 'prismarine_brick_slab', 'dark_prismarine', 'dark_prismarine_stairs',
    'dark_prismarine_slab', 'netherrack', 'nether_bricks', 'cracked_nether_bricks', 'nether_brick_stairs', 'nether_brick_slab', 'nether_brick_wall', 'nether_brick_fence',
    'chiseled_nether_bricks', 'red_nether_bricks', 'red_nether_brick_stairs', 'red_nether_brick_slab', 'red_nether_brick_wall', 'basalt', 'smooth_basalt', 'polished_basalt',
    'blackstone', 'gilded_blackstone', 'blackstone_stairs', 'blackstone_slab', 'blackstone_wall', 'chiseled_polished_blackstone', 'polished_blackstone', 'polished_blackstone_stairs',
    'polished_blackstone_slab', 'polished_blackstone_wall', 'polished_blackstone_pressure_plate', 'polished_blackstone_button', 'polished_blackstone_bricks', 'cracked_polished_blackstone_bricks', 'polished_blackstone_brick_stairs', 'polished_blackstone_brick_slab',
    'polished_blackstone_brick_wall', 'end_stone', 'end_stone_bricks', 'end_stone_brick_stairs', 'end_stone_brick_slab', 'end_stone_brick_wall', 'purpur_block', 'purpur_pillar',
    'purpur_stairs', 'purpur_slab', 'coal_block', 'iron_block', 'iron_bars', 'iron_door', 'iron_trapdoor', 'heavy_weighted_pressure_plate',
    'chain', 'gold_block', 'light_weighted_pressure_plate', 'redstone_block', 'emerald_block', 'lapis_block', 'diamond_block', 'netherite_block',
    'quartz_block', 'quartz_stairs', 'quartz_slab', 'chiseled_quartz_block', 'quartz_bricks', 'quartz_pillar', 'smooth_quartz', 'smooth_quartz_stairs',
    'smooth_quartz_slab', 'amethyst_block', 'copper_block', 'chiseled_copper', 'copper_grate', 'cut_copper', 'cut_copper_stairs', 'cut_copper_slab',
    'copper_door', 'copper_trapdoor', 'copper_bulb', 'exposed_copper', 'exposed_chiseled_copper', 'exposed_copper_grate', 'exposed_cut_copper', 'exposed_cut_copper_stairs',
    'exposed_cut_copper_slab', 'exposed_copper_door', 'exposed_copper_trapdoor', 'exposed_copper_bulb', 'weathered_copper', 'weathered_chiseled_copper', 'weathered_copper_grate', 'weathered_cut_copper',
    'weathered_cut_copper_stairs', 'weathered_cut_copper_slab', 'weathered_copper_door', 'weathered_copper_trapdoor', 'weathered_copper_bulb', 'oxidized_copper', 'oxidized_chiseled_copper', 'oxidized_copper_grate',
    'oxidized_cut_copper', 'oxidized_cut_copper_stairs', 'oxidized_cut_copper_slab', 'oxidized_copper_door', 'oxidized_copper_trapdoor', 'oxidized_copper_bulb', 'waxed_copper_block', 'waxed_chiseled_copper',
    'waxed_copper_grate', 'waxed_cut_copper', 'waxed_cut_copper_stairs', 'waxed_cut_copper_slab', 'waxed_copper_door', 'waxed_copper_trapdoor', 'waxed_copper_bulb', 'waxed_exposed_copper',
    'waxed_exposed_chiseled_copper', 'waxed_exposed_copper_grate', 'waxed_exposed_cut_copper', 'waxed_exposed_cut_copper_stairs', 'waxed_exposed_cut_copper_slab', 'waxed_exposed_copper_door', 'waxed_exposed_copper_trapdoor', 'waxed_exposed_copper_bulb',
    'waxed_weathered_copper', 'waxed_weathered_chiseled_copper', 'waxed_weathered_copper_grate', 'waxed_weathered_cut_copper', 'waxed_weathered_cut_copper_stairs', 'waxed_weathered_cut_copper_slab', 'waxed_weathered_copper_door', 'waxed_weathered_copper_trapdoor',
    'waxed_weathered_copper_bulb', 'waxed_oxidized_copper', 'waxed_oxidized_chiseled_copper', 'waxed_oxidized_copper_grate', 'waxed_oxidized_cut_copper', 'waxed_oxidized_cut_copper_stairs', 'waxed_oxidized_cut_copper_slab', 'waxed_oxidized_copper_door',
    'waxed_oxidized_copper_trapdoor', 'waxed_oxidized_copper_bulb',
  ] },
  { name: "染色方块", icon: 'cyan_wool', row: 0, col: 1, x: 27, items: [
    'white_wool', 'light_gray_wool', 'gray_wool', 'black_wool', 'brown_wool', 'red_wool', 'orange_wool', 'yellow_wool',
    'lime_wool', 'green_wool', 'cyan_wool', 'light_blue_wool', 'blue_wool', 'purple_wool', 'magenta_wool', 'pink_wool',
    'white_carpet', 'light_gray_carpet', 'gray_carpet', 'black_carpet', 'brown_carpet', 'red_carpet', 'orange_carpet', 'yellow_carpet',
    'lime_carpet', 'green_carpet', 'cyan_carpet', 'light_blue_carpet', 'blue_carpet', 'purple_carpet', 'magenta_carpet', 'pink_carpet',
    'terracotta', 'white_terracotta', 'light_gray_terracotta', 'gray_terracotta', 'black_terracotta', 'brown_terracotta', 'red_terracotta', 'orange_terracotta',
    'yellow_terracotta', 'lime_terracotta', 'green_terracotta', 'cyan_terracotta', 'light_blue_terracotta', 'blue_terracotta', 'purple_terracotta', 'magenta_terracotta',
    'pink_terracotta', 'white_concrete', 'light_gray_concrete', 'gray_concrete', 'black_concrete', 'brown_concrete', 'red_concrete', 'orange_concrete',
    'yellow_concrete', 'lime_concrete', 'green_concrete', 'cyan_concrete', 'light_blue_concrete', 'blue_concrete', 'purple_concrete', 'magenta_concrete',
    'pink_concrete', 'white_concrete_powder', 'light_gray_concrete_powder', 'gray_concrete_powder', 'black_concrete_powder', 'brown_concrete_powder', 'red_concrete_powder', 'orange_concrete_powder',
    'yellow_concrete_powder', 'lime_concrete_powder', 'green_concrete_powder', 'cyan_concrete_powder', 'light_blue_concrete_powder', 'blue_concrete_powder', 'purple_concrete_powder', 'magenta_concrete_powder',
    'pink_concrete_powder', 'white_glazed_terracotta', 'light_gray_glazed_terracotta', 'gray_glazed_terracotta', 'black_glazed_terracotta', 'brown_glazed_terracotta', 'red_glazed_terracotta', 'orange_glazed_terracotta',
    'yellow_glazed_terracotta', 'lime_glazed_terracotta', 'green_glazed_terracotta', 'cyan_glazed_terracotta', 'light_blue_glazed_terracotta', 'blue_glazed_terracotta', 'purple_glazed_terracotta', 'magenta_glazed_terracotta',
    'pink_glazed_terracotta', 'glass', 'tinted_glass', 'white_stained_glass', 'light_gray_stained_glass', 'gray_stained_glass', 'black_stained_glass', 'brown_stained_glass',
    'red_stained_glass', 'orange_stained_glass', 'yellow_stained_glass', 'lime_stained_glass', 'green_stained_glass', 'cyan_stained_glass', 'light_blue_stained_glass', 'blue_stained_glass',
    'purple_stained_glass', 'magenta_stained_glass', 'pink_stained_glass', 'glass_pane', 'white_stained_glass_pane', 'light_gray_stained_glass_pane', 'gray_stained_glass_pane', 'black_stained_glass_pane',
    'brown_stained_glass_pane', 'red_stained_glass_pane', 'orange_stained_glass_pane', 'yellow_stained_glass_pane', 'lime_stained_glass_pane', 'green_stained_glass_pane', 'cyan_stained_glass_pane', 'light_blue_stained_glass_pane',
    'blue_stained_glass_pane', 'purple_stained_glass_pane', 'magenta_stained_glass_pane', 'pink_stained_glass_pane', 'shulker_box', 'white_shulker_box', 'light_gray_shulker_box', 'gray_shulker_box',
    'black_shulker_box', 'brown_shulker_box', 'red_shulker_box', 'orange_shulker_box', 'yellow_shulker_box', 'lime_shulker_box', 'green_shulker_box', 'cyan_shulker_box',
    'light_blue_shulker_box', 'blue_shulker_box', 'purple_shulker_box', 'magenta_shulker_box', 'pink_shulker_box', 'white_bed', 'light_gray_bed', 'gray_bed',
    'black_bed', 'brown_bed', 'red_bed', 'orange_bed', 'yellow_bed', 'lime_bed', 'green_bed', 'cyan_bed',
    'light_blue_bed', 'blue_bed', 'purple_bed', 'magenta_bed', 'pink_bed', 'candle', 'white_candle', 'light_gray_candle',
    'gray_candle', 'black_candle', 'brown_candle', 'red_candle', 'orange_candle', 'yellow_candle', 'lime_candle', 'green_candle',
    'cyan_candle', 'light_blue_candle', 'blue_candle', 'purple_candle', 'magenta_candle', 'pink_candle', 'white_banner', 'light_gray_banner',
    'gray_banner', 'black_banner', 'brown_banner', 'red_banner', 'orange_banner', 'yellow_banner', 'lime_banner', 'green_banner',
    'cyan_banner', 'light_blue_banner', 'blue_banner', 'purple_banner', 'magenta_banner', 'pink_banner',
  ] },
  { name: "自然方块", icon: 'grass_block', row: 0, col: 2, x: 54, items: [
    'grass_block', 'podzol', 'mycelium', 'dirt_path', 'dirt', 'coarse_dirt', 'rooted_dirt', 'farmland',
    'mud', 'clay', 'gravel', 'sand', 'sandstone', 'red_sand', 'red_sandstone', 'ice',
    'packed_ice', 'blue_ice', 'snow_block', 'snow', 'moss_block', 'moss_carpet', 'stone', 'deepslate',
    'granite', 'diorite', 'andesite', 'calcite', 'tuff', 'dripstone_block', 'pointed_dripstone', 'prismarine',
    'magma_block', 'obsidian', 'crying_obsidian', 'netherrack', 'crimson_nylium', 'warped_nylium', 'soul_sand', 'soul_soil',
    'bone_block', 'blackstone', 'basalt', 'smooth_basalt', 'end_stone', 'coal_ore', 'deepslate_coal_ore', 'iron_ore',
    'deepslate_iron_ore', 'copper_ore', 'deepslate_copper_ore', 'gold_ore', 'deepslate_gold_ore', 'redstone_ore', 'deepslate_redstone_ore', 'emerald_ore',
    'deepslate_emerald_ore', 'lapis_ore', 'deepslate_lapis_ore', 'diamond_ore', 'deepslate_diamond_ore', 'nether_gold_ore', 'nether_quartz_ore', 'ancient_debris',
    'raw_iron_block', 'raw_copper_block', 'raw_gold_block', 'glowstone', 'amethyst_block', 'budding_amethyst', 'small_amethyst_bud', 'medium_amethyst_bud',
    'large_amethyst_bud', 'amethyst_cluster', 'oak_log', 'spruce_log', 'birch_log', 'jungle_log', 'acacia_log', 'dark_oak_log',
    'mangrove_log', 'mangrove_roots', 'muddy_mangrove_roots', 'cherry_log', 'mushroom_stem', 'crimson_stem', 'warped_stem', 'oak_leaves',
    'spruce_leaves', 'birch_leaves', 'jungle_leaves', 'acacia_leaves', 'dark_oak_leaves', 'mangrove_leaves', 'cherry_leaves', 'azalea_leaves',
    'flowering_azalea_leaves', 'brown_mushroom_block', 'red_mushroom_block', 'nether_wart_block', 'warped_wart_block', 'shroomlight', 'oak_sapling', 'spruce_sapling',
    'birch_sapling', 'jungle_sapling', 'acacia_sapling', 'dark_oak_sapling', 'mangrove_propagule', 'cherry_sapling', 'azalea', 'flowering_azalea',
    'brown_mushroom', 'red_mushroom', 'crimson_fungus', 'warped_fungus', 'short_grass', 'fern', 'dead_bush', 'dandelion',
    'poppy', 'blue_orchid', 'allium', 'azure_bluet', 'red_tulip', 'orange_tulip', 'white_tulip', 'pink_tulip',
    'oxeye_daisy', 'cornflower', 'lily_of_the_valley', 'torchflower', 'wither_rose', 'pink_petals', 'spore_blossom', 'bamboo',
    'sugar_cane', 'cactus', 'crimson_roots', 'warped_roots', 'nether_sprouts', 'weeping_vines', 'twisting_vines', 'vine',
    'tall_grass', 'large_fern', 'sunflower', 'lilac', 'rose_bush', 'peony', 'pitcher_plant', 'big_dripleaf',
    'small_dripleaf', 'chorus_plant', 'chorus_flower', 'glow_lichen', 'hanging_roots', 'frogspawn', 'turtle_egg', 'sniffer_egg',
    'wheat_seeds', 'cocoa_beans', 'pumpkin_seeds', 'melon_seeds', 'beetroot_seeds', 'torchflower_seeds', 'pitcher_pod', 'glow_berries',
    'sweet_berries', 'nether_wart', 'lily_pad', 'seagrass', 'sea_pickle', 'kelp', 'dried_kelp_block', 'tube_coral_block',
    'brain_coral_block', 'bubble_coral_block', 'fire_coral_block', 'horn_coral_block', 'dead_tube_coral_block', 'dead_brain_coral_block', 'dead_bubble_coral_block', 'dead_fire_coral_block',
    'dead_horn_coral_block', 'tube_coral', 'brain_coral', 'bubble_coral', 'fire_coral', 'horn_coral', 'dead_tube_coral', 'dead_brain_coral',
    'dead_bubble_coral', 'dead_fire_coral', 'dead_horn_coral', 'tube_coral_fan', 'brain_coral_fan', 'bubble_coral_fan', 'fire_coral_fan', 'horn_coral_fan',
    'dead_tube_coral_fan', 'dead_brain_coral_fan', 'dead_bubble_coral_fan', 'dead_fire_coral_fan', 'dead_horn_coral_fan', 'sponge', 'wet_sponge', 'melon',
    'pumpkin', 'carved_pumpkin', 'jack_o_lantern', 'hay_block', 'bee_nest', 'honeycomb_block', 'slime_block', 'honey_block',
    'ochre_froglight', 'verdant_froglight', 'pearlescent_froglight', 'sculk', 'sculk_vein', 'sculk_catalyst', 'sculk_shrieker', 'sculk_sensor',
    'cobweb', 'bedrock',
  ] },
  { name: "功能方块", icon: 'oak_sign', row: 0, col: 3, x: 81, items: [
    'torch', 'soul_torch', 'redstone_torch', 'lantern', 'soul_lantern', 'chain', 'end_rod', 'sea_lantern',
    'redstone_lamp', 'copper_bulb', 'exposed_copper_bulb', 'weathered_copper_bulb', 'oxidized_copper_bulb', 'waxed_copper_bulb', 'waxed_exposed_copper_bulb', 'waxed_weathered_copper_bulb',
    'waxed_oxidized_copper_bulb', 'glowstone', 'shroomlight', 'ochre_froglight', 'verdant_froglight', 'pearlescent_froglight', 'crying_obsidian', 'glow_lichen',
    'magma_block', 'crafting_table', 'stonecutter', 'cartography_table', 'fletching_table', 'smithing_table', 'grindstone', 'loom',
    'furnace', 'smoker', 'blast_furnace', 'campfire', 'soul_campfire', 'anvil', 'chipped_anvil', 'damaged_anvil',
    'composter', 'note_block', 'jukebox', 'enchanting_table', 'end_crystal', 'brewing_stand', 'cauldron', 'bell',
    'beacon', 'conduit', 'lodestone', 'ladder', 'scaffolding', 'bee_nest', 'beehive', 'suspicious_sand',
    'suspicious_gravel', 'lightning_rod', 'flower_pot', 'decorated_pot', 'armor_stand', 'item_frame', 'glow_item_frame', 'painting',
    'bookshelf', 'chiseled_bookshelf', 'lectern', 'tinted_glass', 'oak_sign', 'oak_hanging_sign', 'spruce_sign', 'spruce_hanging_sign',
    'birch_sign', 'birch_hanging_sign', 'jungle_sign', 'jungle_hanging_sign', 'acacia_sign', 'acacia_hanging_sign', 'dark_oak_sign', 'dark_oak_hanging_sign',
    'mangrove_sign', 'mangrove_hanging_sign', 'cherry_sign', 'cherry_hanging_sign', 'bamboo_sign', 'bamboo_hanging_sign', 'crimson_sign', 'crimson_hanging_sign',
    'warped_sign', 'warped_hanging_sign', 'chest', 'barrel', 'ender_chest', 'shulker_box', 'white_shulker_box', 'light_gray_shulker_box',
    'gray_shulker_box', 'black_shulker_box', 'brown_shulker_box', 'red_shulker_box', 'orange_shulker_box', 'yellow_shulker_box', 'lime_shulker_box', 'green_shulker_box',
    'cyan_shulker_box', 'light_blue_shulker_box', 'blue_shulker_box', 'purple_shulker_box', 'magenta_shulker_box', 'pink_shulker_box', 'respawn_anchor', 'white_bed',
    'light_gray_bed', 'gray_bed', 'black_bed', 'brown_bed', 'red_bed', 'orange_bed', 'yellow_bed', 'lime_bed',
    'green_bed', 'cyan_bed', 'light_blue_bed', 'blue_bed', 'purple_bed', 'magenta_bed', 'pink_bed', 'candle',
    'white_candle', 'light_gray_candle', 'gray_candle', 'black_candle', 'brown_candle', 'red_candle', 'orange_candle', 'yellow_candle',
    'lime_candle', 'green_candle', 'cyan_candle', 'light_blue_candle', 'blue_candle', 'purple_candle', 'magenta_candle', 'pink_candle',
    'white_banner', 'light_gray_banner', 'gray_banner', 'black_banner', 'brown_banner', 'red_banner', 'orange_banner', 'yellow_banner',
    'lime_banner', 'green_banner', 'cyan_banner', 'light_blue_banner', 'blue_banner', 'purple_banner', 'magenta_banner', 'pink_banner',
    'skeleton_skull', 'wither_skeleton_skull', 'player_head', 'zombie_head', 'creeper_head', 'piglin_head', 'dragon_head', 'dragon_egg',
    'end_portal_frame', 'ender_eye', 'vault', 'infested_stone', 'infested_cobblestone', 'infested_stone_bricks', 'infested_mossy_stone_bricks', 'infested_cracked_stone_bricks',
    'infested_chiseled_stone_bricks', 'infested_deepslate',
  ] },
  { name: "红石方块", icon: 'redstone', row: 0, col: 4, x: 108, items: ['redstone', 'redstone_torch', 'redstone_block', 'repeater', 'comparator', 'target', 'waxed_copper_bulb', 'waxed_exposed_copper_bulb', 'waxed_weathered_copper_bulb', 'waxed_oxidized_copper_bulb', 'lever', 'oak_button', 'stone_button', 'oak_pressure_plate', 'stone_pressure_plate', 'light_weighted_pressure_plate', 'heavy_weighted_pressure_plate', 'sculk_sensor', 'calibrated_sculk_sensor', 'sculk_shrieker', 'amethyst_block', 'white_wool', 'tripwire_hook', 'string', 'lectern', 'daylight_detector', 'lightning_rod', 'piston', 'sticky_piston', 'slime_block', 'honey_block', 'dispenser', 'dropper', 'crafter', 'hopper', 'chest', 'barrel', 'chiseled_bookshelf', 'furnace', 'trapped_chest', 'jukebox', 'decorated_pot', 'observer', 'note_block', 'composter', 'cauldron', 'rail', 'powered_rail', 'detector_rail', 'activator_rail', 'minecart', 'hopper_minecart', 'chest_minecart', 'furnace_minecart', 'tnt_minecart', 'oak_chest_boat', 'bamboo_chest_raft', 'oak_door', 'iron_door', 'oak_fence_gate', 'oak_trapdoor', 'iron_trapdoor', 'tnt', 'redstone_lamp', 'bell', 'big_dripleaf', 'armor_stand', 'redstone_ore'] },
  { name: "已保存的快捷栏", icon: 'bookshelf', row: 0, col: 5, x: 142, hotbar: true, items: [] },
  { name: "搜索物品", icon: 'compass', row: 0, col: 6, x: 169, search: true, items: [] },
  { name: "工具与实用物品", icon: 'diamond_pickaxe', row: 1, col: 0, x: 0, items: ['wooden_shovel', 'wooden_pickaxe', 'wooden_axe', 'wooden_hoe', 'stone_shovel', 'stone_pickaxe', 'stone_axe', 'stone_hoe', 'iron_shovel', 'iron_pickaxe', 'iron_axe', 'iron_hoe', 'golden_shovel', 'golden_pickaxe', 'golden_axe', 'golden_hoe', 'diamond_shovel', 'diamond_pickaxe', 'diamond_axe', 'diamond_hoe', 'netherite_shovel', 'netherite_pickaxe', 'netherite_axe', 'netherite_hoe', 'bucket', 'water_bucket', 'cod_bucket', 'salmon_bucket', 'tropical_fish_bucket', 'pufferfish_bucket', 'axolotl_bucket', 'tadpole_bucket', 'lava_bucket', 'powder_snow_bucket', 'milk_bucket', 'fishing_rod', 'flint_and_steel', 'fire_charge', 'bone_meal', 'shears', 'brush', 'name_tag', 'lead', 'bundle', 'compass', 'recovery_compass', 'clock', 'spyglass', 'map', 'writable_book', 'wind_charge', 'ender_pearl', 'ender_eye', 'elytra', 'firework_rocket', 'saddle', 'carrot_on_a_stick', 'warped_fungus_on_a_stick', 'oak_boat', 'oak_chest_boat', 'spruce_boat', 'spruce_chest_boat', 'birch_boat', 'birch_chest_boat', 'jungle_boat', 'jungle_chest_boat', 'acacia_boat', 'acacia_chest_boat', 'dark_oak_boat', 'dark_oak_chest_boat', 'mangrove_boat', 'mangrove_chest_boat', 'cherry_boat', 'cherry_chest_boat', 'bamboo_raft', 'bamboo_chest_raft', 'rail', 'powered_rail', 'detector_rail', 'activator_rail', 'minecart', 'hopper_minecart', 'chest_minecart', 'furnace_minecart', 'tnt_minecart', 'music_disc_13', 'music_disc_cat', 'music_disc_blocks', 'music_disc_chirp', 'music_disc_far', 'music_disc_mall', 'music_disc_mellohi', 'music_disc_stal', 'music_disc_strad', 'music_disc_ward', 'music_disc_11', 'music_disc_creator_music_box', 'music_disc_wait', 'music_disc_creator', 'music_disc_precipice', 'music_disc_otherside', 'music_disc_relic', 'music_disc_5', 'music_disc_pigstep'] },
  { name: "战斗用品", icon: 'netherite_sword', row: 1, col: 1, x: 27, items: ['wooden_sword', 'stone_sword', 'iron_sword', 'golden_sword', 'diamond_sword', 'netherite_sword', 'wooden_axe', 'stone_axe', 'iron_axe', 'golden_axe', 'diamond_axe', 'netherite_axe', 'trident', 'mace', 'shield', 'leather_helmet', 'leather_chestplate', 'leather_leggings', 'leather_boots', 'chainmail_helmet', 'chainmail_chestplate', 'chainmail_leggings', 'chainmail_boots', 'iron_helmet', 'iron_chestplate', 'iron_leggings', 'iron_boots', 'golden_helmet', 'golden_chestplate', 'golden_leggings', 'golden_boots', 'diamond_helmet', 'diamond_chestplate', 'diamond_leggings', 'diamond_boots', 'netherite_helmet', 'netherite_chestplate', 'netherite_leggings', 'netherite_boots', 'turtle_helmet', 'leather_horse_armor', 'iron_horse_armor', 'golden_horse_armor', 'diamond_horse_armor', 'wolf_armor', 'totem_of_undying', 'tnt', 'end_crystal', 'snowball', 'egg', 'wind_charge', 'bow', 'crossbow', 'firework_rocket', 'arrow', 'spectral_arrow'] },
  { name: "食物与饮品", icon: 'golden_apple', row: 1, col: 2, x: 54, items: ['apple', 'golden_apple', 'enchanted_golden_apple', 'melon_slice', 'sweet_berries', 'glow_berries', 'chorus_fruit', 'carrot', 'golden_carrot', 'potato', 'baked_potato', 'poisonous_potato', 'beetroot', 'dried_kelp', 'beef', 'cooked_beef', 'porkchop', 'cooked_porkchop', 'mutton', 'cooked_mutton', 'chicken', 'cooked_chicken', 'rabbit', 'cooked_rabbit', 'cod', 'cooked_cod', 'salmon', 'cooked_salmon', 'tropical_fish', 'pufferfish', 'bread', 'cookie', 'cake', 'pumpkin_pie', 'rotten_flesh', 'spider_eye', 'mushroom_stew', 'beetroot_soup', 'rabbit_stew', 'suspicious_stew', 'milk_bucket', 'honey_bottle', 'ominous_bottle'] },
  { name: "原材料", icon: 'iron_ingot', row: 1, col: 3, x: 81, items: ['coal', 'charcoal', 'raw_iron', 'raw_copper', 'raw_gold', 'emerald', 'lapis_lazuli', 'diamond', 'ancient_debris', 'quartz', 'amethyst_shard', 'iron_nugget', 'gold_nugget', 'iron_ingot', 'copper_ingot', 'gold_ingot', 'netherite_scrap', 'netherite_ingot', 'stick', 'flint', 'wheat', 'bone', 'bone_meal', 'string', 'feather', 'snowball', 'egg', 'leather', 'rabbit_hide', 'honeycomb', 'ink_sac', 'glow_ink_sac', 'turtle_scute', 'armadillo_scute', 'slime_ball', 'clay_ball', 'prismarine_shard', 'prismarine_crystals', 'nautilus_shell', 'heart_of_the_sea', 'fire_charge', 'blaze_rod', 'breeze_rod', 'heavy_core', 'nether_star', 'ender_pearl', 'ender_eye', 'shulker_shell', 'popped_chorus_fruit', 'echo_shard', 'disc_fragment_5', 'white_dye', 'light_gray_dye', 'gray_dye', 'black_dye', 'brown_dye', 'red_dye', 'orange_dye', 'yellow_dye', 'lime_dye', 'green_dye', 'cyan_dye', 'light_blue_dye', 'blue_dye', 'purple_dye', 'magenta_dye', 'pink_dye', 'bowl', 'brick', 'nether_brick', 'paper', 'book', 'firework_star', 'glass_bottle', 'nether_wart', 'redstone', 'glowstone_dust', 'gunpowder', 'dragon_breath', 'fermented_spider_eye', 'blaze_powder', 'sugar', 'rabbit_foot', 'glistering_melon_slice', 'spider_eye', 'pufferfish', 'magma_cream', 'golden_carrot', 'ghast_tear', 'turtle_helmet', 'phantom_membrane', 'flower_banner_pattern', 'creeper_banner_pattern', 'skull_banner_pattern', 'mojang_banner_pattern', 'globe_banner_pattern', 'piglin_banner_pattern', 'flow_banner_pattern', 'guster_banner_pattern', 'angler_pottery_sherd', 'archer_pottery_sherd', 'arms_up_pottery_sherd', 'blade_pottery_sherd', 'brewer_pottery_sherd', 'burn_pottery_sherd', 'danger_pottery_sherd', 'flow_pottery_sherd', 'explorer_pottery_sherd', 'friend_pottery_sherd', 'guster_pottery_sherd', 'heart_pottery_sherd', 'heartbreak_pottery_sherd', 'howl_pottery_sherd', 'miner_pottery_sherd', 'mourner_pottery_sherd', 'plenty_pottery_sherd', 'prize_pottery_sherd', 'scrape_pottery_sherd', 'sheaf_pottery_sherd', 'shelter_pottery_sherd', 'skull_pottery_sherd', 'snort_pottery_sherd', 'netherite_upgrade_smithing_template', 'sentry_armor_trim_smithing_template', 'vex_armor_trim_smithing_template', 'wild_armor_trim_smithing_template', 'coast_armor_trim_smithing_template', 'dune_armor_trim_smithing_template', 'wayfinder_armor_trim_smithing_template', 'raiser_armor_trim_smithing_template', 'shaper_armor_trim_smithing_template', 'host_armor_trim_smithing_template', 'ward_armor_trim_smithing_template', 'silence_armor_trim_smithing_template', 'tide_armor_trim_smithing_template', 'snout_armor_trim_smithing_template', 'rib_armor_trim_smithing_template', 'eye_armor_trim_smithing_template', 'spire_armor_trim_smithing_template', 'flow_armor_trim_smithing_template', 'bolt_armor_trim_smithing_template', 'experience_bottle', 'trial_key', 'ominous_trial_key'] },
  { name: "刷怪蛋", icon: 'creeper_spawn_egg', row: 1, col: 4, x: 108, items: ['spawner', 'trial_spawner', 'allay_spawn_egg', 'armadillo_spawn_egg', 'axolotl_spawn_egg', 'bat_spawn_egg', 'bee_spawn_egg', 'blaze_spawn_egg', 'bogged_spawn_egg', 'breeze_spawn_egg', 'camel_spawn_egg', 'cat_spawn_egg', 'cave_spider_spawn_egg', 'chicken_spawn_egg', 'cod_spawn_egg', 'cow_spawn_egg', 'creeper_spawn_egg', 'dolphin_spawn_egg', 'donkey_spawn_egg', 'drowned_spawn_egg', 'elder_guardian_spawn_egg', 'enderman_spawn_egg', 'endermite_spawn_egg', 'evoker_spawn_egg', 'fox_spawn_egg', 'frog_spawn_egg', 'ghast_spawn_egg', 'glow_squid_spawn_egg', 'goat_spawn_egg', 'guardian_spawn_egg', 'hoglin_spawn_egg', 'horse_spawn_egg', 'husk_spawn_egg', 'iron_golem_spawn_egg', 'llama_spawn_egg', 'magma_cube_spawn_egg', 'mooshroom_spawn_egg', 'mule_spawn_egg', 'ocelot_spawn_egg', 'panda_spawn_egg', 'parrot_spawn_egg', 'phantom_spawn_egg', 'pig_spawn_egg', 'piglin_spawn_egg', 'piglin_brute_spawn_egg', 'pillager_spawn_egg', 'polar_bear_spawn_egg', 'pufferfish_spawn_egg', 'rabbit_spawn_egg', 'ravager_spawn_egg', 'salmon_spawn_egg', 'sheep_spawn_egg', 'shulker_spawn_egg', 'silverfish_spawn_egg', 'skeleton_spawn_egg', 'skeleton_horse_spawn_egg', 'slime_spawn_egg', 'sniffer_spawn_egg', 'snow_golem_spawn_egg', 'spider_spawn_egg', 'squid_spawn_egg', 'stray_spawn_egg', 'strider_spawn_egg', 'tadpole_spawn_egg', 'trader_llama_spawn_egg', 'tropical_fish_spawn_egg', 'turtle_spawn_egg', 'vex_spawn_egg', 'villager_spawn_egg', 'vindicator_spawn_egg', 'wandering_trader_spawn_egg', 'warden_spawn_egg', 'witch_spawn_egg', 'wither_skeleton_spawn_egg', 'wolf_spawn_egg', 'zoglin_spawn_egg', 'zombie_spawn_egg', 'zombie_horse_spawn_egg', 'zombie_villager_spawn_egg', 'zombified_piglin_spawn_egg'] },
  { name: "管理员用品", icon: 'command_block', row: 1, col: 5, x: 135, items: ['command_block', 'chain_command_block', 'repeating_command_block', 'command_block_minecart', 'jigsaw', 'structure_block', 'structure_void', 'barrier', 'debug_stick', 'light'] },
  { name: "生存模式物品栏", icon: 'chest', row: 1, col: 6, x: 169, inventory: true, items: [] },
];
